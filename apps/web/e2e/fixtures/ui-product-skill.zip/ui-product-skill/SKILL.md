---
name: ui-product-skill
description: Browser imported skill
version: 1.0.0
---

# UI Product Skill
