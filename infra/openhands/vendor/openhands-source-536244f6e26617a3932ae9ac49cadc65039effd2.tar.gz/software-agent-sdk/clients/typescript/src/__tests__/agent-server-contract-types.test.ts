import { fileURLToPath } from 'node:url';
import ts from 'typescript';
import type { MCPClient } from '../client/mcp-client';
import type { RemoteWorkspace } from '../workspace/remote-workspace';
import type {
  GitChange as PublicGitChange,
  GitChangeStatus as PublicGitChangeStatus,
} from '../index';
import type { SettingsClient } from '../client/settings-client';
import type {
  AcpAgentProfile as GeneratedACPAgentProfile,
  AgentProfileDiagnostics as GeneratedAgentProfileDiagnostics,
  AgentProfileInfo as GeneratedAgentProfileSummary,
  GitChange as GeneratedGitChange,
  GitChangeStatus as GeneratedGitChangeStatus,
  McpConfigPatchWritable,
  McpServerPatchWritable,
  OpenHandsAgentProfile as GeneratedOpenHandsAgentProfile,
} from '../generated/agent-server-schema';
import type {
  ACPAgentProfile,
  AgentProfileDiagnostics,
  AgentProfileSaveInput,
  AgentProfileSummary,
  OpenHandsAgentProfile,
} from '../models/agent-profile';
import type {
  AgentServerMCPOAuthCallbackRequest,
  AgentServerMCPOAuthCallbackResponse,
  AgentServerMCPOAuthStatusResponse,
  AgentServerMCPStartOAuthRequest,
  AgentServerMCPStartOAuthResponse,
  AgentServerMCPTestRequest,
  AgentServerMCPTestResponse,
  AgentServerSettingsPatchRequest,
  AgentServerSettingsPatchResponse,
  AgentServerSettingsResponse,
  AgentServerSettingsSchema,
} from '../models/agent-server-api';
import type {
  MCPAuthCredential,
  MCPConfig,
  MCPConfigPatch,
  MCPServer,
  MCPServerPatch,
} from '../models/mcp-settings';

type Equal<Left, Right> =
  (<Value>() => Value extends Left ? 1 : 2) extends <Value>() => Value extends Right ? 1 : 2
    ? true
    : false;

type IsAny<Value> = 0 extends 1 & Value ? true : false;
type IsBareUnknown<Value> =
  IsAny<Value> extends true
    ? false
    : unknown extends Value
      ? [keyof Value] extends [never]
        ? true
        : false
      : false;

type GeneratedMCPClientContract = {
  testServer(request: AgentServerMCPTestRequest): Promise<AgentServerMCPTestResponse>;
  startOAuth(request: AgentServerMCPStartOAuthRequest): Promise<AgentServerMCPStartOAuthResponse>;
};

function assertType<Type extends true>(_value: Type): void {
  // Compiling this call is the assertion.
}

describe('Agent Server generated contract aliases', () => {
  it('typechecks the contract assertions with TypeScript', () => {
    const root = fileURLToPath(new URL('../../', import.meta.url));
    const configPath = fileURLToPath(new URL('../../tsconfig.json', import.meta.url));
    const config = ts.readConfigFile(configPath, ts.sys.readFile);
    const parsed = ts.parseJsonConfigFileContent(config.config, ts.sys, root);
    const program = ts.createProgram([fileURLToPath(import.meta.url)], {
      ...parsed.options,
      noEmit: true,
    });
    const diagnostics = [
      ...(config.error ? [config.error] : []),
      ...parsed.errors,
      ...ts.getPreEmitDiagnostics(program),
    ];
    expect(
      ts.formatDiagnostics(diagnostics, {
        getCanonicalFileName: (fileName) => fileName,
        getCurrentDirectory: ts.sys.getCurrentDirectory,
        getNewLine: () => ts.sys.newLine,
      })
    ).toBe('');
  }, 30_000);

  it('statically checks settings client request and response types', () => {
    assertType<
      Equal<Awaited<ReturnType<SettingsClient['getAgentSchema']>>, AgentServerSettingsSchema>
    >(true);
    assertType<
      Equal<Awaited<ReturnType<SettingsClient['getSettings']>>, AgentServerSettingsResponse>
    >(true);
    assertType<
      Equal<Parameters<SettingsClient['updateSettings']>[0], AgentServerSettingsPatchRequest>
    >(true);
    assertType<
      Equal<Awaited<ReturnType<SettingsClient['updateSettings']>>, AgentServerSettingsPatchResponse>
    >(true);
    assertType<Equal<Parameters<SettingsClient['createMcpServer']>[1], MCPServer>>(true);
    assertType<Equal<Parameters<SettingsClient['patchMcpServer']>[1], MCPServerPatch>>(true);
    assertType<
      Equal<
        Awaited<ReturnType<SettingsClient['createMcpServer']>>,
        AgentServerSettingsPatchResponse
      >
    >(true);
    assertType<
      Equal<Awaited<ReturnType<SettingsClient['patchMcpServer']>>, AgentServerSettingsPatchResponse>
    >(true);
    assertType<
      Equal<
        Awaited<ReturnType<SettingsClient['deleteMcpServer']>>,
        AgentServerSettingsPatchResponse
      >
    >(true);
  });

  it('keeps important MCP contract exports stronger than any or bare unknown', () => {
    assertType<Equal<IsAny<MCPServer>, false>>(true);
    assertType<Equal<IsBareUnknown<MCPServer>, false>>(true);
    assertType<Equal<IsAny<MCPConfig>, false>>(true);
    assertType<Equal<IsBareUnknown<MCPConfig>, false>>(true);
    assertType<Equal<IsAny<MCPAuthCredential>, false>>(true);
    assertType<Equal<IsBareUnknown<MCPAuthCredential>, false>>(true);
    assertType<Equal<IsAny<MCPServerPatch>, false>>(true);
    assertType<Equal<IsBareUnknown<MCPServerPatch>, false>>(true);
    assertType<Equal<IsAny<MCPConfigPatch>, false>>(true);
    assertType<Equal<IsBareUnknown<MCPConfigPatch>, false>>(true);
  });

  it('keeps MCP client methods checked against generated operations', () => {
    assertType<MCPClient extends GeneratedMCPClientContract ? true : false>(true);
    assertType<
      Equal<Awaited<ReturnType<MCPClient['getOAuthStatus']>>, AgentServerMCPOAuthStatusResponse>
    >(true);
    assertType<
      Equal<Parameters<MCPClient['submitOAuthCallback']>[1], AgentServerMCPOAuthCallbackRequest>
    >(true);
    assertType<
      Equal<
        Awaited<ReturnType<MCPClient['submitOAuthCallback']>>,
        AgentServerMCPOAuthCallbackResponse
      >
    >(true);
  });

  it('types git change statuses with the generated wire enum', () => {
    assertType<Equal<PublicGitChange['status'], GeneratedGitChange['status']>>(true);
    assertType<Equal<PublicGitChangeStatus, GeneratedGitChangeStatus>>(true);
    assertType<
      Equal<
        Awaited<ReturnType<RemoteWorkspace['gitChanges']>>[number]['status'],
        GeneratedGitChangeStatus
      >
    >(true);

    const statuses = ['ADDED', 'UPDATED', 'DELETED', 'MOVED'] satisfies PublicGitChange['status'][];
    expect(statuses).toHaveLength(4);
  });

  it('distinguishes omitted patch fields from explicit clearing', () => {
    const omitted = {} satisfies MCPServerPatch;
    const cleared = { auth: null } satisfies MCPServerPatch;

    expect('auth' in omitted).toBe(false);
    expect(cleared.auth).toBeNull();
  });

  it('derives every MCP patch field from the generated server contract', () => {
    assertType<Equal<MCPServerPatch, McpServerPatchWritable>>(true);
    assertType<Equal<MCPConfigPatch, McpConfigPatchWritable>>(true);
    assertType<Equal<MCPServerPatch['env'], Record<string, string | null> | null | undefined>>(
      true
    );
    assertType<Equal<MCPServerPatch['headers'], Record<string, string | null> | null | undefined>>(
      true
    );
  });

  it('declares every agent-profile payload field the server sends, and no others', () => {
    assertType<Equal<keyof AgentProfileSummary, keyof GeneratedAgentProfileSummary>>(true);
    assertType<Equal<keyof OpenHandsAgentProfile, keyof GeneratedOpenHandsAgentProfile>>(true);
    assertType<Equal<keyof ACPAgentProfile, keyof GeneratedACPAgentProfile>>(true);
    assertType<Equal<keyof AgentProfileDiagnostics, keyof GeneratedAgentProfileDiagnostics>>(true);
  });

  it('preserves optional nullable public-skill selection in profiles and diagnostics', () => {
    assertType<
      Equal<
        Pick<OpenHandsAgentProfile, 'public_skills'>,
        Pick<GeneratedOpenHandsAgentProfile, 'public_skills'>
      >
    >(true);
    assertType<
      Equal<
        Pick<AgentProfileDiagnostics, 'public_skills'>,
        Pick<GeneratedAgentProfileDiagnostics, 'public_skills'>
      >
    >(true);
    assertType<
      Equal<
        Pick<Extract<AgentProfileSaveInput, { agent_kind: 'openhands' }>, 'public_skills'>,
        Pick<GeneratedOpenHandsAgentProfile, 'public_skills'>
      >
    >(true);
  });
});
