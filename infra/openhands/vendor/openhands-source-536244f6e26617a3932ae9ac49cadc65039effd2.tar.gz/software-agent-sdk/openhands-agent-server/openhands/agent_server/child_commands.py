"""Native governed child commands; no platform execution or message queue."""

import asyncio
from typing import TYPE_CHECKING
from uuid import UUID, uuid5

from openhands.agent_server.child_queries import ChildQueries
from openhands.agent_server.prepared_child import complete_child_write
from openhands.sdk import Message, TextContent
from openhands.sdk.conversation.child_commands import (
    CHILD_COMMAND_TOOLS,
    ChildCommandInvocation,
    ChildCommandRequest,
    ChildCommandResult,
    ChildInputBusy,
    ChildInterruptReceipt,
    child_input_event_id,
    verify_child_command_token,
)
from openhands.sdk.conversation.child_launcher import ChildLauncherDenied
from openhands.sdk.conversation.state import ConversationExecutionStatus
from openhands.sdk.event import InterruptEvent, PauseEvent
from openhands.sdk.utils import utc_now
from openhands.sdk.utils.files import atomic_write_text


if TYPE_CHECKING:
    from openhands.agent_server.conversation_service import ConversationService
    from openhands.agent_server.event_service import EventService


class ChildCommands:
    def __init__(self, service: "ConversationService"):
        self.service = service
        self.queries = ChildQueries(service)

    async def verify(
        self, parent_id: UUID, request: ChildCommandRequest
    ) -> ChildCommandInvocation:
        claim = verify_child_command_token(request, self.queries.cipher(parent_id))
        if claim.policy.parent_conversation_id != parent_id:
            raise ChildLauncherDenied("Child command parent mismatch")
        expected = {"conversation_id": str(claim.command.conversation_id)}
        if claim.command.operation == "send":
            assert claim.command.text is not None
            expected["text"] = claim.command.text
        await self.queries.verify_native(
            parent_id, claim, CHILD_COMMAND_TOOLS[claim.command.operation], expected
        )
        await self.queries.record(claim.command.conversation_id, claim)
        if claim.expires_at <= utc_now():
            # Expired proofs may only reconcile an already persisted native effect.
            child = await self.service.get_persisted_event_service(
                claim.command.conversation_id
            )
            if child is None:
                raise ChildLauncherDenied("Expired child command")
            path = self._receipt_path(claim)
            if claim.command.operation == "send":
                event = await child.get_event(
                    child_input_event_id(
                        claim.command.conversation_id, claim.command_id
                    )
                )
                if event is None:
                    raise ChildLauncherDenied("Expired child command was not admitted")
            elif not await self.service._run_read(path.exists):
                raise ChildLauncherDenied("Expired child command was not admitted")
        return claim

    def _receipt_path(self, claim: ChildCommandInvocation):
        return (
            self.service.conversations_dir
            / claim.command.conversation_id.hex
            / "child-interrupts"
            / f"{claim.command_id.hex}.json"
        )

    async def execute(
        self, parent_id: UUID, request: ChildCommandRequest
    ) -> ChildCommandResult:
        claim = await self.verify(parent_id, request)
        child_id = claim.command.conversation_id
        async with self.service._conversation_lifecycle(child_id):
            await self.verify(parent_id, request)
            child = await self.service._get_or_load_event_service_locked(child_id)
            if child is None:
                raise ChildInputBusy("Child runtime is unavailable")
            child._require_child_release()
            if claim.command.operation == "send":
                assert claim.command.text is not None
                return await child.submit_child_message(
                    Message(
                        role="user", content=[TextContent(text=claim.command.text)]
                    ),
                    claim.command_id,
                    source=claim.source(),
                )
            if child._child_input_lock.locked():
                raise ChildInputBusy("Child input operation is in progress")
            async with child._child_input_lock:
                return await complete_child_write(self._interrupt(child, claim))

    async def _interrupt(
        self, child: "EventService", claim: ChildCommandInvocation
    ) -> ChildCommandResult:
        path = self._receipt_path(claim)
        conversation = child._conversation
        assert conversation is not None

        def load():
            if not path.exists():
                return None
            receipt = ChildInterruptReceipt.model_validate_json(path.read_text())
            if (
                receipt.command_id != claim.command_id
                or receipt.conversation_id != child.stored.id
                or receipt.source != claim.source()
            ):
                raise ChildInputBusy(
                    "Interrupt identity conflicts with prior admission"
                )
            return receipt

        receipt = await child._run_lifecycle(load)
        replayed = receipt is not None
        event_id = str(uuid5(claim.command_id, "native-interrupt-v1"))

        def snapshot():
            state = conversation._state
            # Native tools can hold the live state lock. Immutable events and
            # the current input pointer suffice to fence a stale interruption.
            return (
                state.last_user_message_id,
                state.leaf_event_id,
                state.execution_status,
            )

        input_id, head, status = await child._run_read(snapshot)
        if receipt is None:
            receipt = ChildInterruptReceipt(
                command_id=claim.command_id,
                conversation_id=child.stored.id,
                source=claim.source(),
                target_input_id=input_id,
                target_head=head,
            )

        async def save(value):
            def write():
                with child._write_guard():
                    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
                    atomic_write_text(path, value.model_dump_json())

            await child._run_lifecycle(write)

        if receipt.phase == "completed":
            return ChildCommandResult(
                conversation_id=child.stored.id,
                command_id=claim.command_id,
                operation="interrupt",
                event_id=receipt.interrupt_event_id,
                interrupted=receipt.interrupt_event_id is not None,
                replayed=True,
            )
        await save(receipt)
        event = await child.get_event(event_id)
        if (
            event is None
            and input_id == receipt.target_input_id
            and (
                (child._run_task is not None and not child._run_task.done())
                or status
                in {
                    ConversationExecutionStatus.RUNNING,
                    ConversationExecutionStatus.WAITING_FOR_CONFIRMATION,
                    ConversationExecutionStatus.WAITING_FOR_USER_INPUT,
                }
            )
        ):
            child._explicit_interrupt_generation += 1
            child._rerun_requested = False
            child._acp_internal_rerun_requested = False
            await child._run_control(
                lambda: conversation.interrupt(
                    event_id=event_id, parent_instruction=claim.source()
                )
            )
            task = child._run_task
            if task is not None and not task.done():
                try:
                    await asyncio.wait_for(asyncio.shield(task), timeout=5)
                except TimeoutError:
                    return ChildCommandResult(
                        conversation_id=child.stored.id,
                        command_id=claim.command_id,
                        operation="interrupt",
                        pending=True,
                        replayed=replayed,
                    )
            event = await child.get_event(event_id)
        if event is not None and (
            not isinstance(event, (InterruptEvent, PauseEvent))
            or event.parent_instruction != claim.source()
        ):
            raise ChildInputBusy("Native interrupt identity mismatch")
        receipt = receipt.model_copy(
            update={
                "phase": "completed",
                "interrupt_event_id": event.id if event else None,
            }
        )
        await save(receipt)
        return ChildCommandResult(
            conversation_id=child.stored.id,
            command_id=claim.command_id,
            operation="interrupt",
            event_id=receipt.interrupt_event_id,
            interrupted=event is not None,
            replayed=replayed,
        )
