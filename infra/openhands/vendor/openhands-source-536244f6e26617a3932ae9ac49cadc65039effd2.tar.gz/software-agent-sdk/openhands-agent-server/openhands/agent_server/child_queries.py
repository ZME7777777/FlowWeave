"""Read-only native projections and cancellable waits for direct children."""

import asyncio
import json
import os
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal
from uuid import UUID

from pydantic import BaseModel, ConfigDict, SecretStr

from openhands.agent_server.child_creation_store import ChildCreationConflict
from openhands.agent_server.event_service import EventService
from openhands.agent_server.models import StoredConversation
from openhands.sdk.conversation.child_commands import ChildCommandInvocation
from openhands.sdk.conversation.child_creation import ChildConversationCreationIdentity
from openhands.sdk.conversation.child_launcher import (
    ChildLauncherDenied,
    ChildLauncherPolicy,
)
from openhands.sdk.conversation.child_queries import (
    CHILD_QUERY_TOOLS,
    ChildEventExcerpt,
    ChildListPage,
    ChildQueryInvocation,
    ChildQueryRequest,
    ChildQueryResult,
    ChildReadPage,
    ChildSnapshot,
    ChildWaitResult,
    verify_child_query_token,
)
from openhands.sdk.conversation.persistence_const import BASE_STATE
from openhands.sdk.conversation.state import ConversationExecutionStatus
from openhands.sdk.event import ActionEvent, MessageEvent, ObservationEvent
from openhands.sdk.event.types import ROOT_PARENT_ID
from openhands.sdk.llm import TextContent
from openhands.sdk.utils.cipher import Cipher


if TYPE_CHECKING:
    from openhands.agent_server.conversation_service import ConversationService


class _Cursor(BaseModel):
    model_config = ConfigDict(extra="forbid")

    version: Literal[1] = 1
    kind: Literal["list", "read", "checkpoint"]
    policy: ChildLauncherPolicy
    conversation_id: UUID | None = None
    head: str | None = None
    next_event_id: str | None = None
    text_offset: int = 0
    last_child: UUID | None = None
    mode: Literal["events", "results"] = "events"
    status: ConversationExecutionStatus | None = None
    phase: str | None = None
    title: str | None = None


class ChildQueries:
    def __init__(self, service: "ConversationService"):
        self.service = service

    def cipher(self, parent_id: UUID) -> Cipher:
        cipher = self.service._cipher_for(parent_id)
        runtime_keys = {self.service.session_api_key} | {
            value
            for name, value in os.environ.items()
            if name == "SESSION_API_KEY" or name.startswith("OH_SESSION_API_KEYS_")
        }
        if cipher is None or runtime_keys.intersection(
            {cipher.secret_key, *cipher.previous_keys}
        ):
            raise ChildLauncherDenied("Query requires an independent persistent cipher")
        return cipher

    def seal(self, cursor: _Cursor) -> str:
        token = self.cipher(cursor.policy.parent_conversation_id).encrypt(
            SecretStr(cursor.model_dump_json())
        )
        assert token is not None
        return token

    def unseal(self, value: str, claim: ChildQueryInvocation, kind: str) -> _Cursor:
        try:
            raw = self.cipher(claim.policy.parent_conversation_id).try_decrypt_str(
                value
            )
            if raw is None:
                raise ValueError("Invalid cursor")
            cursor = _Cursor.model_validate_json(raw)
            if cursor.kind != kind or cursor.policy != claim.policy:
                raise ValueError("Cursor scope mismatch")
            if kind != "list" and cursor.conversation_id != claim.query.conversation_id:
                raise ValueError("Cursor child mismatch")
            if kind == "read" and cursor.mode != claim.query.mode:
                raise ValueError("Cursor mode mismatch")
            return cursor
        except (ValueError, TypeError):
            raise ChildLauncherDenied("Invalid child query cursor") from None

    async def verify(
        self, parent_id: UUID, request: ChildQueryRequest
    ) -> ChildQueryInvocation:
        claim = verify_child_query_token(request, self.cipher(parent_id))
        if claim.policy.parent_conversation_id != parent_id:
            raise ChildLauncherDenied("Query parent mismatch")
        keys = {
            "list": {"cursor", "limit"},
            "read": {"conversation_id", "cursor", "mode", "limit", "max_chars"},
            "wait": {"conversation_id", "checkpoint", "timeout_seconds"},
        }[request.query.operation]
        payload = request.query.model_dump(mode="json")
        await self.verify_native(
            parent_id,
            claim,
            CHILD_QUERY_TOOLS[request.query.operation],
            {k: payload[k] for k in keys},
        )
        return claim

    async def verify_native(
        self,
        parent_id: UUID,
        claim: ChildQueryInvocation | ChildCommandInvocation,
        name: str,
        expected: dict[str, Any],
    ) -> None:
        async with self.service._conversation_lifecycle(parent_id):
            parent = await self.service._get_or_load_event_service_locked(parent_id)
            if (
                parent is None
                or parent.stored.parent_conversation_id is not None
                or parent.stored.child_launcher_invocation is not None
            ):
                raise ChildLauncherDenied(
                    "Only a governed root parent can query children"
                )
            state = await parent.get_state()

            def check():
                # Events are immutable; taking the run lock here deadlocks the
                # parent that is waiting for its own native tool HTTP response.
                tools = [t for t in state.agent.tools if t.name == name]
                if len(tools) != 1:
                    raise ChildLauncherDenied("Frozen child query tool is unavailable")
                try:
                    policy = ChildLauncherPolicy.model_validate(
                        tools[0].params["policy"]
                    )
                    audience = tools[0].params["access_url"]
                except (KeyError, ValueError, TypeError):
                    raise ChildLauncherDenied(
                        "Invalid frozen child query configuration"
                    ) from None
                if policy != claim.policy or audience != claim.audience:
                    raise ChildLauncherDenied("Child query configuration changed")
                if claim.action_id not in state.events:
                    raise ChildLauncherDenied("Child query action is missing")
                event = state.events[state.events.get_index(claim.action_id)]
                if (
                    not isinstance(event, ActionEvent)
                    or event.action is None
                    or event.tool_name != name
                    or event.tool_call_id != claim.tool_call_id
                    or event.tool_call.id != claim.tool_call_id
                ):
                    raise ChildLauncherDenied("Native child query action mismatch")
                # Scope is frozen config, never a model argument.
                args = event.action.model_dump(mode="json")
                if any(args.get(k) != value for k, value in expected.items()):
                    raise ChildLauncherDenied(
                        "Native child operation parameters changed"
                    )
                head, seen = state.leaf_event_id, set()
                while head is not None and head != event.id:
                    if head in seen or head not in state.events:
                        raise ChildLauncherDenied("Invalid query event ancestry")
                    seen.add(head)
                    head = state.events[state.events.get_index(head)].parent_id
                if head is None:
                    raise ChildLauncherDenied(
                        "Child query action is outside the active branch"
                    )

            await self.service._run_read(check)

    def matches(
        self,
        parent: StoredConversation,
        child: StoredConversation,
        claim: ChildQueryInvocation | ChildCommandInvocation,
    ) -> bool:
        admitted = child.child_launcher_invocation
        gate = child.child_launch_gate
        if admitted is None or gate is None:
            return False
        expected = ChildConversationCreationIdentity.for_request(
            parent.id, admitted.creation_id
        )
        return (
            child.id == expected.conversation_id
            and child.parent_conversation_id == parent.id
            and gate.receipt.identity == expected
            and admitted.policy.parent_conversation_id == parent.id
            and admitted.policy.scope_id == claim.policy.scope_id
            and admitted.policy.runtime_session_id == claim.policy.runtime_session_id
            and admitted.policy.manifest_digest == claim.policy.manifest_digest
            and not child.worktree
            and Path(str(child.workspace.working_dir)).resolve()
            == Path(str(parent.workspace.working_dir)).resolve()
        )

    async def record(
        self, child_id: UUID, claim: ChildQueryInvocation | ChildCommandInvocation
    ) -> StoredConversation:
        def read():
            parent_id = claim.policy.parent_conversation_id
            parents = self.service._load_catalog_sync(parent_id)
            children = self.service._load_catalog_sync(child_id)
            parent, child = parents.get(parent_id), children.get(child_id)
            if (
                parent is None
                or child is None
                or not self.matches(parent.stored, child.stored, claim)
            ):
                raise ChildLauncherDenied("Target is not an authorized direct child")
            deleted = (
                self.service._child_creation_store().directory
                / f"{child_id.hex}.deleted"
            )
            if deleted.exists():
                raise ChildLauncherDenied("Child deletion has begun")
            return child.stored

        return await self.service._run_read(read)

    async def snapshot(
        self, child_id: UUID, claim: ChildQueryInvocation
    ) -> ChildSnapshot:
        child = await self.record(child_id, claim)

        def read():
            # base_state is an atomic native snapshot, readable while a tool holds
            # the live state lock. Never activate the child or await its run lock.
            payload = json.loads(
                (self.service.conversations_dir / child_id.hex / BASE_STATE).read_text()
            )
            status = ConversationExecutionStatus(payload["execution_status"])
            head = payload.get("leaf_event_id")
            assert child.child_launch_gate is not None
            phase = child.child_launch_gate.phase
            title = child.title[:256] if child.title is not None else None
            marker = self.seal(
                _Cursor(
                    kind="checkpoint",
                    policy=claim.policy,
                    conversation_id=child_id,
                    head=head,
                    status=status,
                    phase=phase,
                    title=title,
                )
            )
            return ChildSnapshot(
                conversation_id=child_id,
                parent_conversation_id=claim.policy.parent_conversation_id,
                title=title,
                title_truncated=bool(child.title and len(child.title) > 256),
                execution_status=status,
                preparation_phase=phase,
                leaf_event_id=head,
                checkpoint=marker,
            )

        return await self.service._run_read(read)

    async def list(self, claim: ChildQueryInvocation) -> ChildListPage:
        cursor = (
            self.unseal(claim.query.cursor, claim, "list")
            if claim.query.cursor
            else None
        )
        parent_id = claim.policy.parent_conversation_id

        def ids():
            records = self.service._load_catalog_sync()
            parent = records.get(parent_id)
            if parent is None:
                raise ChildLauncherDenied("Parent no longer exists")
            return sorted(
                [
                    r.stored.id
                    for r in records.values()
                    if self.matches(parent.stored, r.stored, claim)
                    and (
                        cursor is None
                        or cursor.last_child is None
                        or r.stored.id.hex > cursor.last_child.hex
                    )
                ],
                key=lambda i: i.hex,
            )

        children = await self.service._run_read(ids)
        items = [
            await self.snapshot(child_id, claim)
            for child_id in children[: claim.query.limit]
        ]
        more = len(children) > len(items)
        next_cursor = (
            self.seal(
                _Cursor(
                    kind="list",
                    policy=claim.policy,
                    last_child=items[-1].conversation_id,
                )
            )
            if more
            else None
        )
        return ChildListPage(items=items, next_cursor=next_cursor, complete=not more)

    async def read(self, claim: ChildQueryInvocation) -> ChildReadPage:
        assert claim.query.conversation_id is not None
        snapshot = await self.snapshot(claim.query.conversation_id, claim)
        cursor = (
            self.unseal(claim.query.cursor, claim, "read")
            if claim.query.cursor
            else _Cursor(
                kind="read",
                policy=claim.policy,
                conversation_id=snapshot.conversation_id,
                head=snapshot.leaf_event_id,
                next_event_id=snapshot.leaf_event_id,
                mode=claim.query.mode,
            )
        )
        if cursor.head != snapshot.leaf_event_id:
            raise ChildCreationConflict(
                "Child head changed; restart reading without a cursor"
            )
        stored = await self.record(snapshot.conversation_id, claim)

        events = EventService.for_persisted_events(
            stored, self.service.conversations_dir
        )

        def page():
            log = events._events_for_read()
            head, offset = cursor.next_event_id, cursor.text_offset
            remaining, scanned, seen = claim.query.max_chars, 0, set()
            items = []
            while (
                head is not None
                and len(items) < claim.query.limit
                and scanned < 100
                and remaining > 0
            ):
                if head in seen or head not in log:
                    raise ChildCreationConflict("Child event ancestry is unavailable")
                seen.add(head)
                event = log[log.get_index(head)]
                scanned += 1
                parent = event.parent_id if event.parent_id != ROOT_PARENT_ID else None
                assistant = (
                    isinstance(event, MessageEvent)
                    and event.source == "agent"
                    and event.llm_message.role == "assistant"
                )
                include = assistant or (
                    claim.query.mode == "events"
                    and isinstance(event, (ActionEvent, ObservationEvent))
                )
                if include:
                    text = (
                        "\n".join(
                            p.text
                            for p in event.llm_message.content
                            if isinstance(p, TextContent)
                        )
                        if assistant and isinstance(event, MessageEvent)
                        else None
                    )
                    total = len(text) if text is not None else 0
                    if offset < 0 or offset > total:
                        raise ChildCreationConflict("Invalid child event offset")
                    part = (
                        text[offset : offset + remaining] if text is not None else None
                    )
                    end = offset + len(part or "")
                    complete = end == total
                    items.append(
                        ChildEventExcerpt(
                            event_id=event.id,
                            parent_id=event.parent_id,
                            kind=type(event).__name__,
                            source=event.source,
                            tool_name=event.tool_name
                            if isinstance(event, (ActionEvent, ObservationEvent))
                            else None,
                            action_id=event.action_id
                            if isinstance(event, ObservationEvent)
                            else None,
                            tool_call_id=event.tool_call_id
                            if isinstance(event, (ActionEvent, ObservationEvent))
                            else None,
                            text=part,
                            text_offset=offset,
                            next_text_offset=None if complete else end,
                            complete=complete,
                        )
                    )
                    remaining -= len(part or "")
                    if not complete:
                        offset = end
                        break
                head, offset = parent, 0
            next_cursor = (
                self.seal(
                    cursor.model_copy(
                        update={"next_event_id": head, "text_offset": offset}
                    )
                )
                if head is not None
                else None
            )
            return ChildReadPage(
                snapshot=snapshot,
                items=items,
                next_cursor=next_cursor,
                complete=head is None,
            )

        result = await self.service._run_read(page)
        latest = await self.snapshot(snapshot.conversation_id, claim)
        if latest.leaf_event_id != snapshot.leaf_event_id:
            raise ChildCreationConflict(
                "Child head changed; restart reading without a cursor"
            )
        return result

    async def wait(self, claim: ChildQueryInvocation) -> ChildWaitResult:
        assert claim.query.conversation_id is not None
        first = await self.snapshot(claim.query.conversation_id, claim)
        marker = self.unseal(
            claim.query.checkpoint or first.checkpoint, claim, "checkpoint"
        )
        deadline = asyncio.get_running_loop().time() + claim.query.timeout_seconds
        current = first
        while True:
            changed = (
                current.leaf_event_id,
                current.execution_status,
                current.preparation_phase,
                current.title,
            ) != (marker.head, marker.status, marker.phase, marker.title)
            remaining = deadline - asyncio.get_running_loop().time()
            if changed or remaining <= 0:
                return ChildWaitResult(
                    snapshot=current, changed=changed, timed_out=not changed
                )
            await asyncio.sleep(min(0.2, remaining))
            current = await self.snapshot(claim.query.conversation_id, claim)

    async def execute(
        self, parent_id: UUID, request: ChildQueryRequest
    ) -> ChildQueryResult:
        claim = await self.verify(parent_id, request)
        if request.query.operation == "list":
            result = await self.list(claim)
        elif request.query.operation == "read":
            result = await self.read(claim)
        else:
            result = await self.wait(claim)
        # Revalidate after every await-heavy projection; no stale scope can escape.
        await self.verify(parent_id, request)
        if result.kind == "list":
            for item in result.items:
                await self.record(item.conversation_id, claim)
        else:
            await self.record(result.snapshot.conversation_id, claim)
        return result
