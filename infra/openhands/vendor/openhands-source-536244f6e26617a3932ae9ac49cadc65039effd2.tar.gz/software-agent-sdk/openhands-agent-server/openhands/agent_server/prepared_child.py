"""Immutable native launch plans used to recover interrupted child preparation."""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable

from pydantic import BaseModel, ConfigDict, Field, model_validator

from openhands.agent_server.models import StoredConversation
from openhands.sdk.conversation.child_creation import ChildConversationCreationReceipt
from openhands.sdk.conversation.child_governance import (
    ChildConversationPreparationOverrides,
)
from openhands.sdk.conversation.request import ACPEnabledAgent


class ChildConversationNotReleased(RuntimeError):
    """The native child is awaiting governance or first-turn admission."""


class PreparedChildPlan(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    receipt: ChildConversationCreationReceipt
    stored: StoredConversation
    agent: ACPEnabledAgent
    overrides: ChildConversationPreparationOverrides | None = Field(
        default=None, repr=False, exclude_if=lambda value: value is None
    )

    @model_validator(mode="after")
    def validate_identity(self) -> PreparedChildPlan:
        gate = self.stored.child_launch_gate
        identity = self.receipt.identity
        if (
            gate is None
            or gate.receipt != self.receipt
            or gate.phase != "prepared"
            or self.stored.id != identity.conversation_id
            or self.stored.parent_conversation_id != identity.parent_conversation_id
            or self.stored.worktree
            or gate.governance_id
            != (self.overrides.governance_id if self.overrides else None)
        ):
            raise ValueError("Prepared child plan identity mismatch")
        return self


async def complete_child_write[T](operation: Awaitable[T]) -> T:
    """Keep lifecycle fencing until an off-loop native write has settled."""
    task = asyncio.ensure_future(operation)
    try:
        return await asyncio.shield(task)
    except asyncio.CancelledError:
        while not task.done():
            try:
                await asyncio.shield(task)
            except asyncio.CancelledError:
                continue
        task.result()
        raise


def apply_child_overrides(
    stored: StoredConversation,
    agent: ACPEnabledAgent,
    overrides: ChildConversationPreparationOverrides,
) -> tuple[StoredConversation, ACPEnabledAgent]:
    """Do not leave a parent source in meta, context, registry seed or plan."""
    removed = overrides.remove_secrets
    replacements = overrides.replace_secrets
    context = agent.agent_context
    if context is not None:
        context = context.model_copy(
            update={
                "secrets": {
                    name: source
                    for name, source in (context.secrets or {}).items()
                    if name not in removed and name not in replacements
                },
            }
        )
    agent = agent.model_copy(
        update={
            "agent_context": context,
            "mcp_config": {
                name: config
                for name, config in (agent.mcp_config or {}).items()
                if name not in overrides.remove_mcp_servers
            },
        }
    )
    # Copy the exact configured native sources; no source is resolved here.
    stored = stored.model_copy(
        update={
            "secrets": {
                **{
                    name: source
                    for name, source in stored.secrets.items()
                    if name not in removed
                },
                **replacements,
            },
        }
    )
    return stored, agent
