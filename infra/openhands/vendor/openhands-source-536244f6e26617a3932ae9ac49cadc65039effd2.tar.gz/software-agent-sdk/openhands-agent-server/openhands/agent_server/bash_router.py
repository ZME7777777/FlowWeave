"""Bash router for OpenHands SDK."""

import logging
from datetime import datetime
from pathlib import Path
from typing import Annotated, Literal
from uuid import UUID

from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
    Query,
    status,
)

from openhands.agent_server.bash_service import BashEventService
from openhands.agent_server.dependencies import get_bash_event_service
from openhands.agent_server.models import (
    BashCommand,
    BashEventBase,
    BashEventPage,
    BashEventSortOrder,
    BashOutput,
    ExecuteBashRequest,
    Success,
)
from openhands.agent_server.server_details_router import update_last_execution_time


bash_router = APIRouter(prefix="/bash", tags=["Bash"])
logger = logging.getLogger(__name__)


# bash event routes
@bash_router.get("/bash_events/search")
async def search_bash_events(
    kind__eq: Literal["BashCommand", "BashOutput"] | None = None,
    command_id__eq: UUID | None = None,
    timestamp__gte: datetime | None = None,
    timestamp__lt: datetime | None = None,
    order__gt: Annotated[
        int | None,
        Query(
            title="Filter to events with order greater than this value",
            description="Only returns BashOutput events with order > this value. "
            "Useful for polling to fetch only new events since the last poll.",
        ),
    ] = None,
    sort_order: BashEventSortOrder = BashEventSortOrder.TIMESTAMP,
    page_id: Annotated[
        str | None,
        Query(title="Optional next_page_id from the previously returned page"),
    ] = None,
    limit: Annotated[
        int,
        Query(title="The max number of results in the page", gt=0, le=100),
    ] = 100,
    bash_event_service: BashEventService = Depends(get_bash_event_service),
) -> BashEventPage:
    """Search / List bash event events"""

    return await bash_event_service.search_bash_events(
        kind__eq=kind__eq,
        command_id__eq=command_id__eq,
        timestamp__gte=timestamp__gte,
        timestamp__lt=timestamp__lt,
        order__gt=order__gt,
        sort_order=sort_order,
        page_id=page_id,
        limit=limit,
    )


@bash_router.get(
    "/bash_events/{event_id}", responses={404: {"description": "Item not found"}}
)
async def get_bash_event(
    event_id: str,
    bash_event_service: BashEventService = Depends(get_bash_event_service),
) -> BashEventBase:
    """Get a bash event event given an id"""
    event = await bash_event_service.get_bash_event(event_id)
    if event is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND)
    return event


@bash_router.get("/bash_events/")
async def batch_get_bash_events(
    event_ids: list[str],
    bash_event_service: BashEventService = Depends(get_bash_event_service),
) -> list[BashEventBase | None]:
    """Get a batch of bash event events given their ids, returning null for any
    missing item."""
    events = await bash_event_service.batch_get_bash_events(event_ids)
    return events


@bash_router.post("/start_bash_command")
async def start_bash_command(
    request: ExecuteBashRequest,
    bash_event_service: BashEventService = Depends(get_bash_event_service),
) -> BashCommand:
    """Execute a bash command in the background"""
    update_last_execution_time()
    _validate_cwd(request, bash_event_service)
    command, _ = await bash_event_service.start_bash_command(request)
    return command


@bash_router.post("/execute_bash_command")
async def execute_bash_command(
    request: ExecuteBashRequest,
    bash_event_service: BashEventService = Depends(get_bash_event_service),
) -> BashOutput:
    """Execute a bash command and wait for a result"""
    update_last_execution_time()
    _validate_cwd(request, bash_event_service)
    command, task = await bash_event_service.start_bash_command(request)
    await task
    return await _collect_bash_output(bash_event_service, command.id)


async def _collect_bash_output(
    bash_event_service: BashEventService, command_id: UUID
) -> BashOutput:
    """Join every stored output chunk of a finished command into one result.

    Output over ``MAX_CONTENT_CHAR_LENGTH`` is stored as several ``BashOutput``
    events and only the final one carries the exit code, so read all pages
    instead of returning the last event of the first page.
    """
    outputs: list[BashOutput] = []
    page_id: str | None = None
    while True:
        page = await bash_event_service.search_bash_events(
            kind__eq="BashOutput", command_id__eq=command_id, page_id=page_id
        )
        outputs.extend(item for item in page.items if isinstance(item, BashOutput))
        page_id = page.next_page_id
        if not page_id:
            break
    if not outputs:
        return BashOutput(command_id=command_id, exit_code=-1)
    # Search returns timestamp order; a stable sort keeps it for equal orders.
    outputs.sort(key=lambda output: output.order)
    final = outputs[-1]
    stdout = "".join(output.stdout for output in outputs if output.stdout)
    stderr = "".join(output.stderr for output in outputs if output.stderr)
    return final.model_copy(
        update={
            "exit_code": -1 if final.exit_code is None else final.exit_code,
            "stdout": stdout or None,
            "stderr": stderr or None,
        }
    )


@bash_router.delete("/bash_events")
async def clear_all_bash_events(
    bash_event_service: BashEventService = Depends(get_bash_event_service),
) -> dict[str, int]:
    """Clear all bash events from storage"""
    count = await bash_event_service.clear_all_events()
    return {"cleared_count": count}


@bash_router.post(
    "/bash_commands/{command_id}/stop",
    responses={404: {"description": "Item not found"}},
)
async def stop_bash_command(
    command_id: UUID,
    bash_event_service: BashEventService = Depends(get_bash_event_service),
) -> Success:
    """Stop a running bash command by id without touching the others.

    Idempotent: stopping an already-finished command succeeds, while an
    unknown command id reports not-found so the caller can treat it as
    an already-cancelled stop.
    """
    update_last_execution_time()
    if await bash_event_service.stop_bash_command(command_id):
        return Success()
    if await bash_event_service.get_bash_event(command_id.hex) is not None:
        return Success()
    raise HTTPException(status.HTTP_404_NOT_FOUND)


def _validate_cwd(request: ExecuteBashRequest, service: BashEventService) -> None:
    if service.default_cwd is not None and request.cwd is not None:
        if (
            not Path(request.cwd)
            .resolve()
            .is_relative_to(Path(service.default_cwd).resolve())
        ):
            raise HTTPException(422, "cwd must be inside the conversation workspace")
