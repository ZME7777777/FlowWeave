"""Persistent, process-safe identity reservations for native child creation.

Call synchronous storage operations through the server's lifecycle executor.
Admission, authorization and conversation materialization belong to the caller.
"""

from __future__ import annotations

from pathlib import Path

from filelock import FileLock
from pydantic import ValidationError

from openhands.sdk.conversation.child_creation import (
    ChildConversationCreationIdentity,
    ChildConversationCreationReceipt,
    child_creation_request_digest,
)
from openhands.sdk.conversation.request import StartChildConversationRequest
from openhands.sdk.utils.files import atomic_write_text


class ChildCreationConflict(ValueError):
    """The same creation identity was reused with a different request."""


class ChildCreationReceiptCorrupt(RuntimeError):
    """A persisted receipt cannot safely establish the requested identity."""


class ChildConversationCreationStore:
    def __init__(self, directory: Path, *, lock_timeout_seconds: float = 5):
        if not 0 <= lock_timeout_seconds <= 30:
            raise ValueError("Creation receipt lock timeout must be between 0 and 30")
        self.directory = directory
        self.lock_timeout_seconds = lock_timeout_seconds

    def get(
        self, identity: ChildConversationCreationIdentity
    ) -> ChildConversationCreationReceipt | None:
        """Read a committed receipt without creating directories or taking locks."""
        path = self.directory / f"{identity.conversation_id.hex}.json"
        try:
            content = path.read_text(encoding="utf-8")
        except FileNotFoundError:
            return None
        except UnicodeError:
            raise ChildCreationReceiptCorrupt(
                "Invalid child creation receipt"
            ) from None
        try:
            receipt = ChildConversationCreationReceipt.model_validate_json(content)
        except ValidationError:
            raise ChildCreationReceiptCorrupt(
                "Invalid child creation receipt"
            ) from None
        if receipt.identity != identity:
            raise ChildCreationReceiptCorrupt(
                "Child creation receipt identity mismatch"
            )
        return receipt

    def reserve(
        self,
        identity: ChildConversationCreationIdentity,
        request: StartChildConversationRequest,
    ) -> tuple[ChildConversationCreationReceipt, bool]:
        """Commit once, or return the exact receipt for an identical retry.

        The lock serializes threads and server processes. The atomic rename is
        the commit point, so a failed response can be reconciled with ``get``.
        Receipts survive conversation deletion; this store never reuses IDs.
        """
        digest = child_creation_request_digest(request)
        self.directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        path = self.directory / f"{identity.conversation_id.hex}.json"
        with FileLock(
            str(path.with_suffix(".lock")),
            timeout=self.lock_timeout_seconds,
            mode=0o600,
        ):
            existing = self.get(identity)
            if existing is not None:
                if existing.request_digest != digest:
                    raise ChildCreationConflict("Child creation request changed")
                return existing, False
            receipt = ChildConversationCreationReceipt(
                identity=identity, request_digest=digest
            )
            atomic_write_text(path, receipt.model_dump_json())
            return receipt, True
