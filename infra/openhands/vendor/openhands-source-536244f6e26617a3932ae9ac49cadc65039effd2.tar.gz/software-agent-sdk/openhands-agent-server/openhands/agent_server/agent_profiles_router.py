"""HTTP endpoints for managing named ``AgentProfile`` launch specs.

Mirrors ``profiles_router.py`` (the LLM ``/api/profiles`` router) but serves the
reference-bearing :class:`~openhands.sdk.profiles.AgentProfile` union and keeps a
*separate* active pointer (``active_agent_profile_id``). Activation here is
pointer-only — unlike the LLM ``/activate`` it must **not** write
``agent_settings`` (the creation-time-only contract).

``POST /{name}/materialize`` performs a dry-run resolve of a stored profile, or
of a draft body, and returns
:class:`~openhands.sdk.profiles.AgentProfileDiagnostics` (never raises on
dangling refs — those appear in the body).
"""

import asyncio
from typing import Annotated, Any

from fastapi import APIRouter, HTTPException, Path, Request, status
from pydantic import BaseModel, ConfigDict, Field, PlainValidator, ValidationError

from openhands.agent_server._secrets_exposure import (
    get_cipher,
    get_config,
    store_errors,
)
from openhands.agent_server.config import Config
from openhands.agent_server.launch import (
    can_probe_tools,
    server_launch_stores,
    target_launch_runtime,
)
from openhands.agent_server.persistence import (
    PersistedSettings,
    get_agent_profile_store,
    get_llm_profile_store,
    get_settings_store,
)
from openhands.agent_server.profiles_router import MAX_PROFILES, _has_api_key
from openhands.sdk.launch import preview_launch
from openhands.sdk.llm import LLM
from openhands.sdk.llm.llm_profile_store import (
    ProfileLimitExceeded as LLMProfileLimitExceeded,
)
from openhands.sdk.logger import get_logger
from openhands.sdk.profiles import (
    SEED_PROFILE_NAME,
    ACPAgentProfile,
    AgentProfile,
    AgentProfileDiagnostics,
    AgentProfileInfo,
    AgentProfileListResponse,
    AgentProfileStore,
    OpenHandsAgentProfile,
    ProfileLimitExceeded,
    build_seed_profile,
    safe_validation_error_detail,
    save_profile_preserving_identity,
    validate_agent_profile,
)
from openhands.sdk.profiles.agent_profile_store import (
    PROFILE_NAME_PATTERN,
    canonical_profile_name,
)
from openhands.sdk.settings.model import OpenHandsAgentSettings
from openhands.sdk.utils.cipher import Cipher


logger = get_logger(__name__)

agent_profiles_router = APIRouter(prefix="/agent-profiles", tags=["Agent Profiles"])

MAX_AGENT_PROFILES = 50

ProfileName = Annotated[
    str,
    Path(min_length=1, max_length=64, pattern=PROFILE_NAME_PATTERN),
]
ProfileId = Annotated[str, Path(min_length=1, max_length=128)]


class AgentProfileDetailResponse(BaseModel):
    name: str
    profile: dict[str, Any]


class AgentProfileMutationResponse(BaseModel):
    name: str
    message: str


class ActivateAgentProfileResponse(BaseModel):
    id: str
    message: str
    # Always False: activation is pointer-only by contract. The field documents
    # that agent_settings was untouched; materialize (#3717) is the path that
    # resolves a profile into settings.
    agent_settings_applied: bool = False


def _raw_profile_payload(value: Any) -> dict[str, Any] | None:
    if value is not None and not isinstance(value, dict):
        raise ValueError("profile must be an object")
    return value


class MaterializeAgentProfileRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    # Kept raw so the draft goes through the same migrations as a save.
    profile: Annotated[
        dict[str, Any] | None,
        PlainValidator(
            _raw_profile_payload, json_schema_input_type=AgentProfile | None
        ),
    ] = Field(
        default=None,
        description=(
            "Draft profile to evaluate instead of the stored one. The path name "
            "overrides the draft's name."
        ),
    )


class RenameAgentProfileRequest(BaseModel):
    new_name: str = Field(
        ...,
        min_length=1,
        max_length=64,
        pattern=PROFILE_NAME_PATTERN,
    )


def _llm_has_real_config(llm: LLM) -> bool:
    """True when ``llm`` carries real, user-provided configuration.

    Distinguishes an already-working setup — a real API key, subscription auth,
    or a custom endpoint — from bare SDK field defaults on a never-configured
    account (``model="gpt-5.5"``, no ``api_key``). Only the former is worth
    mirroring into a named ``default`` LLM profile; persisting the latter leaves
    a keyless, non-functional "ghost" profile that the user never asked for and
    that nothing ever cleans up (#4031).
    """
    if _has_api_key(llm):
        return True
    if llm.is_subscription or llm.auth_type == "subscription":
        return True
    if llm.base_url and llm.base_url.strip():
        return True
    return False


def _seed_default_llm_profile(llm: LLM, cipher: Cipher | None) -> str:
    """Mirror the live LLM config into a ``SEED_PROFILE_NAME`` LLM profile.

    ``build_seed_profile`` falls back to the literal name ``SEED_PROFILE_NAME``
    when no LLM profile is active, on the assumption that a profile by that
    name exists — but nothing ever created one, so the seeded agent profile's
    ``llm_profile_ref`` dangled from birth (#3933). Mirrors the cloud
    ``SaasSettingsStore``'s legacy-LLM backfill: materialize the current
    ``agent_settings.llm`` under that name so the reference resolves, unless a
    profile is already stored there (never clobber it).

    Only a *real, pre-existing* LLM config is persisted (``_llm_has_real_config``
    — an API key, subscription auth, or a custom base_url), which is exactly the
    legacy/cloud migration case the backfill exists for. On a fresh,
    never-configured account the live LLM is untouched SDK defaults (keyless
    ``gpt-5.5``); persisting *that* only litters the profile list with a keyless,
    unusable ``default`` "ghost" profile (#4031), so we skip the save and leave
    ``llm_profile_ref="default"`` as a soft/dangling ref — the canvas
    "LLM not configured" banner and the legible launch-time error already cover
    that state, and materialize reports it rather than raising: ``valid`` false,
    ``llm_profile_resolved`` false and an ``errors`` entry
    ``"LLM profile 'default' not found"``.

    Existence is checked via ``load()``, not ``list()``: the store resolves a
    name straight to a filesystem path, so on a case-insensitive filesystem
    (macOS/Windows) a differently-cased ``Default`` profile already occupies
    the ``default`` path even though it wouldn't case-sensitively match a
    ``list()`` membership check — that mismatch would otherwise let ``save()``
    silently clobber it.
    """
    llm_store = get_llm_profile_store()
    with store_errors():
        try:
            llm_store.load(SEED_PROFILE_NAME, cipher=cipher)
            return SEED_PROFILE_NAME
        except FileNotFoundError:
            pass
        except ValueError:
            # Something already occupies the name (e.g. corrupted/unparsable
            # file) — never overwrite it; a broken ref surfaces at
            # materialize/launch time instead.
            logger.warning(
                f"Default LLM profile '{SEED_PROFILE_NAME}' exists but "
                "failed to load; leaving it as-is"
            )
            return SEED_PROFILE_NAME
        if not _llm_has_real_config(llm):
            # Never-configured account: don't persist a keyless ghost profile.
            # Leave the ref soft/dangling; the banner + launch-time error handle
            # it, and it resolves for real once the user saves a profile.
            logger.info(
                f"Skipping default LLM profile '{SEED_PROFILE_NAME}' seed: "
                "no real LLM config yet (leaving llm_profile_ref as a soft ref)"
            )
            return SEED_PROFILE_NAME
        try:
            llm_store.save(
                SEED_PROFILE_NAME,
                llm,
                include_secrets=True,
                cipher=cipher,
                max_profiles=MAX_PROFILES,
            )
            logger.info(f"Seeded default LLM profile '{SEED_PROFILE_NAME}'")
        except LLMProfileLimitExceeded:
            # Can't mirror the live LLM as a profile; the agent profile's
            # llm_profile_ref will still dangle, but no worse than before.
            logger.warning(
                "Could not seed default LLM profile "
                f"'{SEED_PROFILE_NAME}': profile limit reached"
            )
    return SEED_PROFILE_NAME


def _ensure_active_profile(
    store: AgentProfileStore, config: Config, cipher: Cipher | None
) -> None:
    """Keep ``active_agent_profile_id`` on a stored profile.

    A missing or dangling pointer moves to ``default``, which is seeded from the
    current ``agent_settings`` when absent, so every launch has a profile. When
    ``default`` is unreadable or the store is too full to seed it, the first
    other profile is activated instead. The lock spans the check, the seed and
    the pointer write, so concurrent callers seed once and agree on the pointer.
    """
    settings_store = get_settings_store(config)
    with store_errors(), store.lock():
        settings = settings_store.load() or PersistedSettings()
        active_id = settings.active_agent_profile_id
        if active_id is not None and store.name_for_id(active_id) is not None:
            return
        target = _profile_to_activate(store, settings, cipher)
        if target is None:
            return
        name, profile_id = target

        def set_pointer(s: PersistedSettings) -> PersistedSettings:
            s.active_agent_profile_id = profile_id
            return s

        settings_store.update(set_pointer)
        logger.info(f"Activated agent profile '{name}' (id={profile_id})")


def _profile_to_activate(
    store: AgentProfileStore, settings: PersistedSettings, cipher: Cipher | None
) -> tuple[str, str] | None:
    """Return the name and id of ``default``, seeding it if the store has room."""
    try:
        profile = store.load(SEED_PROFILE_NAME)
        return profile.name, str(profile.id)
    except FileNotFoundError:
        try:
            profile = _seed_default_profile(store, settings, cipher)
            return profile.name, str(profile.id)
        except ProfileLimitExceeded:
            pass
    except ValueError:
        logger.warning(
            f"Agent profile '{SEED_PROFILE_NAME}' exists but failed to load; "
            "leaving it as-is"
        )
    first = next(
        (
            s
            for s in store.list_summaries()
            if s["id"] and s["name"] != SEED_PROFILE_NAME
        ),
        None,
    )
    return (first["name"], str(first["id"])) if first else None


def _seed_default_profile(
    store: AgentProfileStore, settings: PersistedSettings, cipher: Cipher | None
) -> OpenHandsAgentProfile | ACPAgentProfile:
    active_llm_profile = settings.active_profile
    # Falsy check (not `is None`): mirrors build_seed_profile's own
    # `active_llm_profile or SEED_PROFILE_NAME` fallback. A stray empty
    # string (e.g. a hand-edited/legacy settings.json, or a direct
    # PersistedSettings(active_profile="") construction — the HTTP PATCH
    # payload's pattern validator blocks "" but the stored field has no
    # such constraint) is falsy there too, so the backfill must trigger
    # on the same condition or the exact #3933 dangling ref reappears.
    if not active_llm_profile and settings.agent_settings.agent_kind != "acp":
        active_llm_profile = _seed_default_llm_profile(
            settings.agent_settings.llm, cipher
        )
    profile = build_seed_profile(settings.agent_settings, active_llm_profile)
    store.save(profile, max_profiles=MAX_AGENT_PROFILES)
    logger.info(f"Seeded default agent profile '{profile.name}' (id={profile.id})")
    return profile


def active_agent_profile(
    config: Config, cipher: Cipher | None
) -> OpenHandsAgentProfile | ACPAgentProfile | None:
    """Return the active Agent Profile, activating ``default`` when none is."""
    store = get_agent_profile_store()
    _ensure_active_profile(store, config, cipher)
    settings = get_settings_store(config).load() or PersistedSettings()
    if settings.active_agent_profile_id is None:
        return None
    with store_errors():
        name = store.name_for_id(settings.active_agent_profile_id)
        if name is None:
            return None
        try:
            return store.load(name)
        except FileNotFoundError:
            return None


def _summary_id_for_name(store: AgentProfileStore, name: str) -> str | None:
    """Return the stable id of the profile stored under ``name``, if present."""
    name = canonical_profile_name(name)
    with store_errors():
        for summary in store.list_summaries():
            if summary.get("name") == name:
                sid = summary.get("id")
                return str(sid) if sid is not None else None
    return None


@agent_profiles_router.get("", response_model=AgentProfileListResponse)
async def list_agent_profiles(request: Request) -> AgentProfileListResponse:
    """List all stored agent profiles and the active pointer.

    Some profile is always active: with no valid pointer, ``default`` is
    activated, and seeded from the current ``agent_settings`` when absent.
    """
    config = get_config(request)
    settings_store = get_settings_store(config)
    settings = settings_store.load() or PersistedSettings()

    store = get_agent_profile_store()
    _ensure_active_profile(store, config, get_cipher(request))
    settings = settings_store.load() or settings

    with store_errors():
        summaries = store.list_summaries()

    return AgentProfileListResponse(
        profiles=[AgentProfileInfo(**s) for s in summaries],
        active_agent_profile_id=settings.active_agent_profile_id,
    )


@agent_profiles_router.get("/{name}", response_model=AgentProfileDetailResponse)
async def get_agent_profile(name: ProfileName) -> AgentProfileDetailResponse:
    """Get a stored profile.

    A profile is secret-free at rest (#4017), so there is nothing to mask or
    expose — unlike the LLM ``/api/profiles`` router, this endpoint has no
    ``X-Expose-Secrets`` behavior.
    """
    store = get_agent_profile_store()
    try:
        with store_errors():
            profile = store.load(name)
    except FileNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Agent profile '{name}' not found",
        )

    payload = profile.model_dump(mode="json")
    return AgentProfileDetailResponse(name=name, profile=payload)


def _validate_profile_payload(
    payload: dict[str, Any],
) -> OpenHandsAgentProfile | ACPAgentProfile:
    try:
        return validate_agent_profile(payload)
    except ValidationError as e:
        # Match FastAPI's request-validation shape (``detail`` is a list of
        # error objects): ``loc``/``type``/``msg`` (``input`` dropped — see
        # safe_validation_error_detail's docstring for why msg is now safe).
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=safe_validation_error_detail(e),
        )
    except Exception:
        # Any other validation failure (e.g. a schema/migration error) is a
        # client error, never a 500. Stay generic — these messages can embed
        # the input.
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Invalid agent profile",
        )


@agent_profiles_router.post(
    "/{name}",
    response_model=AgentProfileMutationResponse,
    status_code=status.HTTP_201_CREATED,
)
async def save_agent_profile(
    name: ProfileName, body: dict[str, Any]
) -> AgentProfileMutationResponse:
    """Save an ``AgentProfile`` under ``name`` (overwriting a namesake).

    The path ``name`` is authoritative — it overrides any ``name`` in the body.
    The profile is secret-free at rest (#4017), so no cipher/encryption is
    involved. Returns 409 if creating a new profile would exceed
    ``MAX_AGENT_PROFILES``.
    """
    profile = _validate_profile_payload({**body, "name": name})

    store = get_agent_profile_store()
    # The id is server-managed (the active pointer is keyed on it): overwrite
    # keeps the namesake's id and bumps revision; create mints a fresh id,
    # ignoring any client-supplied one. ``save_profile_preserving_identity``
    # holds the store lock across read + mint + save so two concurrent creates
    # of the same new name can't both mint an id and clobber each other.
    try:
        with store_errors():
            save_profile_preserving_identity(
                store, profile, max_profiles=MAX_AGENT_PROFILES
            )
    except ProfileLimitExceeded:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=(
                f"Agent profile limit reached ({MAX_AGENT_PROFILES}). "
                "Delete a profile before saving a new one."
            ),
        )

    logger.info(f"Saved agent profile '{name}'")
    return AgentProfileMutationResponse(
        name=name, message=f"Agent profile '{name}' saved"
    )


@agent_profiles_router.delete("/{name}", response_model=AgentProfileMutationResponse)
async def delete_agent_profile(
    request: Request, name: ProfileName
) -> AgentProfileMutationResponse:
    """Delete a stored profile (idempotent).

    If the deleted profile was the active one, ``default`` becomes active,
    reseeded from the settings when it was the one deleted. If
    ``agent_settings`` is itself left on a non-OpenHands variant, it is first
    reset to default OpenHands agent settings so stale ACP configuration does
    not outlive the profile it came from; the server-wide ``mcp_config`` is
    carried over.
    """
    store = get_agent_profile_store()
    deleted_id = _summary_id_for_name(store, name)

    with store_errors():
        store.delete(name)

    if deleted_id is not None:
        config = get_config(request)
        settings_store = get_settings_store(config)
        settings = settings_store.load() or PersistedSettings()
        if settings.active_agent_profile_id == deleted_id:

            def clear_pointer_and_reset_settings(
                s: PersistedSettings,
            ) -> PersistedSettings:
                s.active_agent_profile_id = None
                # Stale non-OpenHands settings outlive their profile. Reset to
                # a fresh OpenHands base rather than merging across the variant
                # boundary (see _apply_agent_settings_diff), except for
                # ``mcp_config``: it is the server-wide MCP registry every other
                # profile resolves ``mcp_server_refs`` against, not ACP state.
                prior_kind = s.agent_settings.agent_kind
                if prior_kind != "openhands":
                    s.agent_settings = OpenHandsAgentSettings(
                        mcp_config=s.agent_settings.mcp_config
                    )
                    logger.info(
                        f"Reset agent_settings to default "
                        f"(agent_settings was agent_kind='{prior_kind}')"
                    )
                return s

            settings_store.update(clear_pointer_and_reset_settings)
            logger.info(f"Cleared active pointer for deleted profile '{name}'")
            _ensure_active_profile(store, config, get_cipher(request))

    logger.info(f"Deleted agent profile '{name}'")
    return AgentProfileMutationResponse(
        name=name, message=f"Agent profile '{name}' deleted"
    )


@agent_profiles_router.post(
    "/{name}/rename", response_model=AgentProfileMutationResponse
)
async def rename_agent_profile(
    name: ProfileName, body: RenameAgentProfileRequest
) -> AgentProfileMutationResponse:
    """Rename a stored profile atomically.

    The stable ``id`` is preserved, so an active pointer (keyed on ``id``)
    survives the rename untouched. Returns 404 if the source is missing, 409 if
    ``new_name`` is taken.
    """
    store = get_agent_profile_store()
    try:
        with store_errors():
            store.rename(name, body.new_name)
    except FileNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Agent profile '{name}' not found",
        )
    except FileExistsError:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Agent profile '{body.new_name}' already exists",
        )

    if name == body.new_name:
        message = f"Agent profile '{name}' unchanged (same name)"
    else:
        message = f"Agent profile '{name}' renamed to '{body.new_name}'"
    logger.info(message)
    return AgentProfileMutationResponse(name=body.new_name, message=message)


@agent_profiles_router.post(
    "/{profile_id}/activate", response_model=ActivateAgentProfileResponse
)
async def activate_agent_profile(
    request: Request, profile_id: ProfileId
) -> ActivateAgentProfileResponse:
    """Activate a profile by its stable ``id`` — pointer only.

    Sets ``active_agent_profile_id`` and nothing else: unlike the LLM
    ``/activate``, this does **not** write ``agent_settings`` (the
    creation-time-only contract). Returns 404 if no stored profile has that id.
    """
    store = get_agent_profile_store()
    with store_errors():
        known_ids = {
            str(s["id"]) for s in store.list_summaries() if s.get("id") is not None
        }
    if profile_id not in known_ids:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Agent profile with id '{profile_id}' not found",
        )

    config = get_config(request)
    settings_store = get_settings_store(config)

    def set_pointer(settings: PersistedSettings) -> PersistedSettings:
        settings.active_agent_profile_id = profile_id
        return settings

    try:
        settings_store.update(set_pointer)
    except (OSError, PermissionError):
        logger.error("Failed to activate agent profile - file I/O error")
        raise HTTPException(status_code=500, detail="Failed to activate agent profile")
    except RuntimeError as e:
        # A corrupted / mis-keyed settings file is a server-side integrity
        # failure, not a client conflict.
        logger.error(f"Failed to activate agent profile: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to activate agent profile",
        )

    logger.info(f"Activated agent profile id '{profile_id}'")
    return ActivateAgentProfileResponse(
        id=profile_id,
        message=f"Agent profile '{profile_id}' activated",
    )


@agent_profiles_router.post(
    "/{name}/materialize",
    response_model=AgentProfileDiagnostics,
)
async def materialize_agent_profile(
    request: Request,
    name: ProfileName,
    body: MaterializeAgentProfileRequest | None = None,
) -> AgentProfileDiagnostics:
    """Preview the launch of a profile; return a diagnostics report.

    Previews the stored profile ``name``, or ``body.profile`` when given (so an
    editor can preview before saving), with the same resolve and finalize as a
    launch, against the runtime this server launches into. Dangling references
    are reported in the body (valid=False) rather than raising — the only error
    statuses are 404 (unknown stored profile) and 422 (invalid draft).
    resolved_settings is redacted (no raw secrets).
    """
    if body is not None and body.profile is not None:
        profile = _validate_profile_payload({**body.profile, "name": name})
    else:
        store = get_agent_profile_store()
        try:
            with store_errors():
                profile = store.load(name)
        except FileNotFoundError:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Agent profile '{name}' not found",
            )

    config = get_config(request)
    settings = get_settings_store(config).load() or PersistedSettings()
    context = settings.agent_settings.agent_context
    return await asyncio.to_thread(
        lambda: preview_launch(
            profile,
            server_launch_stores(settings, get_cipher(request)),
            target_launch_runtime(config),
            load_memory=context is not None and context.load_memory,
            check_usable=can_probe_tools(config),
        )
    )
