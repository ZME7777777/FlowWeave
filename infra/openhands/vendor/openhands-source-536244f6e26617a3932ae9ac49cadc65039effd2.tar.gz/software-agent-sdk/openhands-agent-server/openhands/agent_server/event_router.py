"""
Local Event router for OpenHands SDK.
"""

import logging
from datetime import datetime
from typing import Annotated, Any, cast

from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
    Query,
    status,
)
from starlette.responses import JSONResponse

from openhands.agent_server.dependencies import get_event_service
from openhands.agent_server.event_service import EventService
from openhands.agent_server.models import (
    ConfirmationResponseRequest,
    EventSortOrder,
    SendMessageRequest,
    Success,
)
from openhands.sdk import Message
from openhands.sdk.conversation.child_commands import ChildCommandResult
from openhands.sdk.event import Event


event_read_router = APIRouter(
    prefix="/conversations/{conversation_id}/events", tags=["Events"]
)
event_write_router = APIRouter(
    prefix="/conversations/{conversation_id}/events", tags=["Events"]
)
logger = logging.getLogger(__name__)


# Read methods


def normalize_datetime_to_server_timezone(dt: datetime) -> datetime:
    """
    Normalize datetime to server timezone for consistent comparison with events.

    Event timestamps are stored as naive datetimes in server local time.
    This function ensures filter datetimes are also naive in server local time
    so they can be compared correctly.

    If the datetime has timezone info, convert to server native timezone and
    strip the tzinfo to make it naive.
    If it's naive (no timezone), assume it's already in server timezone.

    Args:
        dt: Input datetime (may be timezone-aware or naive)

    Returns:
        Naive datetime in server local time
    """
    if dt.tzinfo is not None:
        # Timezone-aware: convert to server native timezone, then make naive
        return dt.astimezone(None).replace(tzinfo=None)
    else:
        # Naive datetime: assume it's already in server timezone
        return dt


@event_read_router.get(
    "/search", responses={404: {"description": "Conversation not found"}}
)
async def search_conversation_events(
    page_id: Annotated[
        str | None,
        Query(title="Optional next_page_id from the previously returned page"),
    ] = None,
    limit: Annotated[
        int,
        Query(title="The max number of results in the page", gt=0, le=100),
    ] = 100,
    kind: Annotated[
        str | None,
        Query(
            title="Optional filter by event kind/type (e.g., ActionEvent, MessageEvent)"
        ),
    ] = None,
    source: Annotated[
        str | None,
        Query(title="Optional filter by event source (e.g., agent, user, environment)"),
    ] = None,
    body: Annotated[
        str | None,
        Query(title="Optional filter by message content (case-insensitive)"),
    ] = None,
    sort_order: Annotated[
        EventSortOrder,
        Query(title="Sort order for events"),
    ] = EventSortOrder.TIMESTAMP,
    timestamp__gte: Annotated[
        datetime | None,
        Query(title="Filter: event timestamp >= this datetime"),
    ] = None,
    timestamp__lt: Annotated[
        datetime | None,
        Query(title="Filter: event timestamp < this datetime"),
    ] = None,
    event_service: EventService = Depends(get_event_service),
) -> JSONResponse:
    """Search / List local events"""

    # Normalize timezone-aware datetimes to server timezone
    normalized_gte = (
        normalize_datetime_to_server_timezone(timestamp__gte)
        if timestamp__gte
        else None
    )
    normalized_lt = (
        normalize_datetime_to_server_timezone(timestamp__lt) if timestamp__lt else None
    )

    page = await event_service.search_events(
        page_id, limit, kind, source, body, sort_order, normalized_gte, normalized_lt
    )
    if isinstance(page, dict):
        items = cast(list[Any], page.get("items", []))
        next_page_id = cast(str | None, page.get("next_page_id"))
    else:
        items = page.items
        next_page_id = page.next_page_id
    return JSONResponse(
        {
            "items": [
                dict(event)
                if isinstance(event, dict)
                else event.model_dump(mode="json", exclude_none=True)
                for event in items
            ],
            "next_page_id": next_page_id,
        }
    )


@event_read_router.get(
    "/count", responses={404: {"description": "Conversation not found"}}
)
async def count_conversation_events(
    kind: Annotated[
        str | None,
        Query(
            title="Optional filter by event kind/type (e.g., ActionEvent, MessageEvent)"
        ),
    ] = None,
    source: Annotated[
        str | None,
        Query(title="Optional filter by event source (e.g., agent, user, environment)"),
    ] = None,
    body: Annotated[
        str | None,
        Query(title="Optional filter by message content (case-insensitive)"),
    ] = None,
    timestamp__gte: Annotated[
        datetime | None,
        Query(title="Filter: event timestamp >= this datetime"),
    ] = None,
    timestamp__lt: Annotated[
        datetime | None,
        Query(title="Filter: event timestamp < this datetime"),
    ] = None,
    event_service: EventService = Depends(get_event_service),
) -> int:
    """Count local events matching the given filters"""
    # Normalize timezone-aware datetimes to server timezone
    normalized_gte = (
        normalize_datetime_to_server_timezone(timestamp__gte)
        if timestamp__gte
        else None
    )
    normalized_lt = (
        normalize_datetime_to_server_timezone(timestamp__lt) if timestamp__lt else None
    )

    count = await event_service.count_events(
        kind, source, body, normalized_gte, normalized_lt
    )

    return count


@event_read_router.get(
    "/{event_id}", responses={404: {"description": "Item not found"}}
)
async def get_conversation_event(
    event_id: str,
    event_service: EventService = Depends(get_event_service),
) -> Event:
    """Get a local event given an id"""
    event = await event_service.get_event(event_id)
    if event is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND)
    return event


@event_read_router.get("")
async def batch_get_conversation_events(
    event_ids: list[str],
    event_service: EventService = Depends(get_event_service),
) -> list[Event | None]:
    """Get a batch of local events given their ids, returning null for any
    missing item."""
    events = await event_service.batch_get_events(event_ids)
    return events


@event_write_router.post(
    "",
    responses={
        409: {"description": "Governed child busy or stable submission required"},
        429: {"description": "Run capacity full; governed child input not admitted"},
    },
)
async def send_message(
    request: SendMessageRequest,
    event_service: EventService = Depends(get_event_service),
) -> Success:
    """Send a message to a conversation.

    For legacy conversations, a run refusal can follow a saved message; retry
    /run instead of resending. Governed children require submission_id and
    run=true, refuse busy/capacity before append, and return the formal event_id.
    Reconcile those retries with the same submission_id.
    """
    message = Message(role=request.role, content=request.content)
    if request.submission_id is None:
        result = await event_service.send_message(message, request.run)
    else:
        result = await event_service.send_message(
            message, request.run, submission_id=request.submission_id
        )
    return Success(
        event_id=result.event_id if isinstance(result, ChildCommandResult) else None
    )


@event_write_router.post(
    "/respond_to_confirmation",
    responses={
        404: {"description": "Item not found"},
        429: {"description": "Server conversation run capacity is full"},
    },
)
async def respond_to_confirmation(
    request: ConfirmationResponseRequest,
    event_service: EventService = Depends(get_event_service),
) -> Success:
    """Accept or reject a pending action in confirmation mode."""
    await event_service.respond_to_confirmation(request)
    return Success()


event_router = APIRouter()
event_router.include_router(event_read_router)
event_router.include_router(event_write_router)
