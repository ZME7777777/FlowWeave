"""Conversation router for OpenHands SDK."""

import asyncio
import json
from typing import Annotated
from uuid import UUID

from fastapi import (
    APIRouter,
    Body,
    Depends,
    Header,
    HTTPException,
    Query,
    Request,
    Response,
    status,
)
from pydantic import TypeAdapter, ValidationError

from openhands.agent_server._secrets_exposure import (
    decrypt_incoming_llm_secrets,
    get_cipher,
    store_errors,
)
from openhands.agent_server.child_commands import ChildCommands
from openhands.agent_server.child_queries import ChildQueries
from openhands.agent_server.conversation_registry import ConversationRegistry
from openhands.agent_server.conversation_service import (
    ConversationService,
    InvalidParentConversation,
    UnavailableAgentTool,
)
from openhands.agent_server.dependencies import get_conversation_service
from openhands.agent_server.event_service import CondensationUnavailable
from openhands.agent_server.launch import launch_http_exception
from openhands.agent_server.models import (
    INCLUDE_SKILLS_PARAM_TITLE,
    AgentResponseResult,
    AskAgentRequest,
    AskAgentResponse,
    ConversationActivityPage,
    ConversationContext,
    ConversationInfo,
    ConversationPage,
    ConversationRuntimeInfo,
    ConversationRuntimeStatus,
    ConversationSortOrder,
    ForkConversationRequest,
    NavigateConversationRequest,
    SetConfirmationPolicyRequest,
    SetSecurityAnalyzerRequest,
    StartChildConversationRequest,
    StartChildConversationResponse,
    StartConversationRequest,
    StartGoalRequest,
    Success,
    UpdateConversationRequest,
    UpdateSecretsRequest,
    trim_conversation_response_skills,
)
from openhands.agent_server.persistence import get_llm_profile_store
from openhands.sdk import LLM
from openhands.sdk.conversation.child_commands import (
    ChildCommandInvocation,
    ChildCommandRequest,
    ChildCommandResult,
)
from openhands.sdk.conversation.child_creation import (
    ChildConversationPreparation,
    ChildConversationPreparationRequest,
    GovernedChildConversationPreparationRequest,
)
from openhands.sdk.conversation.child_launcher import (
    ChildLauncherDenied,
    ChildLauncherInvocation,
    ChildLauncherRequest,
    ChildLauncherResolution,
)
from openhands.sdk.conversation.child_queries import (
    ChildQueryInvocation,
    ChildQueryRequest,
    ChildQueryResult,
)
from openhands.sdk.conversation.state import ConversationExecutionStatus
from openhands.sdk.conversation.types import (
    ConversationObservabilityMetadata,
    ConversationObservabilitySpanName,
    ConversationObservabilityTags,
)
from openhands.sdk.launch import AgentLaunchError, LaunchStoreError
from openhands.sdk.marketplace.registry import (
    MarketplaceNotFoundError,
    PluginNotFoundError,
    PluginResolutionError,
)
from openhands.sdk.plugin import PluginFetchError
from openhands.sdk.profiles.resolver import ProfileNotFound
from openhands.sdk.tool.client_tool import ClientToolRegistrationError


conversation_catalog_router = APIRouter(prefix="/conversations", tags=["Conversations"])
conversation_router = APIRouter(prefix="/conversations", tags=["Conversations"])
_OBSERVABILITY_SPAN_NAME_ADAPTER = TypeAdapter(ConversationObservabilitySpanName)
_OBSERVABILITY_TAGS_ADAPTER = TypeAdapter(ConversationObservabilityTags)
_OBSERVABILITY_METADATA_ADAPTER = TypeAdapter(ConversationObservabilityMetadata)


def _request_with_observability_headers(
    request: StartConversationRequest,
    *,
    span_name: str | None,
    tags: str | None,
    metadata: str | None,
    parent_span_context: str | None,
) -> StartConversationRequest:
    updates: dict[str, object] = {}
    try:
        if span_name and "observability_span_name" not in request.model_fields_set:
            updates["observability_span_name"] = (
                _OBSERVABILITY_SPAN_NAME_ADAPTER.validate_python(span_name)
            )
        if tags and "observability_tags" not in request.model_fields_set:
            tag_values = [tag.strip() for tag in tags.split(",") if tag.strip()]
            updates["observability_tags"] = _OBSERVABILITY_TAGS_ADAPTER.validate_python(
                tag_values
            )
        if metadata:
            metadata_payload = json.loads(metadata)
            header_metadata = _OBSERVABILITY_METADATA_ADAPTER.validate_python(
                metadata_payload
            )
            updates["observability_metadata"] = {
                **header_metadata,
                **request.observability_metadata,
            }
    except json.JSONDecodeError as exc:
        raise HTTPException(
            status_code=422,
            detail="X-OpenHands-Observability-Metadata must be a JSON object",
        ) from exc
    except ValidationError as exc:
        raise HTTPException(
            status_code=422,
            detail=exc.errors(include_context=False),
        ) from exc
    if parent_span_context and not request.observability_parent_span_context:
        updates["observability_parent_span_context"] = parent_span_context
    return request.model_copy(update=updates) if updates else request


# Examples

START_CONVERSATION_EXAMPLES = [
    {
        "agent_settings": {
            "llm": {
                "usage_id": "your-llm-service",
                "model": "your-model-provider/your-model-name",
                "api_key": "your-api-key-here",
            },
        },
        "workspace": {"working_dir": "workspace/project"},
        "initial_message": {
            "role": "user",
            "content": [{"type": "text", "text": "Flip a coin!"}],
        },
    }
]


# Read methods


def _with_runtime_info(
    request: Request, conversation: ConversationInfo
) -> ConversationInfo:
    registry = getattr(request.app.state, "conversation_registry", None)
    if not isinstance(registry, ConversationRegistry):
        return conversation
    return conversation.model_copy(
        update={"runtime_info": registry.runtime_info(conversation.id)}
    )


@conversation_catalog_router.get("/activity", include_in_schema=False)
@conversation_router.get("/activity", response_model=ConversationActivityPage)
async def conversation_activity(
    page_id: Annotated[
        str | None,
        Query(title="Optional next_page_id from the previously returned page"),
    ] = None,
    limit: Annotated[
        int,
        Query(title="The max number of results in the page", gt=0, le=100),
    ] = 100,
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> ConversationActivityPage:
    """Read catalog activity without loading Conversation state or EventLog."""

    return await conversation_service.conversation_activity_page(page_id, limit)


@conversation_catalog_router.get("/search", include_in_schema=False)
@conversation_router.get("/search")
async def search_conversations(
    request: Request,
    page_id: Annotated[
        str | None,
        Query(title="Optional next_page_id from the previously returned page"),
    ] = None,
    limit: Annotated[
        int,
        Query(title="The max number of results in the page", gt=0, le=100),
    ] = 100,
    status: Annotated[
        ConversationExecutionStatus | None,
        Query(title="Optional filter by conversation execution status"),
    ] = None,
    sort_order: Annotated[
        ConversationSortOrder,
        Query(title="Sort order for conversations"),
    ] = ConversationSortOrder.CREATED_AT_DESC,
    include_skills: Annotated[bool, Query(title=INCLUDE_SKILLS_PARAM_TITLE)] = False,
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> ConversationPage:
    """Search / List conversations"""
    page = await conversation_service.search_conversations(
        page_id, limit, status, sort_order
    )
    if not include_skills:
        # ``model_copy`` rather than in-place mutation so we never
        # write back into whatever the upstream service handed us
        # (matters for services that cache their return value,
        # including the ``AsyncMock`` used in route tests).
        page = page.model_copy(
            update={
                "items": [
                    trim_conversation_response_skills(item) for item in page.items
                ]
            }
        )
    page = page.model_copy(
        update={"items": [_with_runtime_info(request, item) for item in page.items]}
    )
    return page


@conversation_catalog_router.get("/count", include_in_schema=False)
@conversation_router.get("/count")
async def count_conversations(
    status: Annotated[
        ConversationExecutionStatus | None,
        Query(title="Optional filter by conversation execution status"),
    ] = None,
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> int:
    """Count conversations matching the given filters"""
    count = await conversation_service.count_conversations(status)
    return count


@conversation_router.get(
    "/{conversation_id}", responses={404: {"description": "Item not found"}}
)
async def get_conversation(
    conversation_id: UUID,
    request: Request,
    include_skills: Annotated[bool, Query(title=INCLUDE_SKILLS_PARAM_TITLE)] = False,
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> ConversationInfo:
    """Given an id, get a conversation"""
    conversation = await conversation_service.get_conversation(conversation_id)
    if conversation is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND)
    if not include_skills:
        conversation = trim_conversation_response_skills(conversation)
    return _with_runtime_info(request, conversation)


@conversation_router.get("/{conversation_id}/runtime")
async def get_local_conversation_runtime(
    conversation_id: UUID,
    request: Request,
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> ConversationRuntimeInfo:
    """Inspect the always-available in-process runtime."""
    if await conversation_service.get_conversation(conversation_id) is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND)
    registry = getattr(request.app.state, "conversation_registry", None)
    if isinstance(registry, ConversationRegistry):
        return registry.runtime_info(conversation_id)
    return ConversationRuntimeInfo(
        runtime_status=ConversationRuntimeStatus.AVAILABLE, can_resume=True
    )


@conversation_router.post("/{conversation_id}/runtime/reprovision")
async def reprovision_local_conversation_runtime(
    conversation_id: UUID,
    request: Request,
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> ConversationRuntimeInfo:
    """Return local runtime state; local mode has no infrastructure to provision."""
    return await get_local_conversation_runtime(
        conversation_id, request, conversation_service
    )


@conversation_router.get(
    "/{conversation_id}/context",
    responses={404: {"description": "Conversation not found"}},
)
async def get_conversation_context(
    conversation_id: UUID,
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> ConversationContext:
    """Get metrics for a conversation's current active view."""
    event_service = await conversation_service.get_event_service(conversation_id)
    if event_service is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND)
    total_tokens, event_count = await event_service.get_view_context()
    return ConversationContext(total_tokens=total_tokens, event_count=event_count)


@conversation_router.get(
    "/{conversation_id}/agent_final_response",
    responses={404: {"description": "Conversation not found"}},
)
async def get_conversation_agent_final_response(
    conversation_id: UUID,
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> AgentResponseResult:
    """Get the agent's final response for a conversation.

    Returns the text of the last agent finish message (FinishAction) or
    the last agent text response (MessageEvent). Returns an empty string
    if the agent has not produced a final response yet.
    """
    event_service = await conversation_service.get_event_service(conversation_id)
    if event_service is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND)
    response = await event_service.get_agent_final_response()
    return AgentResponseResult(response=response)


@conversation_router.get("")
async def batch_get_conversations(
    request: Request,
    ids: Annotated[list[UUID], Query(max_length=99)],
    include_skills: Annotated[bool, Query(title=INCLUDE_SKILLS_PARAM_TITLE)] = False,
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> list[ConversationInfo | None]:
    """Get a batch of up to 99 conversations given their ids, returning null
    for any missing item"""
    conversations = await conversation_service.batch_get_conversations(ids)
    conversations = [
        _with_runtime_info(request, conversation) if conversation is not None else None
        for conversation in conversations
    ]
    if not include_skills:
        return [
            trim_conversation_response_skills(c) if c is not None else None
            for c in conversations
        ]
    return conversations


# Write Methods


@conversation_router.post(
    "", responses={429: {"description": "Server conversation run capacity is full"}}
)
async def start_conversation(
    request: Annotated[
        StartConversationRequest, Body(examples=START_CONVERSATION_EXAMPLES)
    ],
    response: Response,
    include_skills: Annotated[bool, Query(title=INCLUDE_SKILLS_PARAM_TITLE)] = False,
    x_openhands_observability_span_name: Annotated[
        str | None, Header(alias="X-OpenHands-Observability-Span-Name")
    ] = None,
    x_openhands_observability_tags: Annotated[
        str | None, Header(alias="X-OpenHands-Observability-Tags")
    ] = None,
    x_openhands_observability_metadata: Annotated[
        str | None, Header(alias="X-OpenHands-Observability-Metadata")
    ] = None,
    x_openhands_observability_parent_span_context: Annotated[
        str | None, Header(alias="X-OpenHands-Observability-Parent-Span-Context")
    ] = None,
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> ConversationInfo:
    """Start a conversation in the local environment."""
    if request.conversation_runtime not in (None, "local"):
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="This server only runs local conversations",
        )
    request = _request_with_observability_headers(
        request,
        span_name=x_openhands_observability_span_name,
        tags=x_openhands_observability_tags,
        metadata=x_openhands_observability_metadata,
        parent_span_context=x_openhands_observability_parent_span_context,
    )
    try:
        info, is_new = await conversation_service.start_conversation(request)
    except (ProfileNotFound, AgentLaunchError, LaunchStoreError) as e:
        raise launch_http_exception(e) from e
    except ClientToolRegistrationError as e:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e)
        ) from e
    except (InvalidParentConversation, UnavailableAgentTool) as e:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(e)
        ) from e
    response.status_code = status.HTTP_201_CREATED if is_new else status.HTTP_200_OK
    if not include_skills:
        info = trim_conversation_response_skills(info)
    return info


@conversation_router.post(
    "/{conversation_id}/pause", responses={404: {"description": "Item not found"}}
)
async def pause_conversation(
    conversation_id: UUID,
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> Success:
    """Pause a conversation, allowing it to be resumed later."""
    paused = await conversation_service.pause_conversation(conversation_id)
    if not paused:
        raise HTTPException(status.HTTP_404_NOT_FOUND)
    return Success()


@conversation_router.post(
    "/{conversation_id}/interrupt",
    responses={404: {"description": "Item not found"}},
)
async def interrupt_conversation(
    conversation_id: UUID,
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> Success:
    """Immediately interrupt a running conversation.

    Unlike ``/pause``, which waits for the current LLM call to finish,
    ``/interrupt`` cancels the in-flight request so the effect is instant.
    The conversation transitions to *paused* and can be resumed later.
    """
    interrupted = await conversation_service.interrupt_conversation(conversation_id)
    if not interrupted:
        raise HTTPException(status.HTTP_404_NOT_FOUND)
    return Success()


@conversation_router.delete(
    "/{conversation_id}", responses={404: {"description": "Item not found"}}
)
async def delete_conversation(
    conversation_id: UUID,
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> Success:
    """Permanently delete a conversation."""
    deleted = await conversation_service.delete_conversation(conversation_id)
    if not deleted:
        raise HTTPException(status.HTTP_404_NOT_FOUND)
    return Success()


@conversation_router.post(
    "/{conversation_id}/run",
    responses={
        404: {"description": "Item not found"},
        409: {"description": "Conversation is already running"},
        429: {"description": "Server conversation run capacity is full"},
    },
)
async def run_conversation(
    conversation_id: UUID,
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> Success:
    """Start running the conversation in the background."""
    event_service = await conversation_service.get_event_service(conversation_id)
    if event_service is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND)

    try:
        await event_service.run()
    except ValueError as e:
        if str(e) == "conversation_already_running":
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=(
                    "Conversation already running. Wait for completion or pause first."
                ),
            )
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

    return Success()


@conversation_router.post(
    "/{conversation_id}/goal",
    responses={
        404: {"description": "Item not found"},
        409: {"description": "Conversation run or goal loop is already running"},
        429: {"description": "Server conversation run capacity is full"},
    },
)
async def start_goal_in_conversation(
    conversation_id: UUID,
    request: StartGoalRequest,
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> Success:
    """Start a ``/goal`` loop inside an existing conversation.

    The loop appends messages and starts agent runs in the same conversation
    history and event stream as the main chat. It does not create a separate
    conversation for the goal or fork the existing one.
    """
    event_service = await conversation_service.get_event_service(conversation_id)
    if event_service is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND)

    try:
        await event_service.start_goal_loop(
            request.objective, max_iterations=request.max_iterations
        )
    except ValueError as e:
        message = str(e)
        if message in ("conversation_already_running", "goal_already_running"):
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Conversation run or goal loop already running.",
            )
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=message)

    return Success()


@conversation_router.post(
    "/{conversation_id}/goal/stop",
    responses={404: {"description": "Item not found"}},
)
async def stop_goal_in_conversation(
    conversation_id: UUID,
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> Success:
    """Stop the active ``/goal`` loop inside this conversation.

    This cancels only the background goal loop, not the conversation itself, and
    records an ``interrupted`` goal status so ``/goal/resume`` can continue it.
    """
    event_service = await conversation_service.get_event_service(conversation_id)
    if event_service is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND)
    await event_service.stop_goal_loop()
    return Success()


@conversation_router.post(
    "/{conversation_id}/goal/resume",
    responses={
        404: {"description": "Item not found"},
        409: {"description": "Conversation run or goal loop is already running"},
        429: {"description": "Server conversation run capacity is full"},
    },
)
async def resume_goal_in_conversation(
    conversation_id: UUID,
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> Success:
    """Resume the last interrupted ``/goal`` loop inside this conversation."""
    event_service = await conversation_service.get_event_service(conversation_id)
    if event_service is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND)

    try:
        await event_service.resume_goal_loop()
    except ValueError as e:
        message = str(e)
        if message in ("conversation_already_running", "goal_already_running"):
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Conversation run or goal loop already running.",
            )
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=message)

    return Success()


@conversation_router.post(
    "/{conversation_id}/secrets", responses={404: {"description": "Item not found"}}
)
async def update_conversation_secrets(
    conversation_id: UUID,
    request: UpdateSecretsRequest,
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> Success:
    """Update secrets for a conversation."""
    event_service = await conversation_service.get_event_service(conversation_id)
    if event_service is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND)
    # Strings are valid SecretValue (SecretValue = str | SecretProvider)
    from typing import cast

    from openhands.sdk.conversation.secret_registry import SecretValue

    secrets = cast(dict[str, SecretValue], request.secrets)
    await event_service.update_secrets(secrets)
    return Success()


@conversation_router.post(
    "/{conversation_id}/confirmation_policy",
    responses={404: {"description": "Item not found"}},
)
async def set_conversation_confirmation_policy(
    conversation_id: UUID,
    request: SetConfirmationPolicyRequest,
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> Success:
    """Set the confirmation policy for a conversation."""
    event_service = await conversation_service.get_event_service(conversation_id)
    if event_service is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND)
    await event_service.set_confirmation_policy(request.policy)
    return Success()


@conversation_router.post(
    "/{conversation_id}/security_analyzer",
    responses={404: {"description": "Item not found"}},
)
async def set_conversation_security_analyzer(
    conversation_id: UUID,
    request: SetSecurityAnalyzerRequest,
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> Success:
    """Set the security analyzer for a conversation."""
    event_service = await conversation_service.get_event_service(conversation_id)
    if event_service is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND)
    await event_service.set_security_analyzer(request.security_analyzer)
    return Success()


@conversation_router.post(
    "/{conversation_id}/switch_profile",
    responses={
        400: {"description": "Invalid or corrupted profile"},
        404: {"description": "Conversation or profile not found"},
    },
)
async def switch_conversation_profile(
    conversation_id: UUID,
    profile_name: str = Body(..., embed=True),
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> Success:
    """Switch the conversation's LLM profile to a named profile."""
    event_service = await conversation_service.get_event_service(conversation_id)
    if event_service is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND)
    conversation = event_service.get_conversation()
    try:
        conversation.switch_profile(profile_name)
    except FileNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Profile '{profile_name}' not found",
        )
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )
    return Success()


@conversation_router.post(
    "/{conversation_id}/switch_llm",
    responses={404: {"description": "Conversation not found"}},
)
async def switch_conversation_llm(
    request: Request,
    conversation_id: UUID,
    llm: LLM = Body(..., embed=True),  # noqa: B008
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> Success:
    """Swap the conversation's LLM to a caller-supplied object.

    Used by app-servers that own the LLM directly and don't push profiles
    to the agent-server's filesystem (see #3017), and by the frontend's
    per-conversation model switch, which forwards a profile config that may
    reference a saved provider connection by id instead of carrying an inline
    API key.
    """
    event_service = await conversation_service.get_event_service(conversation_id)
    if event_service is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND)
    conversation = event_service.get_conversation()
    cipher = get_cipher(request)
    if cipher is not None:
        llm = decrypt_incoming_llm_secrets(llm, cipher)
    # Resolve a referenced provider connection before installing the LLM, so a
    # profile linked to a shared connection runs with its api_key / base_url
    # instead of a keyless config (mirrors LLMProfileStore.load). A dangling
    # reference or missing credential surfaces as 422 before the working LLM
    # is replaced. Inline-key configs without a provider_connection_id are
    # byte-identical to the old path.
    with store_errors():
        llm = get_llm_profile_store().resolve_provider_connection(llm, cipher=cipher)
    conversation.switch_llm(llm)
    return Success()


@conversation_router.post(
    "/{conversation_id}/load_plugin",
    responses={
        400: {"description": "Invalid plugin reference or inactive conversation"},
        404: {"description": "Conversation or plugin not found"},
    },
)
async def load_conversation_plugin(
    conversation_id: UUID,
    plugin_ref: str = Body(..., embed=True),
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> Success:
    """Load a plugin from the conversation's registered marketplaces."""
    event_service = await conversation_service.get_event_service(conversation_id)
    if event_service is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND)
    try:
        await event_service.load_plugin(plugin_ref)
    except (PluginNotFoundError, MarketplaceNotFoundError) as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e),
        )
    except (
        PluginResolutionError,
        PluginFetchError,
        FileNotFoundError,
        ValueError,
    ) as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )
    return Success()


@conversation_router.post(
    "/{conversation_id}/switch_acp_model",
    responses={
        400: {"description": "Agent is not ACP, or provider can't switch models"},
        404: {"description": "Conversation not found"},
        504: {"description": "ACP server did not answer the model switch in time"},
    },
)
async def switch_conversation_acp_model(
    conversation_id: UUID,
    model: str = Body(..., embed=True),
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> Success:
    """Switch the model of an ACP conversation.

    For a conversation that has already started, issues a protocol-level
    ``session/set_model`` call to the ACP subprocess so the new model applies to
    subsequent turns without losing context. For one created but not yet run,
    the value is persisted and applied when the first session starts (returns
    ``200`` either way). Only valid for ACP conversations whose provider
    supports model switching.
    """
    event_service = await conversation_service.get_event_service(conversation_id)
    if event_service is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND)
    try:
        await event_service.switch_acp_model(model)
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )
    except TimeoutError as e:
        # The bounded session/set_model round-trip expired. The ACP server is
        # wedged/slow rather than rejecting the request, so surface a 504
        # instead of an opaque 500.
        raise HTTPException(
            status_code=status.HTTP_504_GATEWAY_TIMEOUT,
            detail=str(e),
        )
    return Success()


@conversation_router.patch(
    "/{conversation_id}", responses={404: {"description": "Item not found"}}
)
async def update_conversation(
    conversation_id: UUID,
    request: UpdateConversationRequest,
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> Success:
    """Update conversation metadata.

    This endpoint allows updating conversation details like title.
    """
    updated = await conversation_service.update_conversation(conversation_id, request)
    if not updated:
        raise HTTPException(status.HTTP_404_NOT_FOUND)
    return Success()


@conversation_router.post(
    "/{conversation_id}/ask_agent",
    responses={404: {"description": "Item not found"}},
)
async def ask_agent(
    conversation_id: UUID,
    request: AskAgentRequest,
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> AskAgentResponse:
    """Ask the agent a simple question without affecting conversation state."""
    response = await conversation_service.ask_agent(conversation_id, request.question)
    if response is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, detail="Conversation not found")
    return AskAgentResponse(response=response)


@conversation_router.post(
    "/{conversation_id}/condense",
    responses={
        404: {"description": "Item not found"},
        409: {"description": "The agent has no condenser that handles requests"},
    },
)
async def condense_conversation(
    conversation_id: UUID,
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> Success:
    """Force condensation of the conversation history."""
    try:
        success = await conversation_service.condense(conversation_id)
    except CondensationUnavailable as exc:
        raise HTTPException(status.HTTP_409_CONFLICT, detail=str(exc)) from exc
    if not success:
        raise HTTPException(status.HTTP_404_NOT_FOUND, detail="Conversation not found")
    return Success()


@conversation_router.post(
    "/{conversation_id}/fork",
    responses={
        201: {"description": "Forked conversation created"},
        404: {"description": "Source conversation not found"},
        409: {"description": "Fork ID already in use"},
    },
    status_code=status.HTTP_201_CREATED,
)
async def fork_conversation(
    conversation_id: UUID,
    request: Annotated[ForkConversationRequest, Body()] = ForkConversationRequest(),  # noqa: B008
    include_skills: Annotated[bool, Query(title=INCLUDE_SKILLS_PARAM_TITLE)] = False,
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> ConversationInfo:
    """Fork a conversation, deep-copying its event history.

    The fork starts in ``idle`` status with a fresh event loop.
    Calling ``run`` on the fork resumes from the copied state, meaning
    the agent has full event memory of the source conversation.
    """
    try:
        info = await conversation_service.fork_conversation(
            conversation_id,
            fork_id=request.id,
            title=request.title,
            tags=request.tags if request.tags is not None else None,
            reset_metrics=request.reset_metrics,
            from_event_id=request.from_event_id,
        )
    except ValueError as exc:
        if "already exists" in str(exc):
            raise HTTPException(status.HTTP_409_CONFLICT, detail=str(exc)) from exc
        # An unknown ``from_event_id`` is a bad request against an existing
        # source conversation, not a missing conversation.
        if "from_event_id" in str(exc):
            raise HTTPException(status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
        raise
    if info is None:
        raise HTTPException(
            status.HTTP_404_NOT_FOUND,
            detail="Source conversation not found",
        )
    if not include_skills:
        info = trim_conversation_response_skills(info)
    return info


@conversation_router.post(
    "/{conversation_id}/children/commands/verify",
    responses={403: {"description": "Native child command denied"}},
)
async def verify_child_command(
    conversation_id: UUID,
    request: ChildCommandRequest,
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> ChildCommandInvocation:
    """Verify native command provenance; deployments separately authorize scope."""
    return await ChildCommands(conversation_service).verify(conversation_id, request)


@conversation_router.post(
    "/{conversation_id}/children/commands",
    responses={
        403: {"description": "Child command denied"},
        409: {"description": "Child busy or invocation conflict"},
        429: {"description": "Runtime run capacity full; input not admitted"},
    },
)
async def execute_child_command(
    conversation_id: UUID,
    request: ChildCommandRequest,
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> ChildCommandResult:
    """Deliver or interrupt a direct child using its native admission lifecycle."""
    return await ChildCommands(conversation_service).execute(conversation_id, request)


@conversation_router.post(
    "/{conversation_id}/children/queries/verify",
    responses={403: {"description": "Native child query denied"}},
)
async def verify_child_query(
    conversation_id: UUID,
    request: ChildQueryRequest,
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> ChildQueryInvocation:
    """Verify native provenance; the deployment must separately authorize scope."""
    return await ChildQueries(conversation_service).verify(conversation_id, request)


@conversation_router.post(
    "/{conversation_id}/children/queries",
    responses={
        403: {"description": "Child query denied"},
        409: {"description": "Child head/cursor changed; restart reading"},
    },
)
async def query_child_conversations(
    conversation_id: UUID,
    request: ChildQueryRequest,
    http_request: Request,
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> ChildQueryResult:
    """Read native direct children or wait up to 30 seconds without running them."""

    query = asyncio.create_task(
        ChildQueries(conversation_service).execute(conversation_id, request)
    )
    try:
        while True:
            done, _ = await asyncio.wait({query}, timeout=0.05)
            if query in done:
                return await query
            disconnected = await http_request.is_disconnected()
            current = asyncio.current_task()
            if current is not None and current.cancelling():
                raise asyncio.CancelledError
            if disconnected:
                raise HTTPException(status_code=499, detail="Child query cancelled")
    finally:
        query.cancel()
        await asyncio.gather(query, return_exceptions=True)


@conversation_router.post(
    "/{conversation_id}/children/launcher/verify",
    responses={403: {"description": "Native launcher invocation denied"}},
)
async def verify_child_launcher(
    conversation_id: UUID,
    request: ChildLauncherRequest,
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> ChildLauncherInvocation:
    """Verify native provenance; deployments must also authorize scope and generation.

    This does not reserve capacity, create a child, or authorize a platform user.
    Runtime API credentials alone cannot produce a valid native proof.
    """
    return await conversation_service.verify_child_launcher(conversation_id, request)


@conversation_router.post(
    "/{conversation_id}/children/launcher/resolve",
    responses={403: {"description": "Native launcher invocation denied"}},
)
async def resolve_child_launcher(
    conversation_id: UUID,
    request: ChildLauncherRequest,
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> ChildLauncherResolution:
    """Expose the exact native creation identity; this is not a user grant."""
    invocation = await conversation_service.verify_child_launcher(
        conversation_id, request
    )
    return ChildLauncherResolution.from_invocation(invocation)


@conversation_router.post(
    "/{conversation_id}/children/preparations/{creation_id}/governed",
    status_code=201,
    responses={
        404: {"description": "Parent not found"},
        409: {"description": "Governance or creation conflict"},
        429: {"description": "Run capacity full"},
    },
)
async def prepare_governed_child_conversation(
    conversation_id: UUID,
    creation_id: UUID,
    request: GovernedChildConversationPreparationRequest,
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> ChildConversationPreparation:
    """Freeze credential isolation before initializing the inert child.

    Session authentication and native parent policy still apply. Deployment user
    authorization and binding reservation are the caller's responsibility.
    """
    result = await conversation_service.prepare_child_conversation(
        conversation_id,
        creation_id,
        request.to_child_request(),
        launcher_token=request.launcher_token,
        overrides=request.overrides,
    )
    if result is None:
        raise HTTPException(404, "Parent conversation not found")
    return result


@conversation_router.post(
    "/{conversation_id}/children/preparations/{creation_id}",
    status_code=201,
    responses={
        404: {"description": "Parent not found"},
        409: {"description": "Creation conflict"},
        429: {"description": "Run capacity full"},
    },
)
async def prepare_child_conversation(
    conversation_id: UUID,
    creation_id: UUID,
    request: ChildConversationPreparationRequest,
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> ChildConversationPreparation:
    """Prepare an inert shared child; retry with the same creation identity."""
    result = await conversation_service.prepare_child_conversation(
        conversation_id,
        creation_id,
        request.to_child_request(),
        launcher_token=request.launcher_token,
    )
    if result is None:
        raise HTTPException(404, "Parent conversation not found")
    return result


@conversation_router.get(
    "/{conversation_id}/children/preparations/{creation_id}",
    responses={
        404: {"description": "Creation not found"},
        409: {"description": "Creation conflict"},
    },
)
async def get_child_preparation(
    conversation_id: UUID,
    creation_id: UUID,
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> ChildConversationPreparation:
    """Reconcile a creation outcome without replaying task text or running work."""
    result = await conversation_service.get_child_preparation(
        conversation_id, creation_id
    )
    if result is None:
        raise HTTPException(404, "Child creation not found")
    return result


@conversation_router.post(
    "/{conversation_id}/children/preparations/{creation_id}/release",
    responses={
        404: {"description": "Creation not found"},
        409: {"description": "Creation conflict"},
        429: {"description": "Run capacity full"},
    },
)
async def release_child_conversation(
    conversation_id: UUID,
    creation_id: UUID,
    request: ChildConversationPreparationRequest,
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> ChildConversationPreparation:
    """Deployment-controlled release after binding and credentials are governed.

    A creation ID is an idempotency identity, not authorization. Deployments must
    protect this route with their runtime credentials and launcher policy.
    """
    result = await conversation_service.release_child_conversation(
        conversation_id,
        creation_id,
        request.to_child_request(),
        launcher_token=request.launcher_token,
    )
    if result is None:
        raise HTTPException(404, "Child creation not found")
    return result


@conversation_router.post(
    "/{conversation_id}/children",
    responses={
        201: {"description": "Child conversation created"},
        404: {"description": "Parent conversation not found"},
        429: {"description": "Server conversation run capacity is full"},
    },
    status_code=status.HTTP_201_CREATED,
)
async def start_child_conversation(
    conversation_id: UUID,
    request: Annotated[StartChildConversationRequest, Body()],
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> StartChildConversationResponse:
    """Start a child conversation of ``conversation_id`` on this server.

    The child inherits the parent's configuration and workspace (optionally
    isolated in a git worktree), is linked via ``parent_conversation_id`` and
    receives ``task`` as its first user message. This is the default launcher
    behind the ``start_child_conversation`` tool.
    """
    try:
        result = await conversation_service.start_child_conversation(
            conversation_id, request
        )
    except ChildLauncherDenied:
        raise
    except ValueError as exc:
        raise HTTPException(
            status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(exc)
        ) from exc
    if result is None:
        raise HTTPException(
            status.HTTP_404_NOT_FOUND, detail="Parent conversation not found"
        )
    return result


@conversation_router.post(
    "/{conversation_id}/navigate",
    responses={
        404: {"description": "Conversation or event not found"},
    },
)
async def navigate_conversation(
    conversation_id: UUID,
    request: Annotated[NavigateConversationRequest, Body()],
    include_skills: Annotated[bool, Query(title=INCLUDE_SKILLS_PARAM_TITLE)] = False,
    conversation_service: ConversationService = Depends(get_conversation_service),
) -> ConversationInfo:
    """Move a conversation's HEAD to an existing event, re-rooting the branch.

    All branches stay on disk; only the active branch the agent runs on next
    changes. Unlike ``fork``, no new conversation is created. Returns the
    updated conversation info (carrying the new ``leaf_event_id``).
    """
    try:
        info = await conversation_service.navigate_conversation(
            conversation_id, event_id=request.event_id
        )
    except ValueError as exc:
        # An unknown ``event_id`` against an existing conversation is a 404;
        # other ValueErrors (e.g. inactive_service) are genuine server errors.
        if "event_id" in str(exc):
            raise HTTPException(status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
        raise
    if info is None:
        raise HTTPException(
            status.HTTP_404_NOT_FOUND,
            detail="Conversation not found",
        )
    if not include_skills:
        info = trim_conversation_response_skills(info)
    return info
