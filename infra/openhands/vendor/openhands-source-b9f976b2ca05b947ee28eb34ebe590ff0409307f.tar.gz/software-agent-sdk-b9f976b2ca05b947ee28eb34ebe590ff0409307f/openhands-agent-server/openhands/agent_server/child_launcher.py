"""Native authorization and admission for deployment-governed child launchers."""

import json
import os
from typing import TYPE_CHECKING

from openhands.agent_server.child_creation_store import ChildCreationReceiptCorrupt
from openhands.agent_server.event_service import ConversationRunLimitExceeded
from openhands.sdk.conversation.child_creation import ChildConversationCreationReceipt
from openhands.sdk.conversation.child_launcher import (
    GOVERNED_CHILD_TOOL,
    ChildLauncherDenied,
    ChildLauncherInvocation,
    ChildLauncherPolicy,
    ChildLauncherRequest,
    verify_child_launcher_proof,
)
from openhands.sdk.conversation.state import ConversationExecutionStatus
from openhands.sdk.event import ActionEvent
from openhands.sdk.utils import utc_now


if TYPE_CHECKING:
    from openhands.agent_server.conversation_service import ConversationService
    from openhands.agent_server.event_service import EventService
    from openhands.sdk.conversation.state import ConversationState


def launcher_config(
    state: "ConversationState",
) -> tuple[ChildLauncherPolicy, str] | None:
    tools = [tool for tool in state.agent.tools if tool.name == GOVERNED_CHILD_TOOL]
    if not tools:
        return None
    if len(tools) != 1:
        raise ChildLauncherDenied("Exactly one governed launcher is required")
    try:
        policy = ChildLauncherPolicy.model_validate(tools[0].params["policy"])
        audience = tools[0].params["launch_url"]
        if not isinstance(audience, str) or not audience:
            raise ValueError("Invalid launcher audience")
    except (ValueError, KeyError, TypeError):
        raise ChildLauncherDenied("Invalid frozen launcher configuration") from None
    return policy, audience


async def verify_launcher(
    service: "ConversationService",
    parent: "EventService",
    request: ChildLauncherRequest,
) -> ChildLauncherInvocation:
    parent_id = parent.stored.id
    if parent.stored.parent_conversation_id is not None or (
        parent.stored.child_launcher_invocation is not None
    ):
        raise ChildLauncherDenied("Child conversations cannot launch grandchildren")
    state = await parent.get_state()
    cipher = service._cipher_for(parent_id)
    runtime_keys = {service.session_api_key} | {
        value
        for name, value in os.environ.items()
        if name == "SESSION_API_KEY" or name.startswith("OH_SESSION_API_KEYS_")
    }
    if cipher is None or runtime_keys.intersection(
        {cipher.secret_key, *cipher.previous_keys}
    ):
        raise ChildLauncherDenied(
            "Launcher requires a cipher independent of runtime keys"
        )
    invocation = verify_child_launcher_proof(request, cipher, allow_expired=True)
    identity = invocation.policy.parent_conversation_id
    if identity != parent_id:
        raise ChildLauncherDenied("Launcher parent identity mismatch")

    def check_native() -> None:
        # Native tool callers hold the run lock while awaiting this endpoint.
        # Read immutable formal events and the frozen agent config without it.
        config = launcher_config(state)
        if config != (invocation.policy, invocation.audience):
            raise ChildLauncherDenied("Launcher scope or audience changed")
        if invocation.action_id not in state.events:
            raise ChildLauncherDenied("Native launcher action is missing")
        event = state.events[state.events.get_index(invocation.action_id)]
        if (
            not isinstance(event, ActionEvent)
            or event.tool_name != GOVERNED_CHILD_TOOL
            or event.tool_call_id != invocation.tool_call_id
            or event.tool_call.id != invocation.tool_call_id
            or event.action is None
        ):
            raise ChildLauncherDenied("Matching native launcher action is required")
        arguments = json.loads(event.tool_call.arguments)
        if (
            arguments.get("task") != request.task
            or arguments.get("title") != request.title
        ):
            raise ChildLauncherDenied("Native launcher task changed")
        head = state.leaf_event_id
        seen: set[str] = set()
        while head is not None and head != event.id:
            if head in seen or head not in state.events:
                raise ChildLauncherDenied("Invalid native event ancestry")
            seen.add(head)
            head = state.events[state.events.get_index(head)].parent_id
        if head is None:
            raise ChildLauncherDenied("Launcher action is outside the current branch")

    await service._run_lifecycle(check_native)
    if invocation.expires_at <= utc_now():
        preparation = await service.get_child_preparation(
            parent_id, invocation.creation_id
        )
        if preparation is None:
            raise ChildLauncherDenied("Child launcher proof expired before admission")
    return invocation


async def check_child_capacity(
    service: "ConversationService", invocation: ChildLauncherInvocation
) -> None:
    """Called under the parent lifecycle and cross-process admission locks."""
    parent_id = invocation.policy.parent_conversation_id
    if (
        await service.get_child_preparation(parent_id, invocation.creation_id)
        is not None
    ):
        return

    def receipts() -> list[ChildConversationCreationReceipt]:
        result = []
        for path in service._child_creation_store().directory.glob("*.json"):
            try:
                receipt = ChildConversationCreationReceipt.model_validate_json(
                    path.read_text()
                )
            except ValueError:
                raise ChildCreationReceiptCorrupt(
                    "Invalid child admission receipt"
                ) from None
            if receipt.identity.parent_conversation_id == parent_id:
                result.append(receipt)
        return result

    active = 0
    for receipt in await service._run_lifecycle(receipts):
        child_id = receipt.identity.conversation_id
        deleted = service._child_creation_store().directory / f"{child_id.hex}.deleted"
        if await service._run_lifecycle(deleted.exists):
            # Only a fully removed native conversation releases its admission.
            child_dir = service.conversations_dir / child_id.hex
            if not await service._run_lifecycle(child_dir.exists):
                continue
            active += 1
            continue
        preparation = await service.get_child_preparation(
            parent_id, receipt.identity.creation_id
        )
        if preparation is None or preparation.phase != "started":
            active += 1
            continue
        live = (
            service._event_services.get(child_id) if service._event_services else None
        )
        if (
            live is not None
            and live._run_task is not None
            and not live._run_task.done()
        ):
            active += 1
            continue
        state = (
            await live.get_state()
            if live is not None
            else await service._run_lifecycle(
                service._load_persisted_state_sync, child_id
            )
        )
        if state is None:
            active += 1
            continue

        def is_active() -> bool:
            assert state is not None
            with state:
                return state.execution_status in {
                    ConversationExecutionStatus.IDLE,
                    ConversationExecutionStatus.RUNNING,
                    ConversationExecutionStatus.WAITING_FOR_CONFIRMATION,
                }

        if await service._run_lifecycle(is_active):
            active += 1
    if active >= invocation.policy.max_active_children:
        raise ConversationRunLimitExceeded("Parent child-conversation capacity is full")
