from collections.abc import Sequence

from openhands.sdk.context.view.manipulation_indices import ManipulationIndices
from openhands.sdk.context.view.properties.base import ViewPropertyBase
from openhands.sdk.event import (
    ActionEvent,
    Event,
    EventID,
    LLMConvertibleEvent,
    MessageEvent,
    ObservationBaseEvent,
    ToolCallID,
)


class ToolCallMatchingProperty(ViewPropertyBase):
    """Actions and observations must be paired.

    The view that eventually gets serialized for the LLM should contain exactly
    one observation-like event for each action ``tool_call_id``. Some providers
    (for example Anthropic tool use) require every ``tool_use`` to have one
    corresponding ``tool_result`` in the immediately following user message, so
    duplicate observation-like events are not safe to silently tolerate.
    """

    def enforce(
        self,
        current_view_events: list[LLMConvertibleEvent],
        all_events: Sequence[Event],  # noqa: ARG002
    ) -> set[EventID]:
        """Enforce tool-call matching by removing actions without matching observations,
        and vice versa.
        """
        # Start by collecting all tool call IDs associated with actions and observations
        # separately.
        action_tool_call_ids: set[ToolCallID] = set()
        observation_tool_call_ids: set[ToolCallID] = set()

        for event in current_view_events:
            match event:
                case ActionEvent():
                    action_tool_call_ids.add(event.tool_call_id)
                case ObservationBaseEvent():
                    observation_tool_call_ids.add(event.tool_call_id)

        # If an action event has a tool call ID that doesn't appear in any observation,
        # we need to remove it. Likewise, if an observation has a tool call ID that is
        # not in any action event, we need to remove it.
        events_to_remove: set[EventID] = set()

        for event in current_view_events:
            match event:
                case ActionEvent():
                    if event.tool_call_id not in observation_tool_call_ids:
                        events_to_remove.add(event.id)
                case ObservationBaseEvent():
                    if event.tool_call_id not in action_tool_call_ids:
                        events_to_remove.add(event.id)

        # A tool result is only valid in the same uninterrupted tool turn as
        # the corresponding function call.  Historical crash recovery from an
        # older runtime could execute a leftover action after a new user
        # message, leaving ``function_call_output`` behind that message.  The
        # provider rightfully rejects that shape even though the IDs match.
        # Remove the malformed pair from the LLM view (not the durable event
        # log) so the model can issue a fresh call with a new ID.
        action_positions = {
            event.tool_call_id: index
            for index, event in enumerate(current_view_events)
            if isinstance(event, ActionEvent)
        }
        for observation_index, event in enumerate(current_view_events):
            if not isinstance(event, ObservationBaseEvent):
                continue
            action_index = action_positions.get(event.tool_call_id)
            if action_index is None or action_index >= observation_index:
                continue
            if any(
                isinstance(candidate, MessageEvent)
                for candidate in current_view_events[
                    action_index + 1 : observation_index
                ]
            ):
                events_to_remove.update(
                    (current_view_events[action_index].id, event.id)
                )

        return events_to_remove

    def manipulation_indices(
        self,
        current_view_events: list[LLMConvertibleEvent],
    ) -> ManipulationIndices:
        """Calculate manipulation indices for tool call matching.

        Indices between an action and its matching observation are protected.
        Observation-like events without a pending action do not affect boundaries;
        property enforcement separately removes orphaned and duplicate observations.
        """
        # Start with a complete set of manipulation indices, then we'll remove those
        # between actions and their paired observations.
        manipulation_indices: ManipulationIndices = ManipulationIndices.complete(
            current_view_events
        )

        # Actions always come before observations, so we can maintain a set of pending
        # tool calls -- these are any tool calls that have been introduced by an action
        # but not yet resolved by an observation. If there are any pending tool calls we
        # know we're between an action/observation pair.
        pending_tool_call_ids: set[ToolCallID] = set()

        for index, event in enumerate(current_view_events):
            match event:
                case ActionEvent():
                    pending_tool_call_ids.add(event.tool_call_id)
                case ObservationBaseEvent():
                    pending_tool_call_ids.discard(event.tool_call_id)

            if pending_tool_call_ids:
                # The enumeration index corresponds to the position of the event, but we
                # want the index just after.
                manipulation_indices.remove(index + 1)

        return manipulation_indices
