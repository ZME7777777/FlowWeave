# Governed child conversation preparation

Native shared child preparation is durable and inert until the deployment releases
its first task. This is separate from the legacy immediate child-launch endpoint.

Source: `openhands-agent-server/openhands/agent_server/prepared_child.py`, `openhands-agent-server/openhands/agent_server/child_creation_store.py`, `openhands-sdk/openhands/sdk/conversation/child_creation.py`

Needs: `git`

Routes: `POST /api/conversations/{conversation_id}/children/preparations/{creation_id}`,
`GET /api/conversations/{conversation_id}/children/preparations/{creation_id}`,
`POST /api/conversations/{conversation_id}/children/preparations/{creation_id}/release`,
`POST /api/conversations/{conversation_id}/children/launcher/verify`,
`POST /api/conversations/{conversation_id}/children/queries/verify`,
`POST /api/conversations/{conversation_id}/children/queries`,
`POST /api/conversations/{conversation_id}/children/commands/verify`,
`POST /api/conversations/{conversation_id}/children/commands`

## Sub-features

- `F35.prepare`: stable shared identity, inert preparation, conflicts, execution gate and native restart; deleting a child prevents its recreation.
- `F35.launcher`: frozen native launcher policy refuses calls made with only Runtime credentials; the trusted deployment still authorizes the returned scope and active generation.
- `F35.queries`: native list/read/wait proofs, direct-child scope, bounded result pagination and cancellable waits. Runtime-key-only calls are refused before any history is read.
- `F35.commands`: governed parent send/interrupt proofs, stable native input IDs, formal provenance and shared user/parent admission; Runtime-key-only writes are refused.
- `F35.release`: after deployment governance, admit one initial user message and run; identical retries cannot restart a finished first turn.

## How to get to it (agent POV)

A trusted deployment uses the three preparation routes, with its server credentials.
The creation UUID is not authorization. The model-facing launcher policy and binding
credential activation are additional deployment requirements. Legacy `POST .../children`
is unchanged. TypeScript's generic HTTP client can call the routes; its generated
release schema remains pinned to the released upstream image, not this fork.

## Driving it with control-agent-server

Preconditions:

- An isolated baseline run is live and `doctor` passes.
- The prepare recipe needs no provider credential. The release recipe needs a
  configured `deepseek-flash` profile (`control-agent-server llm preset deepseek`).

- **Governed child prepare (`F35.prepare`).** This recipe is credential-free and can be run independently of the model-backed setup. The inline provider is deliberately unreachable; preparation and refusal must not contact it.
  Needs: `git`

  ```sh
  PREP_W=$(control-agent-server fixture project --name child-prepare --print-path)
  PREP_ID=4388c0d2-d8ab-49a9-95ca-5782e63d6265
  PREP_PARENT=$(control-agent-server api POST /api/conversations --json "{\"agent\":{\"kind\":\"Agent\",\"llm\":{\"model\":\"openai/qa-offline\",\"api_key\":\"no-model-calls\",\"base_url\":\"http://127.0.0.1:9/v1\",\"num_retries\":0},\"tools\":[]},\"workspace\":{\"kind\":\"LocalWorkspace\",\"working_dir\":\"$PREP_W\"},\"autotitle\":false}" --expect 201 --field id)
  PREP_ROUTE="/api/conversations/$PREP_PARENT/children/preparations/$PREP_ID"
  PREP_BODY='{"task":"Check later after governance","title":"Prepared child","isolation":"shared"}'
  PREP_CHILD=$(control-agent-server api POST "/api/conversations/$PREP_PARENT/children/preparations/$PREP_ID" --json "$PREP_BODY" --expect 201 --check phase eq prepared --field receipt.identity.conversation_id --save F35.prepare/prepared)
  control-agent-server api GET "/api/conversations/$PREP_PARENT/children/preparations/$PREP_ID" --expect 200 --check receipt.identity.conversation_id eq "$PREP_CHILD" --save F35.prepare/read
  control-agent-server api POST "/api/conversations/$PREP_PARENT/children/preparations/$PREP_ID" --json "$PREP_BODY" --expect 201 --check receipt.identity.conversation_id eq "$PREP_CHILD"
  control-agent-server api POST "/api/conversations/$PREP_CHILD/run" --expect 409 --save F35.prepare/refused
  control-agent-server restart
  control-agent-server doctor
  control-agent-server api GET "/api/conversations/$PREP_PARENT/children/preparations/$PREP_ID" --expect 200 --check phase eq prepared --check receipt.identity.conversation_id eq "$PREP_CHILD" --save F35.prepare/restored
  control-agent-server api POST "/api/conversations/$PREP_CHILD/run" --expect 409
  control-agent-server api DELETE "/api/conversations/$PREP_CHILD" --expect 200
  control-agent-server api POST "/api/conversations/$PREP_PARENT/children/preparations/$PREP_ID" --json "$PREP_BODY" --expect 409 --save F35.prepare/deleted
  control-agent-server api DELETE "/api/conversations/$PREP_PARENT" --expect 200
  ```

- **Governed child release (`F35.release`).** Needs: `llm`.
  Prepare using a parent with the saved DeepSeek profile, then release the same request. A receipt alone is not authorization: deployment binding and credentials must be governed before invoking release.

  ```sh
  REL_W=$(control-agent-server fixture project --name child-release --print-path)
  REL_PARENT=$(control-agent-server api POST /api/conversations --json "{\"agent_settings\":{\"agent_kind\":\"openhands\",\"llm_profile_ref\":\"deepseek-flash\"},\"workspace\":{\"kind\":\"LocalWorkspace\",\"working_dir\":\"$REL_W\"},\"autotitle\":false}" --expect 201 --field id)
  REL_ROUTE="/api/conversations/$REL_PARENT/children/preparations/53d61b08-853d-48cd-a26d-72d540e55d0e"
  REL_BODY='{"task":"Reply briefly that you are ready","title":"Governed child","isolation":"shared"}'
  REL_CHILD=$(control-agent-server api POST "$REL_ROUTE" --json "$REL_BODY" --expect 201 --field receipt.identity.conversation_id)
  control-agent-server api POST "/api/conversations/$REL_PARENT/children/preparations/53d61b08-853d-48cd-a26d-72d540e55d0e/release" --json "$REL_BODY" --expect 200 --check phase eq started --save F35.release/released
  control-agent-server conversation wait "$REL_CHILD" --until finished --timeout 120
  control-agent-server api POST "/api/conversations/$REL_PARENT/children/preparations/53d61b08-853d-48cd-a26d-72d540e55d0e/release" --json "$REL_BODY" --expect 200 --check phase eq started --save F35.release/retry
  control-agent-server api GET "/api/conversations/$REL_CHILD/events/search" --query kind=MessageEvent --query source=user --check items len-eq 1 --save F35.release/input-once
  control-agent-server api DELETE "/api/conversations/$REL_CHILD" --expect 200
  control-agent-server api DELETE "/api/conversations/$REL_PARENT" --expect 200
  ```

- **Governed launcher refusal (`F35.launcher`).** Runtime credentials are insufficient for launching on behalf of a governed parent. The provider is unreachable and no model call is made.
  Needs: `git`

  ```sh
  LAUNCH_W=$(control-agent-server fixture project --name child-launcher --print-path)
  LAUNCH_PARENT=21537bd2-9044-45ef-8e3b-e2d5483e0be9
  LAUNCH_ROOT="/api/conversations/$LAUNCH_PARENT"
  LAUNCH_BODY='{"task":"Denied without native invocation","isolation":"shared"}'
  control-agent-server api POST /api/conversations --json "{\"conversation_id\":\"$LAUNCH_PARENT\",\"agent\":{\"kind\":\"Agent\",\"llm\":{\"model\":\"openai/qa-offline\",\"api_key\":\"no-model-calls\",\"base_url\":\"http://127.0.0.1:9/v1\",\"num_retries\":0},\"tools\":[{\"name\":\"start_governed_child_conversation\",\"params\":{\"policy\":{\"parent_conversation_id\":\"$LAUNCH_PARENT\",\"scope_id\":\"0b1bb78c-c917-47c7-a2fa-beae012ecb66\",\"runtime_session_id\":\"c20ab857-534e-4017-aa25-c6ed3f0726aa\",\"generation\":1,\"manifest_digest\":\"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"},\"launch_url\":\"https://launcher.example/children\"}}]},\"tool_module_qualnames\":{\"start_governed_child_conversation\":\"openhands.tools.child_conversation.governed\"},\"workspace\":{\"kind\":\"LocalWorkspace\",\"working_dir\":\"$LAUNCH_W\"},\"autotitle\":false}" --expect 201
  control-agent-server api POST "/api/conversations/$LAUNCH_PARENT/children/launcher/verify" --json '{"task":"Denied without native invocation","token":"invalid-runtime-token"}' --expect 403 --save F35.launcher/proof-denied
  control-agent-server api POST "$LAUNCH_ROOT/children" --json "$LAUNCH_BODY" --expect 403 --save F35.launcher/legacy-denied
  control-agent-server api POST "$LAUNCH_ROOT/children/preparations/6bd05783-8d03-410a-9c11-70e5f0a9c149" --json "$LAUNCH_BODY" --expect 403 --save F35.launcher/prepare-denied
  control-agent-server restart
  control-agent-server doctor
  control-agent-server api POST "/api/conversations/$LAUNCH_PARENT/children/launcher/verify" --json '{"task":"Denied without native invocation","token":"invalid-runtime-token"}' --expect 403 --save F35.launcher/restart-denied
  control-agent-server api GET "$LAUNCH_ROOT" --expect 200 --check sub_conversation_ids len-eq 0
  control-agent-server api DELETE "$LAUNCH_ROOT" --expect 200
  ```

- **Child query refusal (`F35.queries`).** Credential-free identity refusal through both query routes, surviving restart; no LLM or child execution.
  Needs: `git`

  ```sh
  QUERY_W=$(control-agent-server fixture project --name child-query --print-path)
  QUERY_PARENT=749d2b64-3f5a-450b-9f21-c745aa6d8d22
  QUERY_ROOT="/api/conversations/$QUERY_PARENT"
  control-agent-server api POST /api/conversations --json "{\"conversation_id\":\"$QUERY_PARENT\",\"agent\":{\"kind\":\"Agent\",\"llm\":{\"model\":\"openai/qa-offline\",\"api_key\":\"no-model-calls\",\"base_url\":\"http://127.0.0.1:9/v1\",\"num_retries\":0},\"tools\":[{\"name\":\"list_child_conversations\",\"params\":{\"policy\":{\"parent_conversation_id\":\"$QUERY_PARENT\",\"scope_id\":\"d3209f5e-605c-4bff-9e25-18c17dcc7213\",\"runtime_session_id\":\"20cad024-f257-41f2-ac64-b1c0394dd8bb\",\"generation\":1,\"manifest_digest\":\"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa\"},\"access_url\":\"https://launcher.example/queries\"}}]},\"tool_module_qualnames\":{\"list_child_conversations\":\"openhands.tools.child_conversation.queries\"},\"workspace\":{\"kind\":\"LocalWorkspace\",\"working_dir\":\"$QUERY_W\"},\"autotitle\":false}" --expect 201
  control-agent-server api POST "/api/conversations/$QUERY_PARENT/children/queries/verify" --json '{"query":{"operation":"list"},"token":"invalid-runtime-token"}' --expect 403 --save F35.queries/verify-denied
  control-agent-server api POST "/api/conversations/$QUERY_PARENT/children/queries" --json '{"query":{"operation":"list"},"token":"invalid-runtime-token"}' --expect 403 --save F35.queries/list-denied
  control-agent-server api POST "/api/conversations/$QUERY_PARENT/children/queries" --json '{"query":{"operation":"wait","conversation_id":"00000000-0000-0000-0000-000000000001","timeout_seconds":31},"token":"invalid-runtime-token"}' --expect 422 --save F35.queries/wait-bound
  control-agent-server restart
  control-agent-server doctor
  control-agent-server api POST "/api/conversations/$QUERY_PARENT/children/queries" --json '{"query":{"operation":"read","conversation_id":"00000000-0000-0000-0000-000000000001"},"token":"invalid-runtime-token"}' --expect 403 --save F35.queries/restart-denied
  control-agent-server api GET "$QUERY_ROOT" --expect 200 --check sub_conversation_ids len-eq 0
  control-agent-server api DELETE "$QUERY_ROOT" --expect 200
  ```

- **Child command refusal (`F35.commands`).** Without native invocation proof, neither sending nor interrupting can affect a child. This recipe never calls a model.
  Needs: `git`

  ```sh
  COMMAND_W=$(control-agent-server fixture project --name child-command --print-path)
  COMMAND_PARENT=$(control-agent-server api POST /api/conversations --json "{\"agent\":{\"kind\":\"Agent\",\"llm\":{\"model\":\"openai/qa-offline\",\"api_key\":\"no-model-calls\",\"base_url\":\"http://127.0.0.1:9/v1\",\"num_retries\":0},\"tools\":[]},\"workspace\":{\"kind\":\"LocalWorkspace\",\"working_dir\":\"$COMMAND_W\"},\"autotitle\":false}" --expect 201 --field id)
  COMMAND_ROOT="/api/conversations/$COMMAND_PARENT"
  control-agent-server api POST "/api/conversations/$COMMAND_PARENT/children/commands/verify" --json '{"command":{"operation":"send","conversation_id":"00000000-0000-0000-0000-000000000001","text":"not admitted"},"token":"invalid-runtime-token"}' --expect 403 --save F35.commands/verify-denied
  control-agent-server api POST "/api/conversations/$COMMAND_PARENT/children/commands" --json '{"command":{"operation":"send","conversation_id":"00000000-0000-0000-0000-000000000001","text":"not admitted"},"token":"invalid-runtime-token"}' --expect 403 --save F35.commands/send-denied
  control-agent-server api POST "/api/conversations/$COMMAND_PARENT/children/commands" --json '{"command":{"operation":"interrupt","conversation_id":"00000000-0000-0000-0000-000000000001","text":"invalid"},"token":"invalid-runtime-token"}' --expect 422 --save F35.commands/invalid-command
  control-agent-server restart
  control-agent-server doctor
  control-agent-server api POST "/api/conversations/$COMMAND_PARENT/children/commands" --json '{"command":{"operation":"interrupt","conversation_id":"00000000-0000-0000-0000-000000000001"},"token":"invalid-runtime-token"}' --expect 403 --save F35.commands/restart-denied
  control-agent-server api GET "$COMMAND_ROOT" --expect 200 --check sub_conversation_ids len-eq 0
  control-agent-server api DELETE "$COMMAND_ROOT" --expect 200
  ```

## Gotchas

- Prepared children reject direct send/run/goal/ask/condense and live conversation
  access. Read-only state and credential setup remain available.
- An immutable encrypted launch plan recovers initialization interrupted before
  metadata persistence. Receipts contain hashes, not task text.
- Explicit run-slot rejection does not append the initial message. A dispatch
  interrupted after the event write reconciles its stable formal event ID.
- CPU/model-backed success and controlled-provider regressions are distinct proof.

- Governed deployments use `start_governed_child_conversation`, an additive tool;
  legacy `start_child_conversation` semantics remain unchanged for other parents.
  Its model input only contains task/title. Native action/tool-call identity, scope,
  generation, manifest and audience are proven by an expiring encrypted token.
- The verifier proves native provenance, not control-plane permission. A deployment
  must resolve scope to its authorized parent binding and fence the active generation
  before prepare/release. Prepared children lose both launcher tools; native routes
  refuse grandchildren. Parent admission is capped at three creating/active children.

- Query tools are frozen individually with the same parent policy and a trusted
  `access_url`. Model inputs expose only the target child, pagination/read budget
  or wait checkpoint. The service verifies native action identity and direct
  governed lineage; control-plane user authorization remains a deployment gate.
- Reads return newest-first progress metadata and formal assistant text, with
  event IDs, Unicode character offsets, `complete` and `next_cursor`. A page
  scans at most 100 events and emits at most 50 excerpts / 12000 text characters.
  Cursors bind parent/scope/generation/child/mode/HEAD; a changed HEAD requires
  restarting the read. System prompts, tool arguments and tool bodies are excluded.
- Wait uses native persisted snapshots and asyncio, never a sleeping worker or
  a child run slot. Timeout is a normal result, bounded to 30 seconds. Parent
  cooperative cancellation closes its HTTP wait; disconnect cancels server work.
- Query and launcher verifiers read immutable events without the parent's run
  lock: the native tool awaiting the verifier may itself hold that lock.

- Governed child messages use the existing native `POST .../events` with additive
  `submission_id` and `run=true`; ungoverned request and response shapes stay
  unchanged. Accepted child replies include `event_id`. Busy rejects before append;
  capacity rejects before append. Same ID reconciles its formal event, never text.
- Parent instructions remain native user messages, with `parent_instruction`
  carrying formal parent/action/tool-call and frozen scope; old events omit the
  optional field. Initial tasks carry the same formal provenance.
- Native interruption is idempotent by invocation, persists only a control receipt
  and original input identity, and attaches provenance to the actual native
  InterruptEvent/PauseEvent. A replay cannot stop a newer user input turn.
  If cancellation has not drained within five seconds, `pending=true` requires
  reconciliation with the same command identity, not a second interruption.
