"""Immutable native launch plans used to recover interrupted child preparation."""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable

from pydantic import BaseModel, ConfigDict, model_validator

from openhands.agent_server.models import StoredConversation
from openhands.sdk.conversation.child_creation import ChildConversationCreationReceipt
from openhands.sdk.conversation.request import ACPEnabledAgent


class ChildConversationNotReleased(RuntimeError):
    """The native child is awaiting governance or first-turn admission."""


class PreparedChildPlan(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)

    receipt: ChildConversationCreationReceipt
    stored: StoredConversation
    agent: ACPEnabledAgent

    @model_validator(mode="after")
    def validate_identity(self) -> PreparedChildPlan:
        gate = self.stored.child_launch_gate
        identity = self.receipt.identity
        if (
            gate is None
            or gate.receipt != self.receipt
            or gate.phase != "prepared"
            or self.stored.id != identity.conversation_id
            or self.stored.parent_conversation_id != identity.parent_conversation_id
            or self.stored.worktree
        ):
            raise ValueError("Prepared child plan identity mismatch")
        return self


async def complete_child_write[T](operation: Awaitable[T]) -> T:
    """Keep lifecycle fencing until an off-loop native write has settled."""
    task = asyncio.ensure_future(operation)
    try:
        return await asyncio.shield(task)
    except asyncio.CancelledError:
        while not task.done():
            try:
                await asyncio.shield(task)
            except asyncio.CancelledError:
                continue
        task.result()
        raise
