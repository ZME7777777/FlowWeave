# PR Review Workflow

This example demonstrates how to set up a GitHub Actions workflow for automated pull request reviews using the OpenHands agent SDK. When a PR is labeled with `review-this` or when openhands-agent is added as a reviewer, OpenHands will analyze the changes and provide detailed, constructive feedback.

**Note**: The actual review scripts now live in the [OpenHands/extensions](https://github.com/OpenHands/extensions/tree/main/plugins/pr-review) repository. This directory contains an example workflow that references those scripts.

## Files

- **`workflow.yml`**: Example GitHub Actions workflow file that runs the PR review agent
- **`README.md`**: This documentation file

## Features

- **Automatic Trigger**: Reviews are triggered when:
  - The `review-this` label is added to a PR, OR
  - openhands-agent is requested as a reviewer
- **Inline Review Comments**: Posts review comments directly on specific lines of code in the PR diff, rather than a single giant comment. This makes it easier to:
  - See exactly which lines the feedback refers to
  - Address issues one by one
  - Have focused discussions on specific code sections
- **Review Context Awareness**: The agent considers previous review history:
  - **Previous reviews**: Sees all past review decisions (APPROVED, CHANGES_REQUESTED, etc.)
  - **Review threads**: Fetches all review threads including their resolution status
  - **Smart commenting**: Avoids repeating issues that have already been raised and addressed
  - **Unresolved focus**: Prioritizes unresolved threads that may still need attention
  - **Pagination limits**: Fetches up to 100 threads per page (with pagination) and up to 50 comments per thread. For PRs with extensive review history exceeding these limits, older threads/comments may be omitted.
- **Skills-Based Review**: Uses public skills from <https://github.com/OpenHands/extensions>:
  - **`/codereview`**: Standard pragmatic code review focusing on simplicity, type safety, and backward compatibility
  - **`/codereview-roasted`**: Linus Torvalds style brutally honest review with emphasis on "good taste" and data structures
- **Complete Diff Upfront**: The agent receives a per-file diff payload in the initial message, preceded by a `Files Changed` manifest listing every file in the PR (so the agent always knows the full file set even when individual patches are abbreviated)
  - Each file's patch is capped at `MAX_PER_FILE_PATCH` (8,000 chars) so a single large file can't starve smaller ones
  - The combined patch block is capped at `MAX_TOTAL_DIFF` (100,000 chars); files past the cap appear in the manifest but their patch is replaced with a `[patch omitted: ...]` marker
  - The agent has full repository access and is instructed to read truncated files directly from the workspace rather than treating them as missing
- **Comprehensive Analysis**: Analyzes code changes in context of the entire repository
- **Detailed Feedback**: Provides structured review comments covering:
  - Overall assessment of changes
  - Code quality and best practices
  - Potential issues and security concerns
  - Specific improvement suggestions
- **GitHub API Integration**: Uses the GitHub API to post inline review comments directly on specific lines of code
- **Version Control**: Use `extensions-version` to pin to a specific version tag or branch of the extensions repository

## Setup

### 1. Copy the workflow file

Copy `workflow.yml` to `.github/workflows/pr-review-by-openhands.yml` in your repository:

```bash
cp examples/03_github_workflows/02_pr_review/workflow.yml .github/workflows/pr-review-by-openhands.yml
```

### 2. Configure secrets

Set the following secrets in your GitHub repository settings:

- **`LLM_API_KEY`** (required): Your LLM API key
  - Get one from the [OpenHands LLM Provider](https://docs.all-hands.dev/openhands/usage/llms/openhands-llms)

**Note**: The workflow automatically uses the `GITHUB_TOKEN` secret that's available in all GitHub Actions workflows.

### 3. Customize the workflow (optional)

Edit `.github/workflows/pr-review-by-openhands.yml` to customize the inputs:

```yaml
            - name: Run PR Review
              uses: OpenHands/extensions/plugins/pr-review@main
              with:
                  # Customize these inputs as needed
                  llm-model: gpt-5.5
                  llm-base-url: ''
                  review-style: roasted
                  # Secrets
                  llm-api-key: ${{ secrets.LLM_API_KEY }}
                  github-token: ${{ secrets.GITHUB_TOKEN }}
                  lmnr-api-key: ${{ secrets.LMNR_PROJECT_API_KEY }}
```

### 4. Create the review label

Create a `review-this` label in your repository:

1. Go to your repository → Issues → Labels
2. Click "New label"
3. Name: `review-this`
4. Description: `Trigger OpenHands PR review`
5. Color: Choose any color you prefer
6. Click "Create label"

## Usage

### Triggering a Review

There are two ways to trigger an automated review of a pull request:

#### Option 1: Using Labels

1. Open the pull request you want reviewed
2. Add the `review-this` label to the PR
3. The workflow will automatically start and analyze the changes
4. Review comments will be posted to the PR when complete

#### Option 2: Requesting a Reviewer (Recommended)

1. Open the pull request you want reviewed
2. Click on "Reviewers" in the right sidebar
3. Search for and select "openhands-agent" as a reviewer
4. The workflow will automatically start and analyze the changes
5. Review comments will be posted to the PR when complete

**Note**: Adding labels or requesting a *new* reviewer requires write access. GitHub may still allow PR authors to use "Re-request review" for a reviewer who has already reviewed.

## Customizing the Code Review

Instead of forking the `agent_script.py`, you can customize the code review behavior by adding a `.agents/skills/code-review.md` file to your repository. This is the **recommended approach** for customization.

### How It Works

The PR review agent uses skills from the [OpenHands/extensions](https://github.com/OpenHands/extensions) repository by default. When you add a `.agents/skills/code-review.md` file to your repository, it **overrides** the default skill with your custom guidelines.

### Example: Custom Code Review Skill

Create `.agents/skills/code-review.md` in your repository:

```markdown
---
name: code-review
description: Custom code review guidelines for my project
triggers:
- /codereview
---

# My Project Code Review Guidelines

You are a code reviewer for this project. Follow these guidelines:

## Review Decisions

- **APPROVE** straightforward changes (config updates, typo fixes, documentation)
- **COMMENT** when you have feedback or concerns

## What to Check

- Code follows our project conventions
- Tests are included for new functionality
- No security vulnerabilities introduced
- Documentation is updated if needed

## Communication Style

- Be direct and constructive
- Use GitHub suggestion syntax for code fixes
- Approve quickly when code is good
```

### Benefits of Custom Skills

1. **No forking required**: Keep using the official SDK while customizing behavior
2. **Version controlled**: Your review guidelines live in your repository
3. **Easy updates**: SDK updates don't overwrite your customizations
4. **Team alignment**: Everyone uses the same review standards

### Reference Example

See the [software-agent-sdk's own code-review skill](https://github.com/OpenHands/software-agent-sdk/blob/main/.agents/skills/code-review.md) for a complete example of a custom code review skill.

## Workflow Configuration

The workflow is configured using inputs to the `OpenHands/extensions/plugins/pr-review` action.

### Action Inputs

| Input | Description | Default Example |
|-------|-------------|---------|
| `llm-model` | LLM model(s) - can be comma-separated for A/B testing | `gpt-5.5` |
| `llm-base-url` | LLM base URL (optional) | `''` |
| `review-style` | Review style: 'standard' or 'roasted' | `roasted` |
| `llm-api-key` | LLM API key | `${{ secrets.LLM_API_KEY }}` |
| `github-token` | GitHub token for API access | `${{ secrets.GITHUB_TOKEN }}` |
| `lmnr-api-key` | Laminar API key for observability (optional) | `${{ secrets.LMNR_PROJECT_API_KEY }}` |

To use a specific version of the extensions repository, modify the `uses` line in the workflow file, e.g., `uses: OpenHands/extensions/plugins/pr-review@v1.0.0`.

## A/B Testing with Multiple Models

The PR review workflow supports A/B testing different LLM models. When multiple models are specified, one is randomly selected for each review.

### Configuration

Specify multiple models as a comma-separated list in the `llm-model` input:

```yaml
            - name: Run PR Review
              uses: OpenHands/extensions/plugins/pr-review@main
              with:
                  # Multiple models for A/B testing - one will be randomly selected
                  llm-model: 'gpt-5.5,gpt-4'
                  llm-api-key: ${{ secrets.LLM_API_KEY }}
                  github-token: ${{ secrets.GITHUB_TOKEN }}
                  # ... other inputs
```

### Observability

When Laminar observability is enabled, the selected model is automatically logged to the trace metadata:

- **Trace metadata**: The `model` field is added to Laminar trace metadata
- **Trace JSON**: The selected model is recorded in `laminar_trace_info.json`
- **GitHub logs**: The selected model is printed to workflow logs

This enables filtering and comparing review effectiveness across different models in Laminar dashboards.

## Review Evaluation (Observability)

When Laminar observability is enabled (`lmnr-api-key` input is provided), the workflow captures trace data that enables delayed evaluation of review effectiveness.

### How It Works

1. **During Review**: The agent script captures the Laminar trace ID and stores it as a GitHub artifact
2. **On PR Close/Merge**: The evaluation workflow (`pr-review-evaluation.yml`) runs automatically:
   - Downloads the trace ID from the artifact
   - Fetches all PR comments and the final diff from GitHub
   - Creates an evaluation trace in Laminar with the review context
   - Optionally scores the original review trace

### Evaluation Metrics

The evaluation script provides:
- **Review Engagement Score**: Preliminary score based on human responses to agent comments
- **Comment Analysis**: Structured data for signal processing (which comments were addressed)
- **Final Diff Context**: The actual code changes for comparison

### Laminar Signal Integration

Configure a Laminar signal to analyze the evaluation traces:

1. Create a signal named `pr_review_effectiveness`
2. Filter by tag: `pr-review-evaluation`
3. Use the signal prompt to analyze:
   - Which agent comments were addressed in the final patch
   - Which comments received human responses
   - Overall review effectiveness score

See [GitHub Issue #1953](https://github.com/OpenHands/software-agent-sdk/issues/1953) for the full implementation details.
