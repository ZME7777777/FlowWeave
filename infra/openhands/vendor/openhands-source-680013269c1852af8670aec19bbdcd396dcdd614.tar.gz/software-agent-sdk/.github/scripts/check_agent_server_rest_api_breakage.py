#!/usr/bin/env python3
"""REST API breakage detection for openhands-agent-server using oasdiff.

This script compares the current OpenAPI schema for the public agent-server REST API
(the `/api/**` surface) against an already-published release. The baseline version is
selected from PyPI, but the baseline schema is generated from the matching git tag
under the current workspace's locked dependency set. This keeps the comparison
focused on API changes in our code, not schema drift from newer FastAPI/Pydantic
releases.

The deprecation note it recognizes intentionally matches the phrasing used by the
Python deprecation checks, for example:

    Deprecated since v1.14.0 and scheduled for removal in v1.19.0.

Policies enforced:

1) REST deprecations must use FastAPI/OpenAPI metadata
   - FastAPI route handlers must not use `openhands.sdk.utils.deprecation.deprecated`.
   - Endpoints documented as deprecated in their OpenAPI description must also be
     marked `deprecated: true` in the generated schema.

2) Deprecation runway before removal
   - If a REST operation (path + HTTP method) or schema property is removed, it
     must have been marked `deprecated: true` in the baseline release and its
     OpenAPI description must declare a scheduled removal version that has been
     reached by the current package version.

3) Additive request/response oneOf/anyOf expansion is allowed
   - Adding new members to ``oneOf`` or ``anyOf`` discriminated unions in request
     or response schemas is a normal evolution for extensible APIs. Clients MUST
     handle unknown discriminator values gracefully (skip/ignore).
   - oasdiff can report union widening as ERR plus secondary type-change or
     property-removal artifacts for fields that still exist on one union member;
     this script downgrades those artifacts to informational notices.

4) Additive response property type widening is allowed with release notes
   - If a response property's old type remains valid and the schema only adds more
     accepted types, the check passes and the workflow marks the PR
     release-note-required.

5) Schema-only repairs of previously opaque MCP/settings locations are allowed
   - The runtime already returned MCP objects at these locations, but historical
     OpenAPI described them as empty/unconstrained schemas. Giving those existing
     objects their real shape is not a wire-format change.
   - Pydantic may also collapse identical validation/serialization components;
     replacing ``MCPNoneAuthCredential-Input`` with the structurally identical
     ``MCPNoneAuthCredential`` is a component-name repair, not a union removal.

6) Publishing the existing pagination limit is allowed
   - Four search endpoints already rejected limits above 100 at runtime. Their
     historical schemas used the unsupported ``lte: 100`` keyword. Replacing it
     with ``maximum: 100`` documents that existing bound.

7) No in-place contract breakage
   - Breaking REST contract changes that are not removals of previously-deprecated
     operations/properties, additive oneOf expansions, or additive response property
     type widenings fail the check. REST clients need 5 minor releases of runway, so
     incompatible replacements must ship additively or behind a versioned contract
     until the scheduled removal version.

If the baseline release schema can't be generated (e.g., missing tag / repo issues),
the script emits a warning and exits successfully to avoid flaky CI.
"""

from __future__ import annotations

import ast
import copy
import json
import os
import re
import subprocess
import sys
import tempfile
import tomllib
import urllib.request
from dataclasses import asdict, dataclass
from pathlib import Path

from packaging import version as pkg_version

from openhands.agent_server.openapi import filter_public_openapi


REPO_ROOT = Path(__file__).resolve().parents[2]
AGENT_SERVER_PYPROJECT = REPO_ROOT / "openhands-agent-server" / "pyproject.toml"
PYPI_DISTRIBUTION = "openhands-agent-server"
# Keep this in sync with REST_ROUTE_DEPRECATION_RE in check_deprecations.py so
# the REST breakage and deprecation checks recognize the same wording.
REST_ROUTE_DEPRECATION_RE = re.compile(
    r"Deprecated since v(?P<deprecated>[0-9A-Za-z.+-]+)\s+"
    r"and scheduled for removal in v(?P<removed>[0-9A-Za-z.+-]+)\.?",
    re.IGNORECASE,
)
HTTP_METHODS = {
    "get",
    "put",
    "post",
    "delete",
    "patch",
    "options",
    "head",
    "trace",
}
AGENT_SERVER_REST_API_BASE_REF_ENV = "AGENT_SERVER_REST_API_BASE_REF"
RESPONSE_TYPE_WIDENING_REPORT_ENV = "AGENT_SERVER_REST_TYPE_WIDENING_REPORT_PATH"


@dataclass(frozen=True)
class ResponsePropertyTypeWidening:
    property_path: str
    added_types: str
    media_type: str
    response_status: str
    text: str


ROUTE_DECORATOR_NAMES = HTTP_METHODS | {"api_route"}
OPENAPI_PROGRAM = """
import json
import sys
from pathlib import Path

source_tree = Path(sys.argv[1])
sys.path = [
    str(source_tree / "openhands-agent-server"),
    str(source_tree / "openhands-sdk"),
    str(source_tree / "openhands-tools"),
    str(source_tree / "openhands-workspace"),
] + sys.path

from openhands.agent_server.api import create_app

print(json.dumps(create_app().openapi()))
"""


def _read_version_from_pyproject(pyproject: Path) -> str:
    data = tomllib.loads(pyproject.read_text())
    try:
        return str(data["project"]["version"])
    except KeyError as exc:  # pragma: no cover
        raise SystemExit(
            f"Unable to determine project version from {pyproject}"
        ) from exc


def _fetch_pypi_metadata(distribution: str) -> dict:
    req = urllib.request.Request(
        url=f"https://pypi.org/pypi/{distribution}/json",
        headers={"User-Agent": "openhands-agent-server-openapi-check/1.0"},
        method="GET",
    )
    with urllib.request.urlopen(req, timeout=10) as response:
        return json.load(response)


def _get_baseline_version(distribution: str, current: str) -> str | None:
    try:
        meta = _fetch_pypi_metadata(distribution)
    except Exception as exc:  # pragma: no cover
        print(
            f"::warning title={distribution} REST API::Failed to fetch PyPI metadata: "
            f"{exc}"
        )
        return None

    releases = list(meta.get("releases", {}).keys())
    if not releases:
        return None

    if current in releases:
        return current

    current_parsed = pkg_version.parse(current)
    older = [rv for rv in releases if pkg_version.parse(rv) < current_parsed]
    if not older:
        return None

    return max(older, key=pkg_version.parse)


def _generate_openapi_from_source_tree(source_tree: Path, label: str) -> dict | None:
    try:
        result = subprocess.run(
            [sys.executable, "-c", OPENAPI_PROGRAM, str(source_tree)],
            check=True,
            capture_output=True,
            text=True,
            cwd=source_tree,
        )
        return json.loads(result.stdout)
    except subprocess.CalledProcessError as exc:
        output = (exc.stdout or "") + ("\n" + exc.stderr if exc.stderr else "")
        excerpt = output.strip()[-1000:]
        print(
            f"::warning title={PYPI_DISTRIBUTION} REST API::Failed to generate "
            f"OpenAPI schema for {label}: {exc}\n{excerpt}"
        )
        return None
    except Exception as exc:
        print(
            f"::warning title={PYPI_DISTRIBUTION} REST API::Failed to generate "
            f"OpenAPI schema for {label}: {exc}"
        )
        return None


def _generate_current_openapi() -> dict | None:
    return _generate_openapi_from_source_tree(REPO_ROOT, "current workspace")


def _generate_openapi_for_git_ref(git_ref: str) -> dict | None:
    with tempfile.TemporaryDirectory(prefix="agent-server-openapi-") as tmp:
        source_tree = Path(tmp)

        try:
            archive = subprocess.run(
                ["git", "-C", str(REPO_ROOT), "archive", git_ref],
                check=True,
                capture_output=True,
            )
            subprocess.run(
                ["tar", "-x", "-C", str(source_tree)],
                check=True,
                input=archive.stdout,
                capture_output=True,
            )
        except subprocess.CalledProcessError as exc:
            output = (exc.stdout or b"") + (b"\n" + exc.stderr if exc.stderr else b"")
            excerpt = output.decode(errors="replace").strip()[-1000:]
            print(
                f"::warning title={PYPI_DISTRIBUTION} REST API::Failed to extract "
                f"source for {git_ref}: {exc}\n{excerpt}"
            )
            return None

        return _generate_openapi_from_source_tree(source_tree, git_ref)


def _dotted_name(node: ast.AST) -> str | None:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        prefix = _dotted_name(node.value)
        if prefix is None:
            return None
        return f"{prefix}.{node.attr}"
    return None


def _find_sdk_deprecated_fastapi_routes_in_file(
    file_path: Path, repo_root: Path
) -> list[str]:
    tree = ast.parse(file_path.read_text(), filename=str(file_path))

    deprecated_names: set[str] = set()
    deprecation_module_names: set[str] = set()

    for node in tree.body:
        if isinstance(node, ast.ImportFrom):
            if node.module == "openhands.sdk.utils.deprecation":
                for alias in node.names:
                    if alias.name == "deprecated":
                        deprecated_names.add(alias.asname or alias.name)
            elif node.module == "openhands.sdk.utils":
                for alias in node.names:
                    if alias.name == "deprecation":
                        deprecation_module_names.add(alias.asname or alias.name)
        elif isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name == "openhands.sdk.utils.deprecation":
                    deprecation_module_names.add(alias.asname or alias.name)

    errors: list[str] = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
            continue

        has_route_decorator = False
        uses_sdk_deprecated = False

        for decorator in node.decorator_list:
            if not isinstance(decorator, ast.Call):
                continue

            dotted_name = _dotted_name(decorator.func)
            if (
                isinstance(decorator.func, ast.Attribute)
                and decorator.func.attr in ROUTE_DECORATOR_NAMES
            ):
                has_route_decorator = True

            if dotted_name in deprecated_names or (
                dotted_name == "openhands.sdk.utils.deprecation.deprecated"
            ):
                uses_sdk_deprecated = True
                continue

            if (
                isinstance(decorator.func, ast.Attribute)
                and decorator.func.attr == "deprecated"
            ):
                base_name = _dotted_name(decorator.func.value)
                if base_name in deprecation_module_names or (
                    base_name == "openhands.sdk.utils.deprecation"
                ):
                    uses_sdk_deprecated = True

        if has_route_decorator and uses_sdk_deprecated:
            rel_path = file_path.relative_to(repo_root).as_posix()
            errors.append(
                f"{rel_path}:{node.lineno} FastAPI route `{node.name}` uses "
                "openhands.sdk.utils.deprecation.deprecated; use the route "
                "decorator's deprecated=True flag instead."
            )

    return errors


def _find_sdk_deprecated_fastapi_routes(repo_root: Path) -> list[str]:
    app_root = repo_root / "openhands-agent-server" / "openhands" / "agent_server"
    errors: list[str] = []

    for file_path in sorted(app_root.rglob("*.py")):
        errors.extend(_find_sdk_deprecated_fastapi_routes_in_file(file_path, repo_root))

    return errors


def _filter_public_rest_openapi(schema: dict) -> dict:
    # Compatibility checks retain the historical component set so an approved,
    # deprecated property can still be inspected after the route that referenced
    # it is removed. Release artifacts use the pruned, canonical mode instead.
    return filter_public_openapi(
        schema,
        prune_schemas=False,
        add_contract_components=False,
    )


def _find_deprecation_policy_errors(schema: dict) -> list[str]:
    errors: list[str] = []

    for path, path_item in schema.get("paths", {}).items():
        if not isinstance(path_item, dict):
            continue

        for method, operation in path_item.items():
            if method not in HTTP_METHODS or not isinstance(operation, dict):
                continue

            description = operation.get("description") or ""
            if "deprecated since" not in description.lower():
                continue

            if operation.get("deprecated") is True:
                continue

            errors.append(
                f"{method.upper()} {path} documents deprecation in its "
                "description but is not marked deprecated=true in OpenAPI."
            )

    return errors


def _parse_openapi_deprecation_description(
    description: str | None,
) -> tuple[str, str] | None:
    """Extract ``(deprecated_in, removed_in)`` from an OpenAPI description.

    The accepted wording intentionally matches ``check_deprecations.py`` so both
    CI checks recognize the same note, for example:

        Deprecated since v1.14.0 and scheduled for removal in v1.19.0.
    """
    if not description:
        return None

    match = REST_ROUTE_DEPRECATION_RE.search(" ".join(description.split()))
    if match is None:
        return None

    return match.group("deprecated").rstrip("."), match.group("removed").rstrip(".")


def _version_ge(current: str, target: str) -> bool:
    try:
        return pkg_version.parse(current) >= pkg_version.parse(target)
    except pkg_version.InvalidVersion as exc:
        raise SystemExit(
            f"Invalid semantic version comparison: {current=} {target=}"
        ) from exc


def _get_openapi_operation(schema: dict, path: str, method: str) -> dict | None:
    path_item = schema.get("paths", {}).get(path)
    if not isinstance(path_item, dict):
        return None

    operation = path_item.get(method.lower())
    if not isinstance(operation, dict):
        return None

    return operation


def _validate_removed_operations(
    removed_operations: list[dict],
    prev_schema: dict,
    current_version: str,
) -> list[str]:
    """Validate removed operations against the baseline deprecation metadata."""
    errors: list[str] = []

    for operation in removed_operations:
        path = str(operation.get("path", ""))
        method = str(operation.get("method", "")).lower()
        method_label = method.upper() or "<unknown method>"

        if not operation.get("deprecated", False):
            errors.append(
                f"Removed {method_label} {path} without prior deprecation "
                "(deprecated=true)."
            )
            continue

        baseline_operation = _get_openapi_operation(prev_schema, path, method)
        if baseline_operation is None:
            errors.append(
                f"Removed {method_label} {path} was marked deprecated in the "
                "baseline release, but the previous OpenAPI schema could not be "
                "inspected for its scheduled removal version."
            )
            continue

        deprecation_details = _parse_openapi_deprecation_description(
            baseline_operation.get("description")
        )
        if deprecation_details is None:
            errors.append(
                f"Removed {method_label} {path} was marked deprecated in the "
                "baseline release, but its OpenAPI description does not declare "
                "a scheduled removal version. REST API removals require 5 minor "
                "releases of deprecation runway."
            )
            continue

        _, removed_in = deprecation_details
        if not _version_ge(current_version, removed_in):
            errors.append(
                f"Removed {method_label} {path} before its scheduled removal "
                f"version v{removed_in} (current version: v{current_version}). "
                "REST API removals require 5 minor releases of deprecation "
                "runway."
            )
            continue

        print(
            f"::notice title={PYPI_DISTRIBUTION} REST API::Removed previously-"
            f"deprecated {method_label} {path} after its scheduled removal "
            f"version v{removed_in}."
        )

    return errors


def _iter_schema_properties(schema: dict):
    if not isinstance(schema, dict):
        return

    properties = schema.get("properties")
    if isinstance(properties, dict):
        for property_name, property_schema in properties.items():
            if isinstance(property_schema, dict):
                yield property_name, property_schema

    for value in schema.values():
        if isinstance(value, dict):
            yield from _iter_schema_properties(value)
        elif isinstance(value, list):
            for item in value:
                if isinstance(item, dict):
                    yield from _iter_schema_properties(item)


def _removed_property_name(change: dict) -> str | None:
    text = str(change.get("text", ""))
    match = re.search(
        r"(?:request property|optional property|required property) `([^`]+)`",
        text,
    )
    if match is None:
        return None
    return match.group(1).rstrip("/").rsplit("/", maxsplit=1)[-1]


def _validate_removed_schema_properties(
    removed_properties: list[dict],
    prev_schema: dict,
    current_version: str,
) -> list[str]:
    """Validate removed schema properties against baseline deprecation metadata."""
    errors: list[str] = []
    baseline_properties: dict[str, list[dict]] = {}
    for property_name, property_schema in _iter_schema_properties(prev_schema):
        baseline_properties.setdefault(property_name, []).append(property_schema)

    for change in removed_properties:
        property_name = _removed_property_name(change)
        if property_name is None:
            errors.append(
                "Removed schema property could not be identified from oasdiff output: "
                f"{change.get('text', str(change))}"
            )
            continue

        deprecated_candidates = [
            property_schema
            for property_schema in baseline_properties.get(property_name, [])
            if property_schema.get("deprecated") is True
        ]
        if not deprecated_candidates:
            errors.append(
                f"Removed schema property {property_name!r} without prior "
                "deprecation (deprecated=true)."
            )
            continue

        removal_targets = [
            deprecation_details[1]
            for property_schema in deprecated_candidates
            if (
                deprecation_details := _parse_openapi_deprecation_description(
                    property_schema.get("description")
                )
            )
            is not None
        ]
        if not removal_targets:
            errors.append(
                f"Removed schema property {property_name!r} was marked deprecated "
                "in the baseline release, but its OpenAPI description does not "
                "declare a scheduled removal version. REST API property removals "
                "require 5 minor releases of deprecation runway."
            )
            continue

        if not any(
            _version_ge(current_version, removed_in) for removed_in in removal_targets
        ):
            errors.append(
                f"Removed schema property {property_name!r} before its scheduled "
                f"removal version(s): {', '.join(f'v{v}' for v in removal_targets)} "
                f"(current version: v{current_version}). REST API property removals "
                "require 5 minor releases of deprecation runway."
            )
            continue

        print(
            f"::notice title={PYPI_DISTRIBUTION} REST API::Removed previously-"
            f"deprecated schema property {property_name!r} after its scheduled "
            "removal version was reached."
        )

    return errors


# oasdiff rule IDs for additive oneOf/anyOf expansion in response schemas.
# These are flagged as ERR by oasdiff but are expected evolution for extensible
# discriminated-union APIs (e.g. the events endpoint).  We downgrade them to
# informational notices so they don't block CI.
_ADDITIVE_RESPONSE_ONEOF_IDS = frozenset(
    {
        "response-body-one-of-added",
        "response-property-one-of-added",
        # Keep the anyOf variants here too so that if oasdiff ever reports them
        # as breakages, additive response-union expansion gets the same
        # downgrade without further script changes.
        "response-body-any-of-added",
        "response-property-any-of-added",
    }
)


_ADDITIVE_RESPONSE_BODY_ONEOF_IDS = frozenset(
    {
        "response-body-one-of-added",
        "response-body-any-of-added",
    }
)


# oasdiff rule IDs for enum-value additions in response schemas.
_RESPONSE_ENUM_VALUE_ADDED_IDS = frozenset(
    {
        "response-property-enum-value-added",
        "response-write-only-property-enum-value-added",
    }
)
_RESPONSE_PROPERTY_TYPE_WIDENING_RE = re.compile(
    r"response property `(?P<property_path>[^`]+)` list-of-types was widened "
    r"by adding types `(?P<added_types>[^`]+)` to media type "
    r"`(?P<media_type>[^`]+)` of response `(?P<response_status>[^`]+)`"
)


def _parse_response_property_type_widening(
    change: dict,
) -> ResponsePropertyTypeWidening | None:
    text = str(change.get("text", ""))
    match = _RESPONSE_PROPERTY_TYPE_WIDENING_RE.search(text)
    if match is None:
        return None
    return ResponsePropertyTypeWidening(text=text, **match.groupdict())


def _is_additive_response_property_type_widening(change: dict) -> bool:
    return _parse_response_property_type_widening(change) is not None


def _response_type_widening_report_items(
    changes: list[dict],
) -> list[ResponsePropertyTypeWidening]:
    items: list[ResponsePropertyTypeWidening] = []
    for change in changes:
        widening = _parse_response_property_type_widening(change)
        if widening is not None:
            items.append(widening)
    return items


# Response properties that are known extensible discriminated-union discriminators
# and may therefore grow new enum values additively. Adding a HookType value
# (e.g. "agent") to a hook definition's `type` is safe because hook configs are an
# extensible union and clients must tolerate unknown discriminator values. This is
# intentionally scoped to the hook discriminator so an ordinary new response enum
# value elsewhere (a new status/mode/etc.) is still treated as a breaking change.
_EXTENSIBLE_DISCRIMINATOR_PROPERTY_RE = re.compile(
    r"HookConfig\b.*\bhooks/items/type\b"
)
_ACCEPTED_CLOUD_PROXY_PATH_REMOVAL_ID = "api-path-removed-without-deprecation"
_ACCEPTED_CLOUD_PROXY_REMOVAL_PATH = "/api/cloud-proxy"
_ACCEPTED_CLOUD_PROXY_REMOVAL_METHOD = "post"
_ACCEPTED_CLOUD_PROXY_REMOVAL_OPERATION_ID = "cloud_proxy_api_cloud_proxy_post"

_ACCEPTED_VSCODE_BASE_URL_DEFAULT_REMOVAL_ID = "request-parameter-default-value-removed"
_ACCEPTED_VSCODE_BASE_URL_DEFAULT_REMOVAL_PATH = "/api/vscode/url"
_ACCEPTED_VSCODE_BASE_URL_DEFAULT_REMOVAL_METHOD = "get"
_ACCEPTED_VSCODE_BASE_URL_DEFAULT_REMOVAL_OPERATION_ID = (
    "get_vscode_url_api_vscode_url_get"
)
_ACCEPTED_VSCODE_BASE_URL_DEFAULT_REMOVAL_PARAM_RE = re.compile(
    r"request parameter `base_url`, default value `http://localhost:8001` "
    r"was removed"
)


def _is_accepted_vscode_base_url_default_removal(change: dict) -> bool:
    """Return True for the accepted /api/vscode/url base_url default removal.

    Maintainers accepted this documented-default removal in PR #4181: the
    ``base_url`` query parameter stays optional, only the server-side fallback
    changed (from a hardcoded ``http://localhost:8001`` to the actually
    configured VSCode port). Requests that omit ``base_url`` keep working, so
    no client contract is broken.
    """
    return (
        str(change.get("id", "")) == _ACCEPTED_VSCODE_BASE_URL_DEFAULT_REMOVAL_ID
        and str(change.get("path", ""))
        == _ACCEPTED_VSCODE_BASE_URL_DEFAULT_REMOVAL_PATH
        and str(change.get("operation", "")).lower()
        == _ACCEPTED_VSCODE_BASE_URL_DEFAULT_REMOVAL_METHOD
        and str(change.get("operationId", ""))
        == _ACCEPTED_VSCODE_BASE_URL_DEFAULT_REMOVAL_OPERATION_ID
        and bool(
            _ACCEPTED_VSCODE_BASE_URL_DEFAULT_REMOVAL_PARAM_RE.search(
                str(change.get("text", ""))
            )
        )
    )


_SEARCH_LIMIT_SCHEMA_REPAIR_PATHS = frozenset(
    {
        "/api/conversations/search",
        "/api/conversations/{conversation_id}/events/search",
        "/api/bash/bash_events/search",
        "/api/file/search_subdirs",
    }
)


def _is_search_limit_schema_repair(change: dict, prev_schema: dict) -> bool:
    """Accept the known pagination ``lte: 100`` to ``maximum: 100`` repair."""
    path = change.get("path", "")
    if (
        change.get("id") != "request-parameter-max-set"
        or path not in _SEARCH_LIMIT_SCHEMA_REPAIR_PATHS
        or str(change.get("operation", "")).lower() != "get"
        or change.get("text")
        != "for the `query` request parameter `limit`, the max was set to `100.00`"
    ):
        return False

    operation = prev_schema.get("paths", {}).get(path, {}).get("get", {})
    if change.get("operationId") != operation.get("operationId"):
        return False

    for parameter in operation.get("parameters", []):
        if parameter.get("in") == "query" and parameter.get("name") == "limit":
            schema = parameter.get("schema", {})
            return (
                schema.get("type") == "integer"
                and schema.get("lte") == 100
                and "maximum" not in schema
            )
    return False


def _is_accepted_cloud_proxy_removal(operation: dict) -> bool:
    """Return True for the accepted /api/cloud-proxy removal from PR #3326."""
    path = str(operation.get("path", ""))
    method = str(operation.get("method", "")).lower()
    return (
        path == _ACCEPTED_CLOUD_PROXY_REMOVAL_PATH
        and method == _ACCEPTED_CLOUD_PROXY_REMOVAL_METHOD
        and operation.get("deprecated", False) is False
    )


def _is_accepted_cloud_proxy_path_removal(change: dict) -> bool:
    """Return True for oasdiff's accepted /api/cloud-proxy path-removal shape."""
    return (
        str(change.get("id", "")) == _ACCEPTED_CLOUD_PROXY_PATH_REMOVAL_ID
        and str(change.get("path", "")) == _ACCEPTED_CLOUD_PROXY_REMOVAL_PATH
        and str(change.get("operation", "")).lower()
        == _ACCEPTED_CLOUD_PROXY_REMOVAL_METHOD
        and str(change.get("operationId", ""))
        == _ACCEPTED_CLOUD_PROXY_REMOVAL_OPERATION_ID
    )


def _is_additive_discriminator_enum_value(change: dict) -> bool:
    """Return True for additive enum values on a known extensible discriminator.

    Adding a value to a response enum is normally breaking (generated clients may
    treat the enum exhaustively), so this is scoped narrowly to the hook config
    discriminator union rather than allowlisting every response enum addition.
    """
    if str(change.get("id", "")) not in _RESPONSE_ENUM_VALUE_ADDED_IDS:
        return False
    text = str(change.get("text", ""))
    return bool(_EXTENSIBLE_DISCRIMINATOR_PROPERTY_RE.search(text))


def _is_union_property_removal_artifact(change: dict) -> bool:
    """Return True for property removals that are artifacts of union widening.

    When a request or response schema is widened from a concrete object schema
    to an additive oneOf/anyOf union, oasdiff can emit secondary "removed
    property" reports for the original object's fields even though the original
    schema is still present as one union member.
    """
    change_id = str(change.get("id", "")).lower()
    text = str(change.get("text", "")).lower()
    return (
        "removed" in change_id
        and "property" in change_id
        and ("from the response" in text or "request property" in text)
    )


def _is_union_type_change_artifact(change: dict) -> bool:
    text = str(change.get("text", "")).lower()
    return "type/format changed from `object`/`` to ``/``" in text


_OPAQUE_MCP_RESPONSE_REPAIR_PATHS = (
    "/mcp_config/",
    "/mcp_servers/",
    "oauth_state/",
)
_OPAQUE_TO_OBJECT_TYPE_CHANGE = (
    "response's property type/format changed from ``/`` to `object`/``"
)
_NONE_AUTH_INPUT_COMPONENT = "#/components/schemas/MCPNoneAuthCredential-Input"
_AGENT_SETTINGS_DIFF_SCHEMA_REPAIR = (
    "removed `subschema #1` from the `agent_settings_diff` request property "
    "`anyOf` list"
)


def _is_mcp_contract_schema_repair(change: dict) -> bool:
    """Recognize wire-compatible repairs of historically opaque MCP schemas.

    This is deliberately narrower than accepting arbitrary type changes. The
    response exception only covers MCP settings and OAuth state locations whose
    old schemas had no type at all. The request exceptions cover an identical
    Pydantic component rename and the settings diff's replacement of an
    unrestricted object schema with the same extensible object plus known fields.
    """
    text = str(change.get("text", ""))
    if _OPAQUE_TO_OBJECT_TYPE_CHANGE in text and any(
        path in text for path in _OPAQUE_MCP_RESPONSE_REPAIR_PATHS
    ):
        return True

    if (
        text.startswith(f"removed `{_NONE_AUTH_INPUT_COMPONENT}` from the `")
        and "/auth/" in text
        and "request property `oneOf` list" in text
    ):
        return True

    return text == _AGENT_SETTINGS_DIFF_SCHEMA_REPAIR


def _split_breaking_changes(
    breaking_changes: list[dict],
) -> tuple[list[dict], list[dict], list[dict], list[dict]]:
    """Split oasdiff results into allowlisted buckets and other breakages."""
    removed_operations: list[dict] = []
    removed_schema_properties: list[dict] = []
    additive_response_oneof: list[dict] = []
    other_breaking_changes: list[dict] = []

    for change in breaking_changes:
        change_id = str(change.get("id", ""))
        details = change.get("details", {})

        if "removed" in change_id.lower() and "operation" in change_id.lower():
            removed_operations.append(
                {
                    "path": details.get("path", ""),
                    "method": details.get("method", ""),
                    "deprecated": details.get("deprecated", False),
                }
            )
            continue

        if "removed" in change_id.lower() and "property" in change_id.lower():
            removed_schema_properties.append(change)
            continue

        if change_id in _ADDITIVE_RESPONSE_ONEOF_IDS or (
            _is_additive_discriminator_enum_value(change)
        ):
            additive_response_oneof.append(change)
            continue

        other_breaking_changes.append(change)

    return (
        removed_operations,
        removed_schema_properties,
        additive_response_oneof,
        other_breaking_changes,
    )


def _normalize_openapi_for_oasdiff(schema: dict) -> dict:
    """Normalize OpenAPI 3.1 schema for oasdiff compatibility.

    oasdiff expects OpenAPI 3.0-style exclusiveMinimum/exclusiveMaximum booleans
    (https://spec.openapis.org/oas/v3.0.3.html#schema-object), while OpenAPI 3.1
    emits numeric values. Convert numeric exclusives into minimum/maximum +
    exclusive boolean flags so oasdiff can parse the schema.

    Mutates the schema in place and returns it for convenience.
    """

    def _walk(node: object) -> None:
        if isinstance(node, dict):
            if (
                "exclusiveMinimum" in node
                and isinstance(node["exclusiveMinimum"], (int, float))
                and not isinstance(node["exclusiveMinimum"], bool)
            ):
                value = node["exclusiveMinimum"]
                if "minimum" not in node:
                    node["minimum"] = value
                node["exclusiveMinimum"] = True
            if (
                "exclusiveMaximum" in node
                and isinstance(node["exclusiveMaximum"], (int, float))
                and not isinstance(node["exclusiveMaximum"], bool)
            ):
                value = node["exclusiveMaximum"]
                if "maximum" not in node:
                    node["maximum"] = value
                node["exclusiveMaximum"] = True

            for child in node.values():
                _walk(child)
        elif isinstance(node, list):
            for child in node:
                _walk(child)

    _walk(schema)
    return schema


def _run_oasdiff_breakage_check(
    prev_spec: Path, cur_spec: Path
) -> tuple[list[dict], int]:
    """Run oasdiff breaking check between two OpenAPI specs.

    Returns (list of breaking changes, exit code from oasdiff).
    """
    try:
        result = subprocess.run(
            [
                "oasdiff",
                "breaking",
                "-f",
                "json",
                "--fail-on",
                "ERR",
                str(prev_spec),
                str(cur_spec),
            ],
            capture_output=True,
            text=True,
        )
    except FileNotFoundError:
        print(
            "::warning title=oasdiff not found::"
            "Please install oasdiff: https://github.com/oasdiff/oasdiff"
        )
        return [], 0

    breaking_changes = []
    if result.stdout:
        try:
            breaking_changes = json.loads(result.stdout)
        except json.JSONDecodeError:
            pass

    return breaking_changes, result.returncode


def _find_response_property_type_widenings(
    prev_schema: dict,
    current_schema: dict,
) -> list[ResponsePropertyTypeWidening]:
    previous = _normalize_openapi_for_oasdiff(copy.deepcopy(prev_schema))
    current = _normalize_openapi_for_oasdiff(copy.deepcopy(current_schema))
    with tempfile.TemporaryDirectory(prefix="oasdiff-type-widening-") as tmp:
        tmp_path = Path(tmp)
        prev_spec_file = tmp_path / "prev_spec.json"
        cur_spec_file = tmp_path / "cur_spec.json"
        prev_spec_file.write_text(json.dumps(previous, indent=2))
        cur_spec_file.write_text(json.dumps(current, indent=2))
        breaking_changes, _ = _run_oasdiff_breakage_check(prev_spec_file, cur_spec_file)
    return _response_type_widening_report_items(breaking_changes)


def _collect_response_property_type_widenings_since_ref(
    base_ref: str,
    current_schema: dict,
) -> list[ResponsePropertyTypeWidening] | None:
    base_schema = _generate_openapi_for_git_ref(base_ref)
    if base_schema is None:
        return None
    base_schema = _filter_public_rest_openapi(base_schema)
    return _find_response_property_type_widenings(base_schema, current_schema)


def _write_response_type_widening_report(
    changes: list[ResponsePropertyTypeWidening],
    *,
    changes_since_base: list[ResponsePropertyTypeWidening] | None = None,
) -> None:
    report_path = os.environ.get(RESPONSE_TYPE_WIDENING_REPORT_ENV, "").strip()
    if not report_path:
        return

    report = {
        "additive_response_property_type_widenings": [
            asdict(change) for change in changes
        ]
    }
    if changes_since_base is not None:
        report["additive_response_property_type_widenings_since_base"] = [
            asdict(change) for change in changes_since_base
        ]

    Path(report_path).write_text(json.dumps(report, indent=2) + "\n")


def main() -> int:
    current_version = _read_version_from_pyproject(AGENT_SERVER_PYPROJECT)
    baseline_version = _get_baseline_version(PYPI_DISTRIBUTION, current_version)

    if baseline_version is None:
        print(
            f"::warning title={PYPI_DISTRIBUTION} REST API::Unable to find baseline "
            f"version for {current_version}; skipping breakage checks."
        )
        return 0

    baseline_git_ref = f"v{baseline_version}"

    static_policy_errors = _find_sdk_deprecated_fastapi_routes(REPO_ROOT)
    for error in static_policy_errors:
        print(f"::error title={PYPI_DISTRIBUTION} REST API::{error}")

    current_schema = _generate_current_openapi()
    if current_schema is None:
        return 1
    current_schema = _filter_public_rest_openapi(current_schema)

    deprecation_policy_errors = _find_deprecation_policy_errors(current_schema)
    for error in deprecation_policy_errors:
        print(f"::error title={PYPI_DISTRIBUTION} REST API::{error}")

    prev_schema = _generate_openapi_for_git_ref(baseline_git_ref)
    if prev_schema is None:
        return 0 if not (static_policy_errors or deprecation_policy_errors) else 1
    prev_schema = _filter_public_rest_openapi(prev_schema)

    prev_schema = _normalize_openapi_for_oasdiff(prev_schema)
    current_schema = _normalize_openapi_for_oasdiff(current_schema)

    with tempfile.TemporaryDirectory(prefix="oasdiff-specs-") as tmp:
        tmp_path = Path(tmp)
        prev_spec_file = tmp_path / "prev_spec.json"
        cur_spec_file = tmp_path / "cur_spec.json"
        prev_spec_file.write_text(json.dumps(prev_schema, indent=2))
        cur_spec_file.write_text(json.dumps(current_schema, indent=2))

        breaking_changes, exit_code = _run_oasdiff_breakage_check(
            prev_spec_file, cur_spec_file
        )

    response_type_widenings: list[ResponsePropertyTypeWidening] = []
    response_type_widenings_since_base: list[ResponsePropertyTypeWidening] | None = None
    report_path = os.environ.get(RESPONSE_TYPE_WIDENING_REPORT_ENV, "").strip()
    base_ref = os.environ.get(AGENT_SERVER_REST_API_BASE_REF_ENV, "").strip()
    if report_path and base_ref:
        response_type_widenings_since_base = (
            _collect_response_property_type_widenings_since_ref(
                base_ref, current_schema
            )
        )

    if not breaking_changes:
        if exit_code == 0:
            print("No breaking changes detected.")
        else:
            print(
                f"oasdiff returned exit code {exit_code} but no breaking changes "
                "in JSON format. There may be warnings only."
            )
        _write_response_type_widening_report(
            response_type_widenings,
            changes_since_base=response_type_widenings_since_base,
        )

    else:
        (
            removed_operations,
            removed_schema_properties,
            additive_response_oneof,
            other_breaking_changes,
        ) = _split_breaking_changes(breaking_changes)
        response_union_artifacts = [
            change
            for change in removed_schema_properties
            if _is_union_property_removal_artifact(change)
        ]
        removed_schema_properties = [
            change
            for change in removed_schema_properties
            if not _is_union_property_removal_artifact(change)
        ]
        union_type_artifacts = [
            change
            for change in other_breaking_changes
            if _is_union_type_change_artifact(change)
        ]
        other_breaking_changes = [
            change
            for change in other_breaking_changes
            if not _is_union_type_change_artifact(change)
        ]
        mcp_contract_schema_repairs = [
            change
            for change in other_breaking_changes
            if _is_mcp_contract_schema_repair(change)
        ]
        other_breaking_changes = [
            change
            for change in other_breaking_changes
            if not _is_mcp_contract_schema_repair(change)
        ]
        accepted_response_type_widening_changes = [
            change
            for change in other_breaking_changes
            if _is_additive_response_property_type_widening(change)
        ]
        other_breaking_changes = [
            change
            for change in other_breaking_changes
            if not _is_additive_response_property_type_widening(change)
        ]
        response_type_widenings = _response_type_widening_report_items(
            accepted_response_type_widening_changes
        )

        accepted_cloud_proxy_removals = [
            operation
            for operation in removed_operations
            if _is_accepted_cloud_proxy_removal(operation)
        ]
        removed_operations = [
            operation
            for operation in removed_operations
            if not _is_accepted_cloud_proxy_removal(operation)
        ]
        accepted_cloud_proxy_path_removals = [
            change
            for change in other_breaking_changes
            if _is_accepted_cloud_proxy_path_removal(change)
        ]
        other_breaking_changes = [
            change
            for change in other_breaking_changes
            if not _is_accepted_cloud_proxy_path_removal(change)
        ]
        accepted_vscode_base_url_default_removals = [
            change
            for change in other_breaking_changes
            if _is_accepted_vscode_base_url_default_removal(change)
        ]
        other_breaking_changes = [
            change
            for change in other_breaking_changes
            if not _is_accepted_vscode_base_url_default_removal(change)
        ]
        search_limit_schema_repairs = [
            change
            for change in other_breaking_changes
            if _is_search_limit_schema_repair(change, prev_schema)
        ]
        other_breaking_changes = [
            change
            for change in other_breaking_changes
            if not _is_search_limit_schema_repair(change, prev_schema)
        ]

        removal_errors = _validate_removed_operations(
            removed_operations,
            prev_schema,
            current_version,
        )
        property_removal_errors = _validate_removed_schema_properties(
            removed_schema_properties,
            prev_schema,
            current_version,
        )

        for error in removal_errors + property_removal_errors:
            print(f"::error title={PYPI_DISTRIBUTION} REST API::{error}")

        if accepted_cloud_proxy_removals or accepted_cloud_proxy_path_removals:
            print(
                f"\n::notice title={PYPI_DISTRIBUTION} REST API::"
                "Accepted removal of POST /api/cloud-proxy. Maintainers "
                "explicitly accepted this REST break in PR #3326, and that PR "
                "is labeled release-note-required."
            )

        if accepted_vscode_base_url_default_removals:
            print(
                f"\n::notice title={PYPI_DISTRIBUTION} REST API::"
                "Accepted removal of the documented default for the optional "
                "`base_url` query parameter of GET /api/vscode/url (PR #4181). "
                "The parameter stays optional; only the server-side fallback "
                "changed, so requests that omit it keep working."
            )

        if search_limit_schema_repairs:
            print(
                f"\n::notice title={PYPI_DISTRIBUTION} REST API::"
                "Published the existing search limit of 100 by correcting "
                "legacy lte metadata to maximum."
            )
            for item in search_limit_schema_repairs:
                print(f"  - GET {item['path']}: {item['text']}")

        if additive_response_oneof:
            print(
                f"\n::notice title={PYPI_DISTRIBUTION} REST API::"
                "Additive oneOf/anyOf expansion or enum-value additions detected "
                "in response schemas. This is expected for extensible "
                "discriminated-union APIs and does not break backward "
                "compatibility."
            )
            for item in additive_response_oneof:
                print(f"  - {item.get('text', str(item))}")
            if response_union_artifacts:
                print(
                    "  - ignored "
                    f"{len(response_union_artifacts)} request/response-property "
                    "removal artifact(s) caused by union widening"
                )
            if union_type_artifacts:
                print(
                    "  - ignored "
                    f"{len(union_type_artifacts)} request/response type-change "
                    "artifact(s) caused by union widening"
                )

        if response_type_widenings:
            print(
                f"\n::notice title={PYPI_DISTRIBUTION} REST API::"
                "Additive response property type widenings detected. The previous "
                "type remains valid, so these changes are accepted with a "
                "release-note-required label."
            )
            for item in response_type_widenings:
                print(f"  - {item.text}")

        if mcp_contract_schema_repairs:
            print(
                f"\n::notice title={PYPI_DISTRIBUTION} REST API::"
                "Typed historically opaque MCP/settings schemas without changing "
                "their runtime wire format."
            )
            for item in mcp_contract_schema_repairs:
                print(f"  - {item.get('text', str(item))}")

        if other_breaking_changes:
            print(
                "::error "
                f"title={PYPI_DISTRIBUTION} REST API::Detected breaking REST API "
                "changes other than removing previously-deprecated operations/"
                "properties, additive response oneOf expansions, or additive "
                "response property type widenings. "
                "REST contract changes must preserve compatibility for 5 minor "
                "releases; keep the old contract available until its scheduled "
                "removal version."
            )
        elif (
            response_union_artifacts or union_type_artifacts
        ) and not additive_response_oneof:
            print(
                f"\n::notice title={PYPI_DISTRIBUTION} REST API::"
                f"Ignored {len(response_union_artifacts)} property-removal and "
                f"{len(union_type_artifacts)} type-change artifact(s) reported "
                "while widening schemas."
            )

        print("\nBreaking REST API changes detected compared to baseline release:")
        for text in breaking_changes:
            print(f"- {text.get('text', str(text))}")

        _write_response_type_widening_report(
            response_type_widenings,
            changes_since_base=response_type_widenings_since_base,
        )

        if not (removal_errors or property_removal_errors or other_breaking_changes):
            print(
                "Breaking changes are limited to previously-deprecated operations "
                "or properties whose scheduled removal versions have been reached, "
                "the accepted POST /api/cloud-proxy removal, the accepted "
                "GET /api/vscode/url base_url default removal, additive response "
                "oneOf expansions, and/or additive response property type widenings."
                " It may also include wire-compatible repairs of historically "
                "opaque MCP/settings schemas or the existing search limit of 100."
            )
        else:
            return 1

    return 1 if (static_policy_errors or deprecation_policy_errors) else 0


if __name__ == "__main__":
    raise SystemExit(main())
