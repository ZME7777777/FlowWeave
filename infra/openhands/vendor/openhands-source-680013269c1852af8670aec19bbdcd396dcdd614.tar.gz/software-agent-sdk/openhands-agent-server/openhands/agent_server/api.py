import asyncio
import os
import shutil
import sys
import tempfile
import traceback
import uuid
from collections.abc import AsyncIterator, Sequence
from contextlib import asynccontextmanager, suppress
from importlib.metadata import version
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

import libtmux
from fastapi import APIRouter, Depends, FastAPI, HTTPException
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from starlette.requests import Request

from openhands.agent_server.acp_router import acp_router
from openhands.agent_server.agent_profiles_router import agent_profiles_router
from openhands.agent_server.auth_router import auth_router
from openhands.agent_server.bash_router import bash_router
from openhands.agent_server.bash_service import get_default_bash_event_service
from openhands.agent_server.canvas_extensions.backend import (
    CanvasExtensionBackendManager,
)
from openhands.agent_server.canvas_extensions.bridge import AppBackendSessionStore
from openhands.agent_server.canvas_extensions_bridge_router import (
    app_backend_bridge_router,
)
from openhands.agent_server.canvas_extensions_router import canvas_extensions_router
from openhands.agent_server.config import (
    Config,
    get_default_config,
)
from openhands.agent_server.conversation_lease import _is_pid_alive
from openhands.agent_server.conversation_registry import (
    create_conversation_registry,
)
from openhands.agent_server.conversation_router import (
    conversation_catalog_router,
    conversation_router,
)
from openhands.agent_server.conversation_service import (
    CredentialBindingActivationRequired,
    get_default_conversation_service,
)
from openhands.agent_server.credential_binding import (
    router as credential_binding_router,
)
from openhands.agent_server.dependencies import (
    check_session_api_key,
    check_workspace_session,
)
from openhands.agent_server.event_service import ConversationRunLimitExceeded
from openhands.agent_server.file_router import file_discovery_router, file_router
from openhands.agent_server.git_router import git_router
from openhands.agent_server.hooks_router import hooks_router
from openhands.agent_server.init_router import (
    InitService,
    init_router,
    require_initialized,
)
from openhands.agent_server.llm_router import llm_router
from openhands.agent_server.local_secret_resolver import local_secret_resolution
from openhands.agent_server.mcp_router import mcp_router
from openhands.agent_server.meta_profiles_router import meta_profiles_router
from openhands.agent_server.middleware import CORSDispatcher
from openhands.agent_server.openai.router import (
    check_openai_api_key,
    openai_router,
)
from openhands.agent_server.plugins_router import plugins_router
from openhands.agent_server.profiles_router import profiles_router
from openhands.agent_server.provider_connections_router import (
    provider_connections_router,
)
from openhands.agent_server.server_details_router import (
    get_server_info,
    mark_initialization_complete,
    server_details_router,
)
from openhands.agent_server.settings_router import settings_router
from openhands.agent_server.skills_router import skills_router
from openhands.agent_server.sub_agents_router import sub_agents_router
from openhands.agent_server.telemetry import (
    build_telemetry_sink,
    emit_server_started,
    emit_server_stopped,
    get_event_factory,
    get_telemetry_sink,
    shutdown_telemetry_sink,
)
from openhands.agent_server.telemetry.factory import (
    DISTINCT_ID_HEADER,
    distinct_id_from_header,
)
from openhands.agent_server.telemetry.models import (
    EventName,
    RequestFailedProperties,
)
from openhands.agent_server.telemetry.sanitizer import normalize_exception
from openhands.agent_server.tool_preload_service import get_tool_preload_service
from openhands.agent_server.tool_router import tool_router
from openhands.agent_server.vscode_router import vscode_router
from openhands.agent_server.vscode_service import get_vscode_service
from openhands.agent_server.workspaces_router import workspaces_router
from openhands.sdk.logger import DEBUG, get_logger
from openhands.sdk.tool.registry import seal_tool_catalog, unseal_tool_catalog
from openhands.sdk.utils.redact import sanitize_dict
from openhands.tools.terminal.constants import (
    TMUX_SOCKET_NAME,
    TMUX_SOCKET_OWNER_OPTION,
)
from openhands.tools.terminal.terminal.tmux_terminal import _socket_creation_lock


logger = get_logger(__name__)


# tmux binds $TMUX_TMPDIR/tmux-<uid>/<socket name>, and fails with "File name
# too long" when that does not fit sockaddr_un.sun_path (108 bytes on Linux,
# 104 on macOS and the BSDs, NUL included).
_MAX_TMUX_SOCKET_PATH = 107 if sys.platform.startswith("linux") else 103
_MAX_TMUX_SOCKET_NAME = len(f"{TMUX_SOCKET_NAME}-{uuid.uuid4().hex}")
_SHORT_TMUX_TMPDIR_ROOT = Path("/tmp")


def _fits_tmux_socket(tmux_tmpdir: Path) -> bool:
    if os.name != "posix":
        return True
    socket_dir = Path(os.path.realpath(tmux_tmpdir)) / f"tmux-{os.getuid()}"
    socket_path_len = len(os.fsencode(socket_dir)) + 1 + _MAX_TMUX_SOCKET_NAME
    return socket_path_len <= _MAX_TMUX_SOCKET_PATH


def _default_server_tmux_tmpdir() -> Path:
    name = f"openhands-agent-server-{os.getpid()}"
    tmux_tmpdir = Path(tempfile.gettempdir()) / name
    if _fits_tmux_socket(tmux_tmpdir):
        return tmux_tmpdir
    # macOS's per-user $TMPDIR (/var/folders/...) is too deep for a socket.
    return _SHORT_TMUX_TMPDIR_ROOT / name


def _ensure_server_tmux_tmpdir() -> tuple[Path, bool, bool]:
    """Return the tmux directory, whether it was defaulted, and whether this
    call created it (only then is it removed at shutdown)."""
    existing = os.getenv("TMUX_TMPDIR")
    if existing and _fits_tmux_socket(Path(existing)):
        return Path(existing), False, False

    tmux_tmpdir = _default_server_tmux_tmpdir()
    created = not tmux_tmpdir.exists()
    tmux_tmpdir.mkdir(parents=True, exist_ok=True)
    os.environ["TMUX_TMPDIR"] = str(tmux_tmpdir)
    if existing:
        logger.warning(
            "TMUX_TMPDIR %s is too long for tmux socket paths; "
            "using per-server tmux directory %s instead",
            existing,
            tmux_tmpdir,
        )
    else:
        logger.info(
            "TMUX_TMPDIR not set; defaulting to per-server tmux directory %s",
            tmux_tmpdir,
        )
    return tmux_tmpdir, True, created


def _isolated_socket_names(socket_dir: Path) -> list[str]:
    """Return per-instance socket names present in *socket_dir*."""
    return [
        path.name
        for path in socket_dir.glob(f"{TMUX_SOCKET_NAME}-" + "[0-9a-f]" * 32)
        if path.is_socket()
    ]


def _kill_sessions(server: libtmux.Server) -> None:
    for session in server.sessions:
        try:
            session.kill()
        except Exception as e:
            logger.warning("Failed to kill tmux session %s: %s", session, e)


def _socket_owner_pid(server: libtmux.Server) -> int | None:
    """Return the recorded owner PID for a socket, or None when unknown."""
    try:
        raw = server.show_option(
            TMUX_SOCKET_OWNER_OPTION, global_=True, scope=None, ignore_errors=True
        )
    except Exception:
        return None
    if raw is None:
        return None
    try:
        return int(str(raw).strip())
    except ValueError:
        return None


def _reclaim_stale_tmux_sockets(socket_dir: Path) -> None:
    """Reclaim the legacy socket and any isolated socket whose owner is gone."""
    try:
        _kill_sessions(libtmux.Server(socket_name=TMUX_SOCKET_NAME))
    except Exception as e:
        logger.warning("Failed to cleanup tmux socket %s: %s", TMUX_SOCKET_NAME, e)

    for socket_name in _isolated_socket_names(socket_dir):
        try:
            server = libtmux.Server(socket_name=socket_name)
            owner_pid = _socket_owner_pid(server)
            if owner_pid is not None and _is_pid_alive(owner_pid):
                logger.debug(
                    "Leaving tmux socket %s alone; owner pid %s is alive",
                    socket_name,
                    owner_pid,
                )
                continue
            _kill_sessions(server)
        except Exception as e:
            logger.warning("Failed to cleanup tmux socket %s: %s", socket_name, e)


def _cleanup_stale_tmux_sessions() -> None:
    """Clean up legacy and isolated terminal sockets on server startup.

    The legacy socket (``openhands``) is always reclaimed. Per-instance
    sockets (``openhands-<32 hex>``) are only reclaimed when their owning
    process is gone: several agent-servers may share one externally supplied
    ``TMUX_TMPDIR``, and killing a live sibling's sessions silently destroys
    that conversation's terminal.

    The scan holds the same cross-process creation lock that terminal setup
    takes between creating a socket and recording its owner, so a socket that
    is still being set up by a live process is never reclaimed as stale.
    """
    if os.name != "posix":
        return
    socket_dir = Path(os.environ.get("TMUX_TMPDIR", "/tmp")) / f"tmux-{os.getuid()}"

    try:
        with _socket_creation_lock():
            _reclaim_stale_tmux_sockets(socket_dir)
    except Exception as e:
        # The lock only closes a rare startup race; it must never stop cleanup
        # from running (or the server from starting).
        logger.warning("tmux socket creation lock unavailable: %s", e)
        _reclaim_stale_tmux_sockets(socket_dir)


@asynccontextmanager
async def api_lifespan(api: FastAPI) -> AsyncIterator[None]:
    original_tmux_tmpdir = os.environ.get("TMUX_TMPDIR")
    tmux_tmpdir, tmux_tmpdir_was_defaulted, tmux_tmpdir_was_created = (
        _ensure_server_tmux_tmpdir()
    )
    secret_resolution: local_secret_resolution | None = None
    try:
        # Clean up stale tmux sessions from previous server runs
        _cleanup_stale_tmux_sessions()
        backend_manager = getattr(api.state, "canvas_extension_backend_manager", None)
        if backend_manager is not None:
            await backend_manager.reap_orphans()

        config: Config = api.state.config
        deferred = config.deferred_init
        conversation_registry = getattr(
            api.state, "conversation_registry", None
        ) or create_conversation_registry(config)
        api.state.conversation_registry = conversation_registry

        # Answer our own LookupSecret URLs in-process; a loopback fetch made
        # from the event loop cannot be served by the loop blocked on it.
        secret_resolution = local_secret_resolution(config)
        secret_resolution.__enter__()

        # Deferred pods boot with telemetry disabled and are rebuilt by
        # InitService, so they emit `server_started` there instead.
        api.state.telemetry_sink = await build_telemetry_sink(config)
        if not deferred:
            emit_server_started()

        seal_tool_catalog()

        vscode_service = get_vscode_service()
        tool_preload_service = get_tool_preload_service()

        # Define async functions for starting each service
        async def start_vscode_service():
            if vscode_service is not None:
                vscode_started = await vscode_service.start()
                if vscode_started:
                    logger.info("VSCode service started successfully")
                else:
                    logger.warning(
                        "VSCode service failed to start, continuing without VSCode"
                    )
            else:
                logger.info("VSCode service is disabled")

        async def start_tool_preload_service():
            if tool_preload_service is not None:
                tool_preload_started = await tool_preload_service.start()
                if tool_preload_started:
                    logger.info("Tool preload service started successfully")
                else:
                    logger.warning("Tool preload service failed to start - skipping")
            else:
                logger.info("Tool preload service is disabled")

        # Start all services concurrently
        results = await asyncio.gather(
            start_vscode_service(),
            start_tool_preload_service(),
            return_exceptions=True,
        )

        # Check for any exceptions during initialization
        exceptions = [r for r in results if isinstance(r, Exception)]
        if exceptions:
            logger.error(
                "Service initialization failed with %d exception(s): %s",
                len(exceptions),
                exceptions,
            )
            # Re-raise the first exception to prevent server from starting
            raise RuntimeError(
                f"Server initialization failed with {len(exceptions)} exception(s)"
            ) from exceptions[0]

        async def stop_stateless_services():
            async def stop_vscode_service():
                if vscode_service is not None:
                    await vscode_service.stop()

            async def stop_tool_preload_service():
                if tool_preload_service is not None:
                    await tool_preload_service.stop()

            await asyncio.gather(
                stop_vscode_service(),
                stop_tool_preload_service(),
                return_exceptions=True,
            )

        # In deferred-init mode the conversation service is *not* entered
        # here — that happens later, when POST /api/init delivers the runtime
        # config. We still mark the /ready endpoint as ready so a warm-pool
        # orchestrator can tell the pod has finished booting and is
        # available to receive its /api/init payload.
        if deferred:
            init_service = InitService(api, base_config=config)
            api.state.init_service = init_service
            mark_initialization_complete()
            logger.info("Server started in deferred-init mode; awaiting POST /api/init")
            try:
                yield
            finally:
                await init_service.teardown()
                await stop_stateless_services()
            return

        # Non-deferred (legacy) path: build and enter the conversation
        # service as part of the lifespan, exactly as before.
        service = get_default_conversation_service()
        mark_initialization_complete()
        logger.info("Server initialization complete - ready to serve requests")

        bash_svc = get_default_bash_event_service()
        api.state.bash_event_service = bash_svc

        conversation_registry.configure_service(service)
        # Runtime cleanup must precede external-catalog recovery so stale
        # runtime owners cannot lose their expired leases to the outer service.
        await conversation_registry.start()

        async with service:
            api.state.conversation_service = service

            config = api.state.config
            retention_task: asyncio.Task | None = None
            if config.bash_events_retention_seconds is not None:
                retention_task = asyncio.create_task(
                    bash_svc.run_retention_cleanup_loop(
                        config.bash_events_retention_seconds
                    )
                )
                logger.info(
                    "Bash events retention cleanup started (retention: %ds)",
                    config.bash_events_retention_seconds,
                )

            try:
                yield
            finally:
                session_store = getattr(api.state, "app_backend_session_store", None)
                if session_store is not None:
                    await session_store.shutdown()
                await conversation_registry.shutdown()
                if retention_task is not None:
                    retention_task.cancel()
                    with suppress(asyncio.CancelledError):
                        await retention_task

                await stop_stateless_services()
    finally:
        # Outer finally so a startup failure cannot leak the drain task, and
        # after `async with service` so terminal events are still accepted.
        if secret_resolution is not None:
            secret_resolution.__exit__(None, None, None)
        unseal_tool_catalog()
        backend_manager = getattr(api.state, "canvas_extension_backend_manager", None)
        if backend_manager is not None:
            await backend_manager.shutdown()
        emit_server_stopped()
        await shutdown_telemetry_sink()

        if tmux_tmpdir_was_defaulted:
            if os.environ.get("TMUX_TMPDIR") == str(tmux_tmpdir):
                if original_tmux_tmpdir is None:
                    os.environ.pop("TMUX_TMPDIR", None)
                else:
                    os.environ["TMUX_TMPDIR"] = original_tmux_tmpdir
        if tmux_tmpdir_was_created:
            # Only the per-server directory this process created; a
            # user-provided TMUX_TMPDIR is never removed.
            try:
                shutil.rmtree(tmux_tmpdir)
            except OSError as e:
                logger.warning(
                    "Failed to remove per-server tmux directory %s: %s",
                    tmux_tmpdir,
                    e,
                )


def _emit_request_failed(request: Request, exc: Exception, error_id: str) -> None:
    """Report an unhandled 5xx as a sanitized diagnostic event.

    Sends the *route template* (``/api/conversations/{conversation_id}``)
    rather than ``request.url.path``, which embeds real identifiers. Fully
    defensive: an error in the telemetry path must not replace the 500 the
    caller is already getting with a different failure.
    """
    try:
        sink = get_telemetry_sink()
        if not sink.enabled:
            return

        factory = get_event_factory()
        if factory is None:
            return

        route = request.scope.get("route")
        route_template = getattr(route, "path", None)
        if not isinstance(route_template, str) or not route_template:
            # Unmatched route: reporting the raw path could leak identifiers.
            route_template = "/unmatched"

        method = request.method.upper()
        if method not in ("GET", "POST", "PUT", "PATCH", "DELETE", "HEAD", "OPTIONS"):
            return

        fingerprint = normalize_exception(exc)
        # Attribute to the frontend's analytics identity when it supplied one;
        # request-scoped activity has no conversation user_id otherwise.
        distinct_id = distinct_id_from_header(request.headers.get(DISTINCT_ID_HEADER))
        sink.emit(
            factory.build(
                EventName.REQUEST_FAILED,
                RequestFailedProperties(
                    route_template=route_template,
                    method=method,  # type: ignore[arg-type]
                    status_code=500,
                    error_class=fingerprint.error_class,
                    error_category=fingerprint.error_category,
                    error_fingerprint=fingerprint.error_fingerprint,
                    error_id=error_id,
                ),
                user_id=distinct_id,
            )
        )
    except Exception:
        logger.debug("Could not emit request_failed telemetry", exc_info=True)


def _get_root_path(config: Config) -> str:
    root_path = ""
    if config.web_url:
        web_url = urlparse(config.web_url)
        root_path = web_url.path.rstrip("/")
    return root_path


def _create_fastapi_instance(config: Config) -> FastAPI:
    """Create the basic FastAPI application instance.

    Returns:
        Basic FastAPI application with title, description, and lifespan.
    """
    return FastAPI(
        title="OpenHands Agent Server",
        version=version("openhands-agent-server"),
        description=(
            "OpenHands Agent Server - REST/WebSocket interface for OpenHands AI Agent"
        ),
        lifespan=api_lifespan,
        root_path=_get_root_path(config),
    )


def _find_http_exception(exc: BaseExceptionGroup) -> HTTPException | None:
    """Helper function to find HTTPException in ExceptionGroup.

    Args:
        exc: BaseExceptionGroup to search for HTTPException.

    Returns:
        HTTPException if found, None otherwise.
    """
    for inner_exc in exc.exceptions:
        if isinstance(inner_exc, HTTPException):
            return inner_exc
        # Recursively search nested ExceptionGroups
        if isinstance(inner_exc, BaseExceptionGroup):
            found = _find_http_exception(inner_exc)
            if found:
                return found
    return None


def _add_api_routes(app: FastAPI) -> None:
    """Add all API routes to the FastAPI application."""
    conversation_registry = app.state.conversation_registry
    app.include_router(server_details_router)

    # The /api/init endpoint bypasses both the session-key auth and the
    # dormant gate. It has its own X-Init-API-Key auth. When
    # ``deferred_init`` is False the endpoints are still mounted but return
    # 404 because no InitService is registered on app.state — see
    # ``get_init_service``.
    init_api_router = APIRouter(prefix="/api")
    init_api_router.include_router(init_router)
    app.include_router(init_api_router)

    # Header-only auth: applied to every /api/* route EXCEPT the workspace
    # static-file routes (handled separately below). Cookies are NOT honored
    # here so that we don't expand the CSRF surface across the whole API.
    # check_session_api_key reads config from request.app.state at request time,
    # so keys delivered via POST /api/init are honoured without re-registering routes.
    dependencies = [
        # Dormant gate: 503s every /api/* route until POST /api/init completes.
        # No-op for non-deferred deployments.
        Depends(require_initialized),
        Depends(check_session_api_key),
    ]

    api_router = APIRouter(prefix="/api", dependencies=dependencies)
    api_router.include_router(file_discovery_router)
    # Collection routes must precede runtime catch-alls such as
    # ``/conversations/{conversation_id}``.
    api_router.include_router(conversation_catalog_router)
    conversation_registry.add_execution_routes(api_router)
    api_router.include_router(conversation_router)
    api_router.include_router(credential_binding_router)
    api_router.include_router(tool_router)
    api_router.include_router(bash_router)
    api_router.include_router(git_router)
    api_router.include_router(file_router)
    api_router.include_router(vscode_router)
    api_router.include_router(skills_router)
    api_router.include_router(sub_agents_router)
    api_router.include_router(plugins_router)
    api_router.include_router(canvas_extensions_router)
    api_router.include_router(hooks_router)
    api_router.include_router(llm_router)
    api_router.include_router(acp_router)
    api_router.include_router(provider_connections_router)
    api_router.include_router(mcp_router)
    api_router.include_router(settings_router)
    api_router.include_router(workspaces_router)
    api_router.include_router(profiles_router)
    api_router.include_router(agent_profiles_router)
    api_router.include_router(meta_profiles_router)
    # /api/auth/* mints workspace cookies and requires the header to bootstrap,
    # so it lives under the header-only auth group.
    api_router.include_router(auth_router)
    app.include_router(
        openai_router,
        dependencies=[Depends(require_initialized), Depends(check_openai_api_key)],
    )

    # Workspace static-file routes get their own auth group that accepts
    # EITHER the X-Session-API-Key header OR the workspace session cookie.
    # The cookie is required so that <iframe src> / <img src> embeds of
    # workspace artifacts work — browsers cannot attach custom headers to
    # those requests.
    workspace_api_router = APIRouter(
        prefix="/api",
        dependencies=[Depends(require_initialized), Depends(check_workspace_session)],
    )
    workspace_api_router.include_router(conversation_registry.workspace_router)
    app.include_router(workspace_api_router)
    app.include_router(api_router)

    app.include_router(
        app_backend_bridge_router,
        dependencies=[Depends(require_initialized)],
    )
    app.include_router(
        conversation_registry.sockets_router,
        dependencies=[Depends(require_initialized)],
    )


def _setup_static_files(app: FastAPI, config: Config) -> None:
    """Set up static file serving and root redirect if configured.

    Args:
        app: FastAPI application instance.
        config: Configuration object containing static files settings.
    """
    # Only proceed if static files are configured and directory exists
    if not (
        config.static_files_path
        and config.static_files_path.exists()
        and config.static_files_path.is_dir()
    ):
        # Map the root path to server info if there are no static files
        app.get("/", tags=["Server Details"])(get_server_info)
        return

    # Mount static files directory
    app.mount(
        "/static",
        StaticFiles(directory=str(config.static_files_path)),
        name="static",
    )

    # Add root redirect to static files
    @app.get("/", tags=["Server Details"])
    async def root_redirect():
        """Redirect root endpoint to static files directory."""
        # Check if index.html exists in the static directory
        # We know static_files_path is not None here due to the outer condition
        assert config.static_files_path is not None
        index_path = config.static_files_path / "index.html"
        if index_path.exists():
            return RedirectResponse(url="/static/index.html", status_code=302)
        else:
            return RedirectResponse(url="/static/", status_code=302)


def _sanitize_validation_errors(errors: Sequence[Any]) -> list[dict]:
    """Sanitize validation error details to remove sensitive input values.

    FastAPI's default 422 response includes the raw request ``input`` in each
    validation error dict.  If the request contained secret-bearing fields
    (e.g. ``agent.llm.api_key``, MCP server ``env``), those values would be
    echoed back to the caller.  This helper redacts them.

    Args:
        errors: The list of error dicts produced by ``exc.errors()``.

    Returns:
        A new list with ``input`` values sanitized through ``sanitize_dict``.
    """
    sanitized: list[dict] = []
    for error in errors:
        error = dict(error)  # shallow copy so we don't mutate the original
        if "input" in error:
            error["input"] = sanitize_dict(error["input"])
        if isinstance(error.get("ctx"), dict) and isinstance(
            error["ctx"].get("error"), Exception
        ):
            error["ctx"] = {**error["ctx"], "error": str(error["ctx"]["error"])}
        sanitized.append(error)
    return sanitized


def _add_exception_handlers(api: FastAPI) -> None:
    """Add exception handlers to the FastAPI application."""

    @api.exception_handler(ConversationRunLimitExceeded)
    async def _run_limit_handler(
        _request: Request, exc: ConversationRunLimitExceeded
    ) -> JSONResponse:
        return JSONResponse(status_code=429, content={"detail": str(exc)})

    @api.exception_handler(CredentialBindingActivationRequired)
    async def _credential_binding_activation_required_handler(
        _request: Request,
        exc: CredentialBindingActivationRequired,
    ) -> JSONResponse:
        return JSONResponse(
            status_code=409,
            content={
                "detail": str(exc),
                "retryable": True,
            },
        )

    @api.exception_handler(RequestValidationError)
    async def _validation_exception_handler(
        request: Request, exc: RequestValidationError
    ) -> JSONResponse:
        """Handle request validation errors, sanitizing sensitive input.

        FastAPI's default 422 handler echoes the raw request body inside the
        ``detail[].input`` field.  When the request contains secrets (e.g.
        ``agent.llm.api_key``, MCP server ``env``), this would leak credentials
        in the error response.  We intercept the error, redact secret-bearing
        fields, and return a safe 422 response.

        Refs: OpenHands/evaluation#385
        """
        logger.info(
            "Validation error on %s %s: %d error(s)",
            request.method,
            request.url.path,
            len(exc.errors()),
        )
        return JSONResponse(
            status_code=422,
            content={"detail": _sanitize_validation_errors(exc.errors())},
        )

    @api.exception_handler(Exception)
    async def _unhandled_exception_handler(
        request: Request, exc: Exception
    ) -> JSONResponse:
        """Handle unhandled exceptions."""
        # Correlation id that ties the 500 a caller receives to the server-side
        # log line (with full traceback) for this failure, so an otherwise
        # opaque 500 can be matched to its traceback in the server logs.
        error_id = uuid.uuid4().hex
        # Always log that we're in the exception handler for debugging
        logger.debug(
            "Exception handler called for %s %s with %s: %s [error_id=%s]",
            request.method,
            request.url.path,
            type(exc).__name__,
            str(exc),
            error_id,
        )

        content = {
            "detail": "Internal Server Error",
            "exception": str(exc),
            "error_id": error_id,
        }
        # In DEBUG mode, include stack trace in response
        if DEBUG:
            content["traceback"] = traceback.format_exc()
        # Check if this is an HTTPException that should be handled directly
        if isinstance(exc, HTTPException):
            return await _http_exception_handler(request, exc)

        # Check if this is a BaseExceptionGroup with HTTPExceptions
        if isinstance(exc, BaseExceptionGroup):
            http_exc = _find_http_exception(exc)
            if http_exc:
                return await _http_exception_handler(request, http_exc)
            # If no HTTPException found, treat as unhandled exception
            logger.error(
                "Unhandled ExceptionGroup on %s %s [error_id=%s]",
                request.method,
                request.url.path,
                error_id,
                exc_info=(type(exc), exc, exc.__traceback__),
            )
            _emit_request_failed(request, exc, error_id)
            return JSONResponse(status_code=500, content=content)

        # Logs full stack trace for any unhandled error that FastAPI would
        # turn into a 500
        logger.error(
            "Unhandled exception on %s %s [error_id=%s]",
            request.method,
            request.url.path,
            error_id,
            exc_info=(type(exc), exc, exc.__traceback__),
        )
        _emit_request_failed(request, exc, error_id)
        return JSONResponse(status_code=500, content=content)

    @api.exception_handler(HTTPException)
    async def _http_exception_handler(
        request: Request, exc: HTTPException
    ) -> JSONResponse:
        """Handle HTTPExceptions with appropriate logging."""
        # Log 4xx errors at info level (expected client errors like auth failures)
        if 400 <= exc.status_code < 500:
            logger.info(
                "HTTPException %d on %s %s: %s",
                exc.status_code,
                request.method,
                request.url.path,
                exc.detail,
            )
        # Log 5xx errors at error level. HTTPException is intentionally
        # raised flow control — the route picked this status and detail
        # on purpose — so a stack trace adds no information beyond
        # `exc.detail` and makes routine upstream blips look
        # indistinguishable from a process crash. Unhandled exceptions
        # still get a full traceback via _unhandled_exception_handler
        # above. Include the traceback only when DEBUG is on, as an
        # opt-in debugging aid.
        elif exc.status_code >= 500:
            logger.error(
                "HTTPException %d on %s %s: %s",
                exc.status_code,
                request.method,
                request.url.path,
                exc.detail,
                exc_info=(type(exc), exc, exc.__traceback__) if DEBUG else None,
            )
            content = {
                "detail": "Internal Server Error",
                "exception": str(exc),
            }
            if DEBUG:
                content["traceback"] = traceback.format_exc()
            # Don't leak internal details to clients for 5xx errors in production
            return JSONResponse(
                status_code=exc.status_code,
                content=content,
            )

        # Return clean JSON response for all non-5xx HTTP exceptions
        return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail})


def create_app(config: Config | None = None) -> FastAPI:
    """Create and configure the FastAPI application.

    Args:
        config: Configuration object. If None, uses default config.

    Returns:
        Configured FastAPI application.
    """
    if config is None:
        config = get_default_config()
    app = _create_fastapi_instance(config)
    app.state.config = config
    app.state.conversation_registry = create_conversation_registry(config)
    app.state.canvas_extension_backend_manager = CanvasExtensionBackendManager()
    app.state.app_backend_session_store = AppBackendSessionStore()

    _add_api_routes(app)
    _setup_static_files(app, config)
    app.add_middleware(
        CORSDispatcher,
        allow_origins=config.allow_cors_origins,
        allow_origin_regex=config.allow_cors_origin_regex,
    )
    _add_exception_handlers(app)

    return app


# Create the default app instance
api = create_app()
