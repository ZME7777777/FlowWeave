"""HTTP endpoints for managing named LLM configurations (profiles)."""

import asyncio
from typing import Annotated, Any

from fastapi import APIRouter, HTTPException, Path, Request, status
from pydantic import BaseModel, Field, SecretStr

from openhands.agent_server._secrets_exposure import (
    build_expose_context,
    decrypt_incoming_llm_secrets,
    get_cipher,
    get_config,
    parse_expose_secrets_header,
    store_errors,
    translate_missing_cipher,
)
from openhands.agent_server.persistence import (
    PersistedSettings,
    get_agent_profile_store,
    get_llm_profile_store,
    get_provider_connections_store,
    get_settings_store,
)
from openhands.sdk.llm import LLM, Message, TextContent
from openhands.sdk.llm.exceptions import (
    LLMError,
    LLMRateLimitError,
    LLMServiceUnavailableError,
    LLMTimeoutError,
)
from openhands.sdk.llm.llm_profile_store import (
    PROFILE_NAME_PATTERN,
    ProfileLimitExceeded,
)
from openhands.sdk.logger import get_logger
from openhands.sdk.profiles import (
    ProfileReferenced,
    delete_llm_profile,
    rename_llm_profile,
)
from openhands.sdk.settings import OpenHandsAgentSettings
from openhands.sdk.utils.redact import redact_text_secrets


logger = get_logger(__name__)

profiles_router = APIRouter(prefix="/profiles", tags=["Profiles"])

MAX_PROFILES = 50

ProfileName = Annotated[
    str,
    Path(min_length=1, max_length=64, pattern=PROFILE_NAME_PATTERN),
]


class ProfileInfo(BaseModel):
    name: str
    model: str | None = None
    base_url: str | None = None
    provider_connection_id: str | None = None
    provider_connection_broken: bool = False
    api_key_set: bool = False


class ProfileListResponse(BaseModel):
    profiles: list[ProfileInfo]
    active_profile: str | None = None


class ProfileDetailResponse(BaseModel):
    """Secrets are nulled unless explicitly requested via X-Expose-Secrets."""

    name: str
    config: dict[str, Any]
    api_key_set: bool = False


class ProfileMutationResponse(BaseModel):
    name: str
    message: str


class SaveProfileRequest(BaseModel):
    llm: LLM
    include_secrets: bool = Field(
        default=True,
        description="Whether to persist the API key with the profile.",
    )


class RenameProfileRequest(BaseModel):
    new_name: str = Field(
        ...,
        min_length=1,
        max_length=64,
        pattern=PROFILE_NAME_PATTERN,
    )


def _has_api_key(llm: LLM) -> bool:
    if not isinstance(llm.api_key, SecretStr):
        return False
    return bool(llm.api_key.get_secret_value().strip())


def _profile_api_key_set(request: Request, llm: LLM) -> bool:
    """Effective key presence: the profile's own key, or its provider's.

    A profile linked to a provider connection carries no inline key (cleared on
    save), so its key presence lives on the connection.
    """
    if _has_api_key(llm):
        return True
    connection_id = llm.provider_connection_id
    if not connection_id:
        return False
    config = get_config(request)
    cipher = get_cipher(request)
    # The provider store read can raise on a corrupted file; map it instead of
    # letting it surface as an unhandled 500 on GET /profiles/{name}.
    with store_errors():
        connection = get_provider_connections_store(config).get(
            connection_id, cipher=cipher
        )
    return connection is not None and connection.api_key_value() is not None


def _set_active_profile_if_matches(
    request: Request, old_name: str, new_name: str | None
) -> bool:
    config = get_config(request)
    settings_store = get_settings_store(config)
    settings = settings_store.load() or PersistedSettings()
    if settings.active_profile != old_name:
        return False

    def update_active(settings: PersistedSettings) -> PersistedSettings:
        settings.active_profile = new_name
        return settings

    settings_store.update(update_active)
    return True


@profiles_router.get("", response_model=ProfileListResponse)
async def list_profiles(request: Request) -> ProfileListResponse:
    """List all saved LLM profiles.

    Returns the list of profiles along with the currently active profile name,
    if one has been activated. The active_profile tracks which LLM profile
    configuration is currently in use.
    """
    config = get_config(request)
    settings_store = get_settings_store(config)
    settings = settings_store.load() or PersistedSettings()

    store = get_llm_profile_store()
    with store_errors():
        summaries = store.list_summaries()

    return ProfileListResponse(
        profiles=[ProfileInfo(**s) for s in summaries],
        active_profile=settings.active_profile,
    )


@profiles_router.get("/{name}", response_model=ProfileDetailResponse)
async def get_profile(request: Request, name: ProfileName) -> ProfileDetailResponse:
    """Get a profile's configuration.

    Use the ``X-Expose-Secrets`` header to control secret exposure:
    - ``encrypted``: Returns cipher-encrypted values (safe for frontend clients)
    - ``plaintext``: Resolves linked providers and returns raw secret values
      for backend clients constructing a runnable LLM configuration
    - (absent): Returns nulled ``api_key`` with ``api_key_set`` indicator
    """
    expose_mode = parse_expose_secrets_header(request)
    cipher = get_cipher(request)

    store = get_llm_profile_store()
    try:
        with store_errors():
            # Runtime reads need current provider credentials. Editor reads
            # retain the stored reference, including dangling references.
            llm = store.load(
                name, cipher=cipher, resolve_provider=expose_mode == "plaintext"
            )
    except FileNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Profile '{name}' not found",
        )

    if expose_mode:
        context = build_expose_context(expose_mode, cipher)
        with translate_missing_cipher():
            config: dict[str, Any] = llm.model_dump(mode="json", context=context)
    else:
        config = llm.model_dump(mode="json")
        config["api_key"] = None

    return ProfileDetailResponse(
        name=name, config=config, api_key_set=_profile_api_key_set(request, llm)
    )


@profiles_router.post(
    "/{name}",
    response_model=ProfileMutationResponse,
    status_code=status.HTTP_201_CREATED,
)
async def save_profile(
    request: Request,
    name: ProfileName,
    body: SaveProfileRequest,
) -> ProfileMutationResponse:
    """Save an LLM configuration as a named profile.

    Overwrites an existing profile of the same name. Returns 409 if creating
    a new profile would exceed ``MAX_PROFILES``.

    When ``OH_SECRET_KEY`` is configured, secrets are encrypted at rest.
    Clients can submit cipher-encrypted secrets which will be decrypted
    server-side before re-encrypting with the storage cipher.
    """
    cipher = get_cipher(request)
    llm = decrypt_incoming_llm_secrets(body.llm, cipher) if cipher else body.llm
    store = get_llm_profile_store()
    try:
        with store_errors():
            store.save(
                name,
                llm,
                include_secrets=body.include_secrets,
                cipher=cipher,
                max_profiles=MAX_PROFILES,
            )
    except ProfileLimitExceeded:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=(
                f"Profile limit reached ({MAX_PROFILES}). "
                "Delete a profile before saving a new one."
            ),
        )

    logger.info(f"Saved profile '{name}' (include_secrets={body.include_secrets})")
    return ProfileMutationResponse(name=name, message=f"Profile '{name}' saved")


class ValidateProfileRequest(BaseModel):
    """Request body for LLM pre-flight validation.

    Accepts an LLM config (same shape as ``SaveProfileRequest.llm``) so the
    frontend can validate a draft *before* persisting it.
    """

    llm: LLM


class ValidateProfileError(BaseModel):
    """Structured error returned when validation fails."""

    type: str
    message: str


class ValidateProfileResponse(BaseModel):
    """Result of an LLM pre-flight check."""

    valid: bool
    error: ValidateProfileError | None = None


# Errors that should NOT block saving — they are transient and unrelated to
# the correctness of the configuration itself.
_TRANSIENT_ERROR_TYPES = (LLMRateLimitError, LLMTimeoutError)


@profiles_router.post(
    "/{name}/validate",
    response_model=ValidateProfileResponse,
)
async def validate_profile(
    request: Request,
    name: ProfileName,
    body: ValidateProfileRequest,
) -> ValidateProfileResponse:
    """Pre-flight check: fire a minimal LLM completion to catch misconfigurations.

    Instantiates the submitted LLM config and sends a 1-token completion to
    surface errors like invalid model names, missing provider prefixes, bad
    base URLs, and invalid API keys — *before* the profile is saved.

    Transient errors (rate limits, timeouts) are treated as non-blocking: the
    response is ``valid=True`` with no error, since those don't indicate a
    misconfigured profile.
    """
    cipher = get_cipher(request)
    llm = decrypt_incoming_llm_secrets(body.llm, cipher) if cipher else body.llm

    messages = [
        Message(
            role="system",
            content=[TextContent(text="Reply with one token.")],
        ),
        Message(
            role="user",
            content=[TextContent(text="ping")],
        ),
    ]

    try:
        # Restore runtime subscription credentials, mirroring ``from_persisted``.
        # The frontend sends auth_type="subscription" but the OAuth access token
        # lives in the credential store, not in the serialized LLM config. Without
        # this, the pre-flight sends api_key=None and fails with
        # "Incorrect API key provided: None".
        #
        # Run the synchronous factory (which may do a network token refresh)
        # off the event loop and inside the handled path so credential errors
        # surface as ``valid=False`` instead of a 500.
        if getattr(llm, "auth_type", None) == "subscription":
            from openhands.sdk.llm.auth.openai import (
                create_subscription_llm_from_config,
            )

            llm = await asyncio.to_thread(create_subscription_llm_from_config, llm)

        # Mirror the runtime dispatch (see ``LLM.agenerate``) and stay
        # async so provider I/O doesn't pin the FastAPI event loop.
        if llm.uses_responses_api():
            await llm.aresponses(messages=messages, max_tokens=1)
        else:
            await llm.acompletion(messages=messages, max_tokens=1)
    except _TRANSIENT_ERROR_TYPES as exc:
        # Transient — don't block the save
        logger.info(
            f"Profile '{name}' pre-flight hit a transient error "
            f"({type(exc).__name__}); not blocking save."
        )
        return ValidateProfileResponse(valid=True)
    except (
        # LLMServiceUnavailableError (provider 503) is intentionally treated as
        # a blocking config error: at this layer a provider outage is
        # indistinguishable from a wrong base URL, so we prefer a false
        # negative over silently saving a misconfigured profile.
        LLMServiceUnavailableError,
        LLMError,
    ) as exc:
        error_type = type(exc).__name__
        safe_msg = redact_text_secrets(exc.message)
        logger.info(f"Profile '{name}' pre-flight failed: {error_type}: {safe_msg}")
        return ValidateProfileResponse(
            valid=False,
            error=ValidateProfileError(
                type=error_type,
                message=safe_msg,
            ),
        )
    except Exception as exc:
        # Unknown errors — block the save and surface the raw message so the
        # user can debug, but classify generically.
        msg = redact_text_secrets(str(exc) or type(exc).__name__)
        logger.info(f"Profile '{name}' pre-flight failed (unknown): {msg}")
        return ValidateProfileResponse(
            valid=False,
            error=ValidateProfileError(
                type=type(exc).__name__,
                message=msg,
            ),
        )

    return ValidateProfileResponse(valid=True)


@profiles_router.delete("/{name}", response_model=ProfileMutationResponse)
async def delete_profile(
    request: Request, name: ProfileName
) -> ProfileMutationResponse:
    """Delete a saved profile (idempotent).

    Guarded by the agent-profile FK: returns 409 naming the referrers if any
    ``AgentProfile`` still cites this LLM profile via ``llm_profile_ref``.
    """
    store = get_llm_profile_store()
    agent_store = get_agent_profile_store()
    try:
        with store_errors():
            delete_llm_profile(agent_store, store, name)
    except ProfileReferenced as e:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(e))
    if _set_active_profile_if_matches(request, name, None):
        logger.info(f"Cleared active_profile for deleted profile '{name}'")
    logger.info(f"Deleted profile '{name}'")
    return ProfileMutationResponse(name=name, message=f"Profile '{name}' deleted")


@profiles_router.post("/{name}/rename", response_model=ProfileMutationResponse)
async def rename_profile(
    request: Request,
    name: ProfileName,
    body: RenameProfileRequest,
) -> ProfileMutationResponse:
    """Rename a saved profile atomically.

    Returns 404 if the source does not exist, or 409 if ``new_name`` already
    exists. A same-name rename is a verified no-op (still 404s if missing).

    If the renamed profile is the currently active profile, the active_profile
    setting is updated to the new name. Any ``AgentProfile.llm_profile_ref``
    citing the old name is cascaded to the new name in lock-step.
    """
    store = get_llm_profile_store()
    agent_store = get_agent_profile_store()
    try:
        with store_errors():
            rename_llm_profile(agent_store, store, name, body.new_name)
    except FileNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Profile '{name}' not found",
        )
    except FileExistsError:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Profile '{body.new_name}' already exists",
        )

    if name != body.new_name and _set_active_profile_if_matches(
        request, name, body.new_name
    ):
        logger.info(f"Updated active_profile from '{name}' to '{body.new_name}'")

    if name == body.new_name:
        message = f"Profile '{name}' unchanged (same name)"
    else:
        message = f"Profile '{name}' renamed to '{body.new_name}'"
    logger.info(message)
    return ProfileMutationResponse(name=body.new_name, message=message)


class ActivateProfileResponse(BaseModel):
    """Response model for profile activation."""

    name: str
    message: str
    llm_applied: bool = True


@profiles_router.post("/{name}/activate", response_model=ActivateProfileResponse)
async def activate_profile(
    request: Request, name: ProfileName
) -> ActivateProfileResponse:
    """Activate a saved LLM profile.

    This endpoint:
    1. Loads the named profile's LLM configuration
    2. Applies it to the current OpenHands agent settings (updates
       ``agent_settings.llm``); ACP settings have no LLM to update
    3. Records the profile name as the active profile for frontend tracking

    Returns 404 if the profile does not exist.

    Use ``GET /api/profiles`` to see which profile is currently active via
    the ``active_profile`` field.
    """
    cipher = get_cipher(request)
    config = get_config(request)

    # Load the profile. ``load`` resolves any referenced provider connection
    # (read-at-use), so the LLM applied to settings already carries the shared
    # api_key / base_url; ``provider_connection_id`` is retained so a later
    # rotation re-resolves on the next activation or launch.
    profile_store = get_llm_profile_store()
    # A dangling provider_connection_id raises ProviderConnectionNotFound, which
    # store_errors() maps to 422.
    try:
        with store_errors():
            llm = profile_store.load(name, cipher=cipher)
    except FileNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Profile '{name}' not found",
        )

    settings_store = get_settings_store(config)
    llm_applied = False

    def apply_profile(settings: PersistedSettings) -> PersistedSettings:
        nonlocal llm_applied
        if isinstance(settings.agent_settings, OpenHandsAgentSettings):
            settings.agent_settings = settings.agent_settings.model_copy(
                update={"llm": llm}
            )
            llm_applied = True
        settings.active_profile = name
        return settings

    try:
        settings_store.update(apply_profile)
    except (OSError, PermissionError):
        logger.error("Failed to activate profile - file I/O error")
        raise HTTPException(status_code=500, detail="Failed to activate profile")
    except RuntimeError as e:
        logger.error(f"Failed to activate profile: {e}")
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Settings file is corrupted or encrypted with a different key",
        )

    logger.info(f"Activated profile '{name}'")
    return ActivateProfileResponse(
        name=name,
        message=(
            f"Profile '{name}' activated and applied to current settings"
            if llm_applied
            else f"Profile '{name}' activated"
        ),
        llm_applied=llm_applied,
    )
