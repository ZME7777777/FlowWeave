import asyncio
import importlib
import json
import logging
import os
from collections.abc import Awaitable, Callable
from concurrent.futures import ThreadPoolExecutor
from contextlib import asynccontextmanager, suppress
from dataclasses import dataclass, field
from functools import partial
from pathlib import Path
from typing import TYPE_CHECKING, Any, cast
from uuid import UUID, uuid4
from weakref import WeakValueDictionary

import httpx
from pydantic import BaseModel

from openhands.agent_server.config import ACPSkillSourcing, Config, WebhookSpec
from openhands.agent_server.conversation_lease import (
    DEFAULT_LEASE_TTL_SECONDS,
    ConversationLeaseHeldError,
)
from openhands.agent_server.event_service import (
    LEASE_RENEW_INTERVAL_SECONDS,
    EventService,
    RunSlot,
)
from openhands.agent_server.launch import (
    is_codex_source,
    launch_source,
    live_launch_runtime,
    scoped_secrets,
    server_launch_stores,
)
from openhands.agent_server.local_storage import (
    conversation_worktree_dir,
    remove_conversation_worktree,
)
from openhands.agent_server.models import (
    ConversationActivityInfo,
    ConversationActivityPage,
    ConversationInfo,
    ConversationPage,
    ConversationSortOrder,
    LaunchedAgentProfile,
    StartConversationRequest,
    StoredConversation,
    UpdateConversationRequest,
)
from openhands.agent_server.persistence import FileSecretsStore
from openhands.agent_server.pub_sub import Subscriber
from openhands.agent_server.server_details_router import update_last_execution_time
from openhands.agent_server.telemetry import (
    ConversationTelemetryContext,
    DiagnosticEventFactory,
    TelemetrySubscriber,
    get_event_factory,
    get_telemetry_sink,
)
from openhands.agent_server.telemetry.sanitizer import model_family, safe_token
from openhands.agent_server.utils import safe_rmtree, utc_now
from openhands.sdk import LLM, Event, Message
from openhands.sdk.agent import ACPAgent
from openhands.sdk.agent.acp_file_credentials import CODEX_AUTH_SECRET_NAME
from openhands.sdk.agent.base import AgentBase
from openhands.sdk.conversation.impl.local_conversation import LocalConversation
from openhands.sdk.conversation.persistence_const import BASE_STATE
from openhands.sdk.conversation.state import (
    ConversationExecutionStatus,
    ConversationState,
)
from openhands.sdk.conversation.title_utils import (
    extract_message_text,
    generate_title_from_message,
)
from openhands.sdk.credential import (
    CredentialAuthorizationRejected,
    CredentialBindingError,
    VersionedCredentialBinding,
)
from openhands.sdk.event import MessageEvent
from openhands.sdk.event.conversation_state import ConversationStateUpdateEvent
from openhands.sdk.git.exceptions import GitCommandError, GitRepositoryError
from openhands.sdk.git.utils import run_git_command, validate_git_repository
from openhands.sdk.launch import LaunchedAgent, finalize
from openhands.sdk.llm.call_context import LLMCallContext
from openhands.sdk.mcp.utils import MCPToolProvider
from openhands.sdk.observability import OPERATION_METADATA_KEY, observe
from openhands.sdk.tool.client_tool import register_client_tools
from openhands.sdk.tool.registry import get_tool_module_qualnames
from openhands.sdk.utils.cipher import Cipher
from openhands.sdk.workspace import LocalWorkspace


if TYPE_CHECKING:
    from openhands.sdk.subagent.schema import AgentDefinition


_AUTOMATION_TAG_KEYS = ("automationtrigger", "automationid", "automationrunid")


class CredentialBindingActivationRequired(RuntimeError):
    pass


def _build_worktree_guidance(
    *,
    source_workspace: Path,
    worktree_root: Path,
    workspace_dir: Path,
    branch: str,
) -> str:
    return (
        "This conversation uses a dedicated git worktree.\n"
        f"- Original workspace: {source_workspace}\n"
        f"- Worktree root: {worktree_root}\n"
        f"- Active workspace: {workspace_dir}\n"
        f"- Branch: {branch}\n"
        "Do all file and git work inside this worktree. Do your work on a new, "
        "appropriately-named branch, based off the main/master branch, "
        "and do not switch back to the original workspace."
    )


def _has_git_remote(repo_root: Path, remote: str = "origin") -> bool:
    try:
        run_git_command(["git", "remote", "get-url", remote], repo_root)
    except GitCommandError:
        return False
    return True


def _local_branch_exists(repo_root: Path, branch: str) -> bool:
    try:
        run_git_command(
            ["git", "show-ref", "--verify", "--quiet", f"refs/heads/{branch}"],
            repo_root,
        )
    except GitCommandError:
        return False
    return True


def _get_worktree_start_point(repo_root: Path) -> str:
    """Resolve the base ref a new conversation worktree should be created from.

    Policy (in order):
      1. ``origin/<default_branch>`` if an ``origin`` remote is configured.
         ``git fetch origin`` is run first so the worktree starts from the
         latest remote tip; the default branch is resolved via
         ``refs/remotes/origin/HEAD``.
      2. Local ``main`` if there is no usable remote default but ``main``
         exists locally.
      3. Local ``master`` if neither remote default nor local ``main`` is
         available.
      4. Fall back to ``HEAD`` only when none of the above applies, so worktree
         creation still succeeds on freshly initialized repos.
    """
    if _has_git_remote(repo_root):
        try:
            run_git_command(["git", "fetch", "origin"], repo_root, timeout=60)
        except GitCommandError as exc:
            logger.warning(
                "git fetch origin failed while choosing worktree start point "
                "for %s; using cached refs. Error: %s",
                repo_root,
                exc,
            )
        try:
            ref = run_git_command(
                ["git", "symbolic-ref", "refs/remotes/origin/HEAD"],
                repo_root,
            )
        except GitCommandError:
            ref = ""
        prefix = "refs/remotes/origin/"
        if ref.startswith(prefix):
            return f"origin/{ref[len(prefix) :]}"

    if _local_branch_exists(repo_root, "main"):
        return "main"
    if _local_branch_exists(repo_root, "master"):
        return "master"
    return "HEAD"


@dataclass(frozen=True)
class _WorktreePlan:
    repo_root: Path
    source_workspace: Path
    worktree_root: Path
    workspace_dir: Path
    branch: str

    @property
    def guidance(self) -> str:
        return _build_worktree_guidance(
            source_workspace=self.source_workspace,
            worktree_root=self.worktree_root,
            workspace_dir=self.workspace_dir,
            branch=self.branch,
        )


def _plan_conversation_worktree(
    workspace: LocalWorkspace,
    conversation_id: UUID,
    conversation_worktree_root: Path,
) -> _WorktreePlan | None:
    source_workspace = Path(workspace.working_dir).resolve()
    try:
        validate_git_repository(source_workspace)
        repo_root = Path(
            run_git_command(
                ["git", "--no-pager", "rev-parse", "--show-toplevel"],
                source_workspace,
            )
        ).resolve()
    except (GitCommandError, GitRepositoryError):
        return None

    worktree_root = conversation_worktree_root / str(conversation_id) / repo_root.name
    return _WorktreePlan(
        repo_root=repo_root,
        source_workspace=source_workspace,
        worktree_root=worktree_root,
        workspace_dir=worktree_root / source_workspace.relative_to(repo_root),
        branch=f"openhands/{conversation_id}",
    )


def _create_conversation_worktree(plan: _WorktreePlan) -> LocalWorkspace:
    repo_root = plan.repo_root
    plan.worktree_root.parent.mkdir(parents=True, exist_ok=True)

    if plan.worktree_root.exists():
        try:
            run_git_command(
                ["git", "worktree", "remove", "--force", str(plan.worktree_root)],
                repo_root,
            )
        except GitCommandError:
            safe_rmtree(plan.worktree_root)

    run_git_command(["git", "worktree", "prune"], repo_root)

    if run_git_command(["git", "branch", "--list", plan.branch], repo_root):
        run_git_command(["git", "branch", "-D", plan.branch], repo_root)

    run_git_command(
        [
            "git",
            "worktree",
            "add",
            "-b",
            plan.branch,
            str(plan.worktree_root),
            _get_worktree_start_point(repo_root),
        ],
        repo_root,
    )

    plan.workspace_dir.mkdir(parents=True, exist_ok=True)
    return LocalWorkspace(working_dir=plan.workspace_dir)


logger = logging.getLogger(__name__)


class InvalidParentConversation(ValueError):
    """``parent_conversation_id`` is unknown, self-referential, or in
    a different workspace."""


def _same_workspace(a: LocalWorkspace, b: LocalWorkspace) -> bool:
    return Path(a.working_dir).resolve() == Path(b.working_dir).resolve()


def _compose_conversation_info(
    stored: StoredConversation,
    state: ConversationState,
    sub_conversation_ids: list[UUID] | None = None,
) -> ConversationInfo:
    # Use mode='json' so SecretStr in nested structures (e.g. LookupSecret.headers,
    # agent.agent_context.secrets) serialize to strings. Without it, validation
    # fails because ConversationInfo expects dict[str, str] but receives SecretStr.
    #
    # ACP model state is lifted onto top-level ConversationInfo fields because
    # the agent holds it in PrivateAttrs (ACPAgent is frozen) which don't survive
    # ``model_dump``. ``getattr`` keeps non-ACP agents a no-op. We read the live
    # agent (fresh within a session) and fall back to ``state.agent_state`` —
    # persisted to ``base_state.json`` by ``ACPAgent._init`` (and kept in sync by
    # ``switch_acp_model``) — so cold list reads, where PrivateAttrs are still
    # empty because ``init_state`` hasn't fired, still surface the last-known
    # state. Persisted ``acp_available_models`` is a list of dicts that
    # ``ConversationInfo`` coerces back into ``ACPModelInfo``.
    agent_state = getattr(state, "agent_state", {}) or {}
    agent = state.agent
    # current_model_id: live PrivateAttr (fresh after a runtime switch) → the
    # persisted hint → the authoritative ``acp_model`` the agent runs on resume.
    #
    # The ``acp_model`` fallback is gated on the agent NOT being a live,
    # initialized one. Once ``init_state`` has fired, ``current_model_id`` is the
    # authoritative resolved value — including ``None`` when an override couldn't
    # be applied (unknown provider, or a resume whose model-selection call the
    # server rejected) — so falling back to ``acp_model`` there would re-assert an
    # override the live session isn't actually running. The fallback is only for
    # *cold* reads (``init_state`` hasn't fired, PrivateAttrs still empty), where
    # the serialized ``acp_model`` is the best last-known hint. The persisted
    # ``acp_current_model_id`` hint is kept honest by ``ACPAgent.init_state`` (it
    # clears the value whenever the override wasn't applied), so it's safe in
    # both cases.
    agent_initialized = bool(getattr(agent, "_initialized", False))
    current_model_id = (
        getattr(agent, "current_model_id", None)
        or agent_state.get("acp_current_model_id")
        or (None if agent_initialized else getattr(agent, "acp_model", None))
    )
    # available_models: the property returns ``[]`` (never ``None``) for *both* a
    # cold-read agent (PrivateAttr default, init_state hasn't fired) and a live
    # agent that genuinely has no models, so an ``is None`` check can't tell them
    # apart — and would drop the persisted picker payload on every cold list
    # read. The ``or`` chain is deliberate: an empty live list falls back to the
    # persisted snapshot, which is exactly right on cold reads (surface the
    # last-known list) and benign for a live empty session (the persisted value
    # is itself empty/absent there).
    available_models = (
        getattr(agent, "available_models", None)
        or agent_state.get("acp_available_models")
        or []
    )
    # Static provider capability. Unlike the two fields above it has no
    # meaningful live-vs-persisted distinction — it's derived from the stable
    # provider identity and written once at session init — so we read the
    # persisted value directly. Defaults False for non-ACP agents and
    # conversations that haven't started a session.
    supports_runtime_model_switch = bool(
        agent_state.get("acp_supports_runtime_model_switch", False)
    )
    return ConversationInfo(
        **state.model_dump(mode="json"),
        title=stored.title,
        metrics=stored.metrics,
        created_at=stored.created_at,
        updated_at=stored.updated_at,
        forked_from_conversation_id=stored.forked_from_conversation_id,
        forked_from_event_id=stored.forked_from_event_id,
        parent_conversation_id=stored.parent_conversation_id,
        sub_conversation_ids=sub_conversation_ids or [],
        current_model_id=current_model_id,
        available_models=available_models,
        supports_runtime_model_switch=supports_runtime_model_switch,
        client_tools=stored.client_tools,
        tool_module_qualnames=dict(stored.tool_module_qualnames),
        launched_agent_profile=stored.launched_agent_profile,
    )


def _compose_conversation_info_sync(
    stored: StoredConversation,
    state: ConversationState,
    sub_conversation_ids: list[UUID] | None = None,
) -> ConversationInfo:
    with state:
        return _compose_conversation_info(stored, state, sub_conversation_ids)


def _compose_webhook_conversation_info(
    stored: StoredConversation, state: ConversationState
) -> ConversationInfo:
    return _compose_conversation_info(stored, state)


def _update_state_tags_sync(
    state: ConversationState, tags: dict[str, str]
) -> ConversationState:
    with state:
        state.tags = tags
    return state


def _compose_webhook_conversation_info_sync(
    stored: StoredConversation, state: ConversationState
) -> ConversationInfo:
    return _compose_conversation_info_sync(stored, state)


def _register_agent_definitions(
    agent_defs: list["AgentDefinition"],
    *,
    context: str,
) -> None:
    """Register agent definitions into the subagent registry.

    Used both when creating new conversations (definitions forwarded from the
    client) and when resuming persisted ones (definitions stored in meta.json).
    """
    from openhands.sdk.subagent.registry import (
        agent_definition_to_factory,
        register_agent_if_absent,
    )

    registered = 0
    for agent_def in agent_defs:
        try:
            factory = agent_definition_to_factory(agent_def)
            register_agent_if_absent(
                name=agent_def.name,
                factory_func=factory,
                description=agent_def,
            )
            registered += 1
        except Exception as e:
            logger.warning(
                f"Failed to register agent definition "
                f"'{agent_def.name}' ({context}): {e}"
            )
    logger.debug(
        f"Registered {registered}/{len(agent_defs)} agent definition(s) ({context})"
    )


def _state_signature(base_state_path: str) -> tuple[int, int] | None:
    """Change-detection token for ``base_state.json``. ``None`` if unreadable.

    ``str`` + ``os.stat`` rather than ``Path``: this runs per conversation on
    every status-filtered query, and ``Path`` costs more than the syscall.
    """
    with suppress(OSError):
        stat = os.stat(base_state_path)
        return (stat.st_mtime_ns, stat.st_size)
    return None


def _stored_metadata_signature(stored: StoredConversation) -> int:
    """Change-detection fingerprint for ``stored`` metadata on a cached row.

    ``cached_info`` is keyed by ``base_state.json``, but also embeds
    ``StoredConversation`` metadata that can change independently via
    ``meta.json`` (notably auto-title). Fingerprint exactly the fields
    ``_compose_conversation_info`` lifts from ``stored`` so a metadata-only
    update invalidates the cache. Keep the set in sync with that function.
    """
    metadata = stored.model_dump(
        mode="json",
        include={
            "title",
            "metrics",
            "created_at",
            "updated_at",
            "forked_from_conversation_id",
            "forked_from_event_id",
            "parent_conversation_id",
            "client_tools",
            "launched_agent_profile",
        },
    )
    return hash(json.dumps(metadata, sort_keys=True, default=str))


def _read_execution_status_sync(
    base_state_path: str,
) -> ConversationExecutionStatus | None:
    """Read only ``execution_status`` from a persisted base state.

    Validating the full ``ConversationState`` costs an agent, LLM config,
    workspace, secret registry and stats blob to reach one enum field.
    """
    with suppress(OSError, ValueError):
        with open(base_state_path, "rb") as f:
            payload = json.loads(f.read())
        return ConversationExecutionStatus(
            payload.get("execution_status", ConversationExecutionStatus.IDLE.value)
        )
    return None


@dataclass
class _ConversationRecord:
    stored: StoredConversation
    execution_status: ConversationExecutionStatus
    # Signature when execution_status was last read. None = unverified, re-read.
    state_signature: tuple[int, int] | None = None
    # Memoised by _base_state_path.
    base_state_path: str | None = None
    # Full ConversationInfo composed from the persisted state at
    # ``state_signature``. Sidebar polling repeatedly asks for the same rows;
    # keep the validated object until base_state.json changes rather than
    # reparsing a large nested ConversationState on every request.
    cached_info: ConversationInfo | None = None
    # Fingerprint of ``stored`` metadata (title, metrics, …) as of the last
    # composition. ``cached_info`` is keyed by ``state_signature`` alone, so
    # metadata-only updates (``meta.json``, e.g. auto-title) must also
    # invalidate it.
    stored_signature: int | None = None


@dataclass
class ConversationService:
    """Manage persisted conversations and their live runtimes.

    Startup loads only lightweight metadata. An ``EventService`` and its event
    history are hydrated when a conversation needs a live runtime.
    """

    conversations_dir: Path = field()
    webhook_specs: list[WebhookSpec] = field(default_factory=list)
    session_api_key: str | None = field(default=None)
    cipher: Cipher | None = None
    runtime_cipher_resolver: Callable[[UUID], Cipher] | None = None
    mcp_tool_provider: MCPToolProvider | None = None
    secrets_store: FileSecretsStore | None = None
    owner_instance_id: str = field(default_factory=lambda: uuid4().hex)
    max_concurrent_runs: int = 10
    lease_ttl_seconds: float = DEFAULT_LEASE_TTL_SECONDS
    conversation_idle_ttl_seconds: float | None = None
    conversation_worktree_root: Path = field(
        default=Path("/tmp/conversation-worktrees")
    )
    acp_skill_sourcing: ACPSkillSourcing = "native"
    max_concurrent_reads: int = 8
    enable_browser: bool = True
    _event_services: dict[UUID, EventService] | None = field(default=None, init=False)
    _conversation_records: dict[UUID, _ConversationRecord] = field(
        default_factory=dict, init=False
    )
    _lifecycle_lock: asyncio.Lock = field(default_factory=asyncio.Lock, init=False)
    _lifecycle_condition: asyncio.Condition = field(
        default_factory=asyncio.Condition, init=False
    )
    _active_lifecycle_operations: int = field(default=0, init=False)
    _exclusive_lifecycle_pending: bool = field(default=False, init=False)
    _conversation_locks: WeakValueDictionary[UUID, asyncio.Lock] = field(
        default_factory=WeakValueDictionary, init=False
    )
    _conversation_webhook_subscribers: list["ConversationWebhookSubscriber"] = field(
        default_factory=list, init=False
    )
    _lease_renewal_task: asyncio.Task | None = field(default=None, init=False)
    _eviction_task: asyncio.Task | None = field(default=None, init=False)
    _run_executor: ThreadPoolExecutor | None = field(default=None, init=False)
    _interactive_executor: ThreadPoolExecutor | None = field(default=None, init=False)
    _read_executor: ThreadPoolExecutor | None = field(default=None, init=False)
    _control_executor: ThreadPoolExecutor | None = field(default=None, init=False)
    _lifecycle_executor: ThreadPoolExecutor | None = field(default=None, init=False)
    _background_executor: ThreadPoolExecutor | None = field(default=None, init=False)
    _lease_executor: ThreadPoolExecutor | None = field(default=None, init=False)
    _run_semaphore: asyncio.Semaphore | None = field(default=None, init=False)
    _credential_bindings: dict[UUID, dict[str, VersionedCredentialBinding]] = field(
        default_factory=dict, init=False
    )

    async def _run_lifecycle[T](
        self, operation: Callable[..., T], *args: object, **kwargs: object
    ) -> T:
        """Run conversation setup away from live reads and controls."""

        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(
            self._lifecycle_executor, partial(operation, *args, **kwargs)
        )

    async def _run_read[T](
        self, operation: Callable[..., T], *args: object, **kwargs: object
    ) -> T:
        """Read one conversation without waiting for catalog scans or statistics."""

        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(
            self._read_executor, partial(operation, *args, **kwargs)
        )

    async def _run_background[T](
        self, operation: Callable[..., T], *args: object, **kwargs: object
    ) -> T:
        """Run catalog/search/statistics work away from live session controls."""

        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(
            self._background_executor, partial(operation, *args, **kwargs)
        )

    async def _run_lease[T](
        self, operation: Callable[..., T], *args: object, **kwargs: object
    ) -> T:
        """Run lease file I/O on its dedicated recovery lane."""

        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(
            self._lease_executor, partial(operation, *args, **kwargs)
        )

    def _load_catalog_sync(
        self, conversation_id: UUID | None = None
    ) -> dict[UUID, _ConversationRecord]:
        records: dict[UUID, _ConversationRecord] = {}
        directories = (
            [self.conversations_dir / conversation_id.hex]
            if conversation_id is not None
            else self.conversations_dir.iterdir()
        )
        for conversation_dir in directories:
            meta_file = conversation_dir / "meta.json"
            if not meta_file.exists():
                continue
            try:
                stored = StoredConversation.model_validate_json(
                    meta_file.read_text(),
                    context={"cipher": self._cipher_for(UUID(conversation_dir.name))},
                )
                execution_status = ConversationExecutionStatus.IDLE
                base_state_file = conversation_dir / BASE_STATE
                base_state_path = str(base_state_file)
                # Signature before read, so a racing write leaves a stale
                # signature and the next query re-reads rather than trusting it.
                signature = _state_signature(base_state_path)
                if base_state_file.exists():
                    # Strict on purpose: a corrupt base state still drops the
                    # conversation from the catalog and logs below.
                    payload = json.loads(base_state_file.read_text())
                    execution_status = ConversationExecutionStatus(
                        payload.get(
                            "execution_status", ConversationExecutionStatus.IDLE.value
                        )
                    )
                else:
                    signature = None
                records[stored.id] = _ConversationRecord(
                    stored=stored,
                    execution_status=execution_status,
                    state_signature=signature,
                    base_state_path=base_state_path,
                )
            except Exception:
                logger.exception(
                    "error_loading_conversation_catalog:%s",
                    conversation_dir,
                    stack_info=True,
                )
        return records

    def _base_state_path(
        self, conversation_id: UUID, record: _ConversationRecord
    ) -> str:
        """Memoised path to a conversation's ``base_state.json``."""
        path = record.base_state_path
        if path is None:
            path = str(self.conversations_dir / conversation_id.hex / BASE_STATE)
            record.base_state_path = path
        return path

    def _cipher_for(self, conversation_id: UUID) -> Cipher | None:
        if self.runtime_cipher_resolver is not None:
            return self.runtime_cipher_resolver(conversation_id)
        return self.cipher

    def _load_persisted_state_sync(
        self, conversation_id: UUID
    ) -> ConversationState | None:
        base_state_file = self.conversations_dir / conversation_id.hex / BASE_STATE
        if not base_state_file.exists():
            return None
        cipher = self._cipher_for(conversation_id)
        context = {"cipher": cipher} if cipher else None
        return ConversationState.model_validate_json(
            base_state_file.read_text(), context=context
        )

    def _agent_from_base_state(self, conversation_id: UUID) -> AgentBase | None:
        """Return the persisted agent from ``base_state.json`` (its single source
        of truth), or ``None`` if there is no persisted state yet.

        Used by cold-path checks (e.g. codex-agent detection) that used to read
        the agent from ``meta.json`` before the agent was removed from it.
        """
        state = self._load_persisted_state_sync(conversation_id)
        return state.agent if state is not None else None

    def _children_index(self) -> dict[UUID, list[UUID]]:
        """Reverse map parent_id -> child ids; rebuilt per call because the
        catalog is mutated from several places and a cache could go stale."""
        index: dict[UUID, list[UUID]] = {}
        for child_id, record in self._conversation_records.items():
            parent_id = record.stored.parent_conversation_id
            if parent_id is not None:
                index.setdefault(parent_id, []).append(child_id)
        return index

    def _children_of(self, conversation_id: UUID) -> list[UUID]:
        return [
            child_id
            for child_id, record in self._conversation_records.items()
            if record.stored.parent_conversation_id == conversation_id
        ]

    async def activate_credential_binding(
        self,
        conversation_id: UUID,
        secret_name: str,
        binding: VersionedCredentialBinding,
    ) -> None:
        async with self._conversation_lifecycle(conversation_id):
            event_services = self._event_services
            event_service = (
                event_services.get(conversation_id)
                if event_services is not None
                else None
            )
            record = self._conversation_records.get(conversation_id)
            stored = (
                event_service.stored
                if event_service is not None
                else (record.stored if record is not None else None)
            )
            if stored is not None and not self._profile_allows_secret(
                stored, secret_name
            ):
                raise CredentialAuthorizationRejected(
                    "The launched agent profile excludes this credential"
                )
            if event_service is not None and event_service.is_open():
                await event_service.activate_credential_binding(secret_name, binding)
                record = self._conversation_records.get(conversation_id)
                if record is not None:
                    record.stored = event_service.stored
                    record.cached_info = None
                return
            self._credential_bindings.setdefault(conversation_id, {})[secret_name] = (
                binding
            )

    async def prepare_for_sandbox_pause(self) -> None:
        async with self._exclusive_lifecycle():
            event_services = self._event_services
            if event_services is None:
                raise ValueError("inactive_service")
            active_services = tuple(event_services.items())
            results = await asyncio.gather(
                *(
                    event_service.__aexit__(None, None, None)
                    for _, event_service in active_services
                ),
                return_exceptions=True,
            )
            first_error: BaseException | None = None
            for (conversation_id, event_service), result in zip(
                active_services, results, strict=True
            ):
                if isinstance(result, BaseException):
                    if first_error is None:
                        first_error = result
                    continue
                record = self._conversation_records.get(conversation_id)
                if record is not None:
                    record.stored = event_service.stored
                    record.cached_info = None
                event_services.pop(conversation_id, None)
            if first_error is not None:
                raise first_error
            self._credential_bindings = {}

    @staticmethod
    def _profile_allows_secret(stored: StoredConversation, name: str) -> bool:
        profile = stored.launched_agent_profile
        return profile is None or profile.allows_secret(name)

    @staticmethod
    def _is_codex_agent(agent: AgentBase | None) -> bool:
        return isinstance(agent, ACPAgent) and agent.acp_server == "codex"

    async def _has_local_codex_credential(self) -> bool:
        if self.secrets_store is None:
            return False
        value = await self._run_lifecycle(
            self.secrets_store.get_secret,
            CODEX_AUTH_SECRET_NAME,
        )
        return value is not None

    async def _resolve_credential_bindings(
        self,
        stored: StoredConversation,
        agent: AgentBase | None = None,
    ) -> dict[str, VersionedCredentialBinding]:
        # The agent no longer lives on ``stored`` (meta.json). Callers pass the
        # agent explicitly (the new-conversation request agent, or the live
        # agent); otherwise fall back to the persisted base_state.json agent.
        # Read it off the event loop — it does blocking file I/O, mirroring the
        # ``_load_persisted_state_sync`` usage elsewhere.
        if agent is None:
            agent = await self._run_lifecycle(self._agent_from_base_state, stored.id)
        bindings = {
            name: binding
            for name, binding in self._credential_bindings.pop(stored.id, {}).items()
            if self._profile_allows_secret(stored, name)
        }
        if (
            self._profile_allows_secret(stored, CODEX_AUTH_SECRET_NAME)
            and CODEX_AUTH_SECRET_NAME not in bindings
            and self._is_codex_agent(agent)
            and await self._has_local_codex_credential()
        ):
            assert self.secrets_store is not None
            from openhands.agent_server.credential_binding import (
                LocalVersionedCredentialBinding,
            )

            bindings[CODEX_AUTH_SECRET_NAME] = LocalVersionedCredentialBinding(
                self.secrets_store,
                CODEX_AUTH_SECRET_NAME,
            )
        return bindings

    async def _conversation_info(
        self,
        conversation_id: UUID,
        record: _ConversationRecord,
        children_index: dict[UUID, list[UUID]] | None = None,
        *,
        interactive: bool = False,
    ) -> ConversationInfo | None:
        read = self._run_read if interactive else self._run_background
        event_services = self._event_services
        if event_services is None:
            raise ValueError("inactive_service")

        children = (
            children_index.get(conversation_id, [])
            if children_index is not None
            else self._children_of(conversation_id)
        )

        event_service = event_services.get(conversation_id)
        if event_service is not None and event_service.is_open():
            live = True
            # Do not acquire the live ConversationState's FIFOLock just to list
            # a sidebar row. Native OpenHands arun() intentionally holds that
            # lock across an entire LLM/tool step, which can last minutes; with
            # several parallel runs, composing every live row waits behind each
            # active step and serializes conversation search. The autosaved
            # base_state.json is the listing snapshot and has the same signature-
            # keyed cache as idle conversations. Live detail/event endpoints
            # remain authoritative for an individual open conversation.
            record.stored = event_service.stored
        else:
            live = False

        signature = _state_signature(self._base_state_path(conversation_id, record))
        if signature is None and event_service is not None and event_service.is_open():
            # Direct embedders/tests can inject a live EventService without a
            # persisted state file. There is no disk snapshot to list in that
            # case, so retain the live-state fallback.
            state = await event_service.get_state()
            conversation_info = await read(
                _compose_conversation_info_sync, event_service.stored, state, children
            )
            record.execution_status = conversation_info.execution_status
            return conversation_info

        # ``record.stored`` is refreshed above for live conversations; idle rows
        # keep the catalog copy. Only live conversations can mutate that in-memory
        # object via metadata-only updates (e.g. auto-title, which writes
        # ``meta.json`` without touching ``base_state.json``), so fingerprint it
        # only when the live refresh actually ran — keeps the hot persisted-row
        # sidebar path free of a per-request dump+hash.
        stored_signature = _stored_metadata_signature(record.stored) if live else None
        cached = record.cached_info
        if (
            cached is not None
            and signature == record.state_signature
            and (not live or stored_signature == record.stored_signature)
        ):
            # Parent/child relationships are catalog-derived and can change
            # without touching this conversation's base_state.json.
            if cached.sub_conversation_ids != children:
                cached = cached.model_copy(update={"sub_conversation_ids": children})
                record.cached_info = cached
            return cached

        state = await read(self._load_persisted_state_sync, conversation_id)
        if state is None:
            return None
        conversation_info = await read(
            _compose_conversation_info, record.stored, state, children
        )
        record.state_signature = signature
        record.stored_signature = stored_signature
        record.cached_info = conversation_info
        record.execution_status = conversation_info.execution_status
        return conversation_info

    @staticmethod
    def _refresh_persisted_statuses_sync(
        targets: list[tuple[UUID, str, tuple[int, int] | None]],
    ) -> dict[UUID, tuple[ConversationExecutionStatus | None, tuple[int, int] | None]]:
        """Re-read ``execution_status`` for persisted conversations that changed.

        ``targets`` is ``(conversation_id, base_state_path, cached_signature)``;
        entries whose signature still matches are skipped without a read. Takes
        plain values because it runs in a worker thread. In the result, a
        ``None`` status means "keep the cached one" and a ``None`` signature
        marks the entry unverified.
        """
        refreshed: dict[
            UUID, tuple[ConversationExecutionStatus | None, tuple[int, int] | None]
        ] = {}
        for conversation_id, base_state_path, cached_signature in targets:
            signature = _state_signature(base_state_path)
            if signature is not None and signature == cached_signature:
                continue
            if signature is None:
                # Unreadable (never started, or mid-delete): keep the cached
                # status, unverified, so a later query retries.
                refreshed[conversation_id] = (None, None)
                continue
            status = _read_execution_status_sync(base_state_path)
            refreshed[conversation_id] = (
                (None, None) if status is None else (status, signature)
            )
        return refreshed

    async def _refresh_execution_statuses(self) -> None:
        """Bring every cached ``execution_status`` up to date.

        The index behind status-filtered search and count. Live conversations
        answer from memory; persisted ones cost a ``stat()`` each and are
        re-read only when changed, never as a full ``ConversationState``.
        """
        event_services = self._event_services
        if event_services is None:
            raise ValueError("inactive_service")

        targets: list[tuple[UUID, str, tuple[int, int] | None]] = []
        for conversation_id, record in list(self._conversation_records.items()):
            event_service = event_services.get(conversation_id)
            if event_service is not None and event_service.is_open():
                # Authoritative: we own it, so disk can only be staler.
                state = await event_service.get_state()
                record.execution_status = state.execution_status
                # Autosave will invalidate any signature and cached info we hold.
                record.state_signature = None
                record.cached_info = None
                continue
            targets.append(
                (
                    conversation_id,
                    self._base_state_path(conversation_id, record),
                    record.state_signature,
                )
            )

        if not targets:
            return

        # One thread hop for the catalog, not one per conversation.
        refreshed = await self._run_background(
            self._refresh_persisted_statuses_sync, targets
        )
        for conversation_id, (status, signature) in refreshed.items():
            record = self._conversation_records.get(conversation_id)
            if record is None:
                continue
            event_service = event_services.get(conversation_id)
            if event_service is not None and event_service.is_open():
                # Went live while we were reading disk; memory wins.
                continue
            if status is not None:
                record.execution_status = status
            # A persisted change (or a move to an unreadable state) invalidates
            # any cached ConversationInfo derived from the previous snapshot.
            record.cached_info = None
            record.state_signature = signature

    async def refresh_persisted_conversation(self, conversation_id: UUID) -> None:
        """Refresh one catalog record changed by an external runtime."""
        event_services = self._event_services
        if event_services is None:
            raise ValueError("inactive_service")
        disk_records = await self._run_background(
            self._load_catalog_sync, conversation_id
        )
        if conversation_id not in disk_records:
            event_service = event_services.get(conversation_id)
            if event_service is None or not event_service.is_open():
                self._conversation_records.pop(conversation_id, None)
            return
        record = disk_records[conversation_id]
        event_service = event_services.get(conversation_id)
        if event_service is not None and event_service.is_open():
            return
        existing = self._conversation_records.setdefault(conversation_id, record)
        if existing.stored != record.stored:
            existing.stored = record.stored
            existing.cached_info = None

    async def _reconcile_active_records(self) -> None:
        """Add injected live services to the in-memory catalog."""
        event_services = self._event_services
        if event_services is None:
            raise ValueError("inactive_service")
        for conversation_id, event_service in event_services.items():
            if conversation_id in self._conversation_records:
                continue
            state = await event_service.get_state()
            self._conversation_records[conversation_id] = _ConversationRecord(
                stored=event_service.stored,
                execution_status=state.execution_status,
            )

    def _prepare_persisted_runtime(self, stored: StoredConversation) -> None:
        if stored.tool_module_qualnames:
            for tool_name, module_qualname in stored.tool_module_qualnames.items():
                try:
                    importlib.import_module(module_qualname)
                    logger.debug(
                        "Tool '%s' registered via module '%s' when resuming %s",
                        tool_name,
                        module_qualname,
                        stored.id,
                    )
                except ImportError as exc:
                    logger.warning(
                        "Failed to import module '%s' for tool '%s' when resuming "
                        "%s: %s. Tool will not be available.",
                        module_qualname,
                        tool_name,
                        stored.id,
                        exc,
                    )
        if stored.client_tools:
            register_client_tools(stored.client_tools)
        if stored.agent_definitions:
            _register_agent_definitions(
                stored.agent_definitions,
                context=f"resuming conversation {stored.id}",
            )

    def _get_conversation_lock(self, conversation_id: UUID) -> asyncio.Lock:
        lock = self._conversation_locks.get(conversation_id)
        if lock is None:
            lock = asyncio.Lock()
            self._conversation_locks[conversation_id] = lock
        return lock

    @asynccontextmanager
    async def _conversation_lifecycle(self, conversation_id: UUID):
        async with self._lifecycle_condition:
            await self._lifecycle_condition.wait_for(
                lambda: not self._exclusive_lifecycle_pending
            )
            self._active_lifecycle_operations += 1
        try:
            async with self._get_conversation_lock(conversation_id):
                yield
        finally:
            async with self._lifecycle_condition:
                self._active_lifecycle_operations -= 1
                if self._active_lifecycle_operations == 0:
                    self._lifecycle_condition.notify_all()

    @asynccontextmanager
    async def _exclusive_lifecycle(self):
        async with self._lifecycle_lock:
            try:
                async with self._lifecycle_condition:
                    self._exclusive_lifecycle_pending = True
                    await self._lifecycle_condition.wait_for(
                        lambda: self._active_lifecycle_operations == 0
                    )
                yield
            finally:
                async with self._lifecycle_condition:
                    self._exclusive_lifecycle_pending = False
                    self._lifecycle_condition.notify_all()

    async def _get_or_load_event_service(
        self, conversation_id: UUID
    ) -> EventService | None:
        event_services = self._event_services
        if event_services is None:
            raise ValueError("inactive_service")
        if (
            conversation_id not in event_services
            and conversation_id not in self._conversation_records
        ):
            return None
        async with self._conversation_lifecycle(conversation_id):
            return await self._get_or_load_event_service_locked(conversation_id)

    async def _get_or_load_event_service_locked(
        self,
        conversation_id: UUID,
        *,
        require_runtime_bindings: bool = True,
        agent: AgentBase | None = None,
    ) -> EventService | None:
        event_services = self._event_services
        if event_services is None:
            raise ValueError("inactive_service")

        event_service = event_services.get(conversation_id)
        if event_service is not None and event_service.is_open():
            # Access counts as activity, deferring idle eviction.
            event_service.touch()
            return event_service

        record = self._conversation_records.get(conversation_id)
        if record is None:
            return None

        pending_bindings = self._credential_bindings.get(conversation_id, {})
        missing_bindings = (
            record.stored.required_runtime_credential_bindings - pending_bindings.keys()
        )
        if require_runtime_bindings and missing_bindings:
            raise CredentialBindingActivationRequired(
                "credential_binding_activation_required"
            )

        await self._run_lifecycle(self._prepare_persisted_runtime, record.stored)
        try:
            return await self._start_event_service(record.stored, persisted_agent=agent)
        except ConversationLeaseHeldError as exc:
            logger.debug(
                "Skipping active conversation %s owned by %s until %s",
                conversation_id,
                exc.owner_instance_id,
                exc.expires_at,
            )
            return None

    async def get_conversation(self, conversation_id: UUID) -> ConversationInfo | None:
        if self._event_services is None:
            raise ValueError("inactive_service")
        record = self._conversation_records.get(conversation_id)
        if record is None:
            event_service = self._event_services.get(conversation_id)
            if event_service is None:
                return None
            state = await event_service.get_state()
            record = _ConversationRecord(
                stored=event_service.stored,
                execution_status=state.execution_status,
            )
            self._conversation_records[conversation_id] = record
            return cast(
                ConversationInfo,
                await self._run_read(
                    _compose_conversation_info_sync,
                    event_service.stored,
                    state,
                    self._children_of(conversation_id),
                ),
            )
        return await self._conversation_info(conversation_id, record, interactive=True)

    async def get_acp_conversation(
        self, conversation_id: UUID
    ) -> ConversationInfo | None:
        return await self.get_conversation(conversation_id)

    async def conversation_activity_page(
        self,
        page_id: str | None = None,
        limit: int = 100,
    ) -> ConversationActivityPage:
        """Read catalog activity without hydrating conversation state or events.

        ``updated_at`` is maintained by ``_EventSubscriber`` for every formal
        non-state event, so it is the native activity projection used by
        catalog pollers. The execution status is updated by formal native state
        events, so this path never takes a Conversation state lock.
        """

        # The catalog is populated at startup and updated when a native
        # conversation starts. Do not reconcile or refresh here: both paths
        # can acquire a live Conversation state lock, which would let polling
        # one stalled conversation delay the whole activity projection.
        records = sorted(
            self._conversation_records.items(),
            key=lambda item: item[1].stored.updated_at,
            reverse=True,
        )
        start_index = 0
        if page_id:
            for index, (conversation_id, _) in enumerate(records):
                if conversation_id.hex == page_id:
                    start_index = index
                    break
        page_records = records[start_index : start_index + limit]
        next_page_id = (
            records[start_index + limit][0].hex
            if start_index + limit < len(records)
            else None
        )
        return ConversationActivityPage(
            items=[
                ConversationActivityInfo(
                    id=conversation_id,
                    execution_status=record.execution_status,
                    updated_at=record.stored.updated_at,
                )
                for conversation_id, record in page_records
            ],
            next_page_id=next_page_id,
        )

    async def search_conversations(
        self,
        page_id: str | None = None,
        limit: int = 100,
        execution_status: ConversationExecutionStatus | None = None,
        sort_order: ConversationSortOrder = ConversationSortOrder.CREATED_AT_DESC,
    ) -> ConversationPage:
        items, next_page_id = await self._search_conversations(
            page_id=page_id,
            limit=limit,
            execution_status=execution_status,
            sort_order=sort_order,
        )
        return ConversationPage(
            items=items,
            next_page_id=next_page_id,
        )

    async def search_acp_conversations(
        self,
        page_id: str | None = None,
        limit: int = 100,
        execution_status: ConversationExecutionStatus | None = None,
        sort_order: ConversationSortOrder = ConversationSortOrder.CREATED_AT_DESC,
    ) -> ConversationPage:
        items, next_page_id = await self._search_conversations(
            page_id=page_id,
            limit=limit,
            execution_status=execution_status,
            sort_order=sort_order,
        )
        return ConversationPage(
            items=items,
            next_page_id=next_page_id,
        )

    async def _search_conversations(
        self,
        page_id: str | None,
        limit: int,
        execution_status: ConversationExecutionStatus | None,
        sort_order: ConversationSortOrder,
    ) -> tuple[list[ConversationInfo], str | None]:
        if self._event_services is None:
            raise ValueError("inactive_service")
        await self._reconcile_active_records()

        if execution_status is not None:
            # Refresh before snapshotting below: this awaits, and a conversation
            # going live replaces its catalog record, so a snapshot taken first
            # would filter on the superseded one. Full state is still loaded
            # only for the page items.
            await self._refresh_execution_statuses()

        records = [
            (conversation_id, record)
            for conversation_id, record in self._conversation_records.items()
            if execution_status is None or record.execution_status == execution_status
        ]
        if sort_order in (
            ConversationSortOrder.CREATED_AT,
            ConversationSortOrder.CREATED_AT_DESC,
        ):
            records.sort(
                key=lambda item: item[1].stored.created_at,
                reverse=sort_order == ConversationSortOrder.CREATED_AT_DESC,
            )
        else:
            records.sort(
                key=lambda item: item[1].stored.updated_at,
                reverse=sort_order == ConversationSortOrder.UPDATED_AT_DESC,
            )

        start_index = 0
        if page_id:
            for i, (conversation_id, _) in enumerate(records):
                if conversation_id.hex == page_id:
                    start_index = i
                    break

        items: list[ConversationInfo] = []
        next_page_id = None
        children_index = self._children_index()
        for conversation_id, record in records[start_index:]:
            if len(items) >= limit:
                next_page_id = conversation_id.hex
                break
            conversation_info = await self._conversation_info(
                conversation_id, record, children_index
            )
            if conversation_info is not None:
                items.append(conversation_info)

        return items, next_page_id

    async def count_conversations(
        self,
        execution_status: ConversationExecutionStatus | None = None,
    ) -> int:
        return await self._count_conversations(execution_status=execution_status)

    async def _count_conversations(
        self,
        execution_status: ConversationExecutionStatus | None,
    ) -> int:
        """Count conversations matching the given filters."""
        if self._event_services is None:
            raise ValueError("inactive_service")
        await self._reconcile_active_records()

        if execution_status is None:
            return len(self._conversation_records)

        await self._refresh_execution_statuses()
        return sum(
            1
            for record in self._conversation_records.values()
            if record.execution_status == execution_status
        )

    async def batch_get_conversations(
        self, conversation_ids: list[UUID]
    ) -> list[ConversationInfo | None]:
        """Given a list of ids, get a batch of conversation info, returning
        None for any that were not found."""
        results = await asyncio.gather(
            *[
                self.get_conversation(conversation_id)
                for conversation_id in conversation_ids
            ]
        )
        return results

    async def batch_get_acp_conversations(
        self, conversation_ids: list[UUID]
    ) -> list[ConversationInfo | None]:
        results = await asyncio.gather(
            *[
                self.get_conversation(conversation_id)
                for conversation_id in conversation_ids
            ]
        )
        return results

    async def _notify_conversation_webhooks(self, conversation_info: BaseModel):
        """Notify all conversation webhook subscribers about conversation changes."""
        if not self._conversation_webhook_subscribers:
            return

        # Send notifications to all conversation webhook subscribers in the background
        async def _notify_and_log_errors():
            results = await asyncio.gather(
                *[
                    subscriber.post_conversation_info(conversation_info)
                    for subscriber in self._conversation_webhook_subscribers
                ],
                return_exceptions=True,  # Don't fail if one webhook fails
            )

            # Log any exceptions that occurred
            for i, result in enumerate(results):
                if isinstance(result, Exception):
                    subscriber = self._conversation_webhook_subscribers[i]
                    logger.error(
                        (
                            f"Failed to notify conversation webhook "
                            f"{subscriber.spec.base_url}: {result}"
                        ),
                        exc_info=result,
                    )

        # Create task to run in background without awaiting
        asyncio.create_task(_notify_and_log_errors())

    # Write Methods

    def _has_conversation(self, conversation_id: UUID) -> bool:
        """Whether this id is already known to the service.

        Cheap, non-awaiting hint used to choose the reuse or create path.
        The create path re-checks under the lifecycle lock, because a
        concurrent create for the same id can commit in between.
        """
        event_services = self._event_services
        if event_services is None:
            return False
        existing_record = self._conversation_records.get(conversation_id)
        existing_event_service = event_services.get(conversation_id)
        return existing_record is not None or (
            existing_event_service is not None and existing_event_service.is_open()
        )

    async def _reuse_existing_conversation_locked(
        self,
        conversation_id: UUID,
        request: StartConversationRequest,
    ) -> tuple[ConversationInfo, bool]:
        """Reuse an existing conversation without recreating it.

        The caller must hold this conversation's lifecycle lock, so the
        catalog cannot change between the existence check and the reuse.
        """
        if self._event_services is None:
            raise ValueError("inactive_service")
        existing_record = self._conversation_records.get(conversation_id)
        existing_event_service = self._event_services.get(conversation_id)
        stored = (
            existing_event_service.stored
            if existing_event_service is not None
            else existing_record.stored
            if existing_record is not None
            else None
        )
        if stored is not None:
            request = request.model_copy(
                update={
                    "secrets": {
                        name: value
                        for name, value in request.secrets.items()
                        if self._profile_allows_secret(stored, name)
                    }
                }
            )
        if existing_event_service is not None and existing_event_service.is_open():
            # ``is_open()`` above guarantees a live conversation, so the
            # public getter never raises here.
            existing_agent = existing_event_service.get_conversation().agent
            if (
                self._is_codex_agent(existing_agent)
                and CODEX_AUTH_SECRET_NAME
                not in existing_event_service.credential_bindings
            ):
                # Reuse the live agent we already resolved above instead
                # of letting _resolve_credential_bindings fall back to a
                # synchronous base_state.json read.
                late_bindings = await self._resolve_credential_bindings(
                    existing_event_service.stored, agent=existing_agent
                )
                try:
                    for secret_name, binding in late_bindings.items():
                        await existing_event_service.activate_credential_binding(
                            secret_name,
                            binding,
                        )
                except Exception:
                    pending = self._credential_bindings.setdefault(conversation_id, {})
                    for secret_name, binding in late_bindings.items():
                        pending.setdefault(secret_name, binding)
                    raise
            if (
                CODEX_AUTH_SECRET_NAME in request.secrets
                and CODEX_AUTH_SECRET_NAME
                not in existing_event_service.credential_bindings
            ):
                await existing_event_service.apply_resume_secrets(
                    {CODEX_AUTH_SECRET_NAME: request.secrets[CODEX_AUTH_SECRET_NAME]}
                )
            state = await existing_event_service.get_state()
            self._conversation_records[conversation_id] = _ConversationRecord(
                stored=existing_event_service.stored,
                execution_status=state.execution_status,
            )
            return (
                _compose_conversation_info(
                    existing_event_service.stored,
                    state,
                    self._children_of(conversation_id),
                ),
                False,
            )
        if existing_record is None:
            raise ValueError(f"Persisted conversation {conversation_id} has no record")
        # Read base_state.json through the lifecycle lane so a slow persisted
        # session cannot consume the loop default executor.
        reattach_agent = await self._run_lifecycle(
            self._agent_from_base_state, conversation_id
        )
        managed_codex_credential = self._is_codex_agent(reattach_agent) and (
            CODEX_AUTH_SECRET_NAME in self._credential_bindings.get(conversation_id, {})
            or await self._has_local_codex_credential()
        )
        fallback_secret = request.secrets.get(CODEX_AUTH_SECRET_NAME)
        if managed_codex_credential or fallback_secret is not None:
            original_stored = existing_record.stored
            injected_fallback = (
                not managed_codex_credential and fallback_secret is not None
            )
            if injected_fallback:
                existing_record.stored = original_stored.model_copy(
                    update={
                        "secrets": {
                            **original_stored.secrets,
                            CODEX_AUTH_SECRET_NAME: fallback_secret,
                        }
                    }
                )
            try:
                # Reuse the agent we already parsed from base_state.json
                # above so the load path doesn't read and parse it again.
                event_service = await self._get_or_load_event_service_locked(
                    conversation_id, agent=reattach_agent
                )
            finally:
                if injected_fallback:
                    existing_record.stored = original_stored
            if event_service is not None:
                state = await event_service.get_state()
                return (
                    _compose_conversation_info(
                        event_service.stored,
                        state,
                        self._children_of(conversation_id),
                    ),
                    False,
                )
        conversation_info = await self._conversation_info(
            conversation_id, existing_record
        )
        if conversation_info is None:
            raise ValueError(
                f"Persisted conversation {conversation_id} has no base state"
            )
        return conversation_info, False

    async def start_conversation(
        self, request: StartConversationRequest
    ) -> tuple[ConversationInfo, bool]:
        return await self._start_conversation(request)

    async def start_acp_conversation(
        self, request: StartConversationRequest
    ) -> tuple[ConversationInfo, bool]:
        return await self._start_conversation(request)

    async def _start_conversation(
        self,
        request: StartConversationRequest,
    ) -> tuple[ConversationInfo, bool]:
        """Start a local event_service and return its id."""
        if self._event_services is None:
            raise ValueError("inactive_service")
        conversation_id = request.conversation_id or uuid4()
        if self._has_conversation(conversation_id):
            async with self._conversation_lifecycle(conversation_id):
                return await self._reuse_existing_conversation_locked(
                    conversation_id, request
                )

        with await RunSlot.acquire(self._run_semaphore) as run_slot:
            return await self._create_conversation(request, conversation_id, run_slot)

    async def _create_conversation(
        self,
        request: StartConversationRequest,
        conversation_id: UUID,
        run_slot: RunSlot,
    ) -> tuple[ConversationInfo, bool]:
        # The link is immutable after creation, so cycles beyond self-parent are
        # impossible; allowing reparenting would require a real ancestor walk.
        if request.parent_conversation_id is not None:
            if request.parent_conversation_id == conversation_id:
                raise InvalidParentConversation(
                    "A conversation cannot be its own parent"
                )
            parent_record = self._conversation_records.get(
                request.parent_conversation_id
            )
            if parent_record is None:
                raise InvalidParentConversation(
                    f"Parent conversation {request.parent_conversation_id} not found"
                )
            if not _same_workspace(parent_record.stored.workspace, request.workspace):
                raise InvalidParentConversation(
                    f"Parent conversation {request.parent_conversation_id} belongs "
                    f"to a different workspace"
                )

        runtime_profile = os.getenv("OH_RUNTIME_LAUNCHED_PROFILE")
        runtime_launched_profile = (
            LaunchedAgentProfile.model_validate_json(runtime_profile)
            if runtime_profile
            else None
        )

        from openhands.agent_server.persistence import (
            PersistedSettings,
            get_settings_store,
        )

        # get_settings_store() is safe here: get_instance() initialises the
        # singleton with the server cipher before any conversation can start.
        # FileSettingsStore.load re-raises PermissionError/OSError by design;
        # now that every launch reads it, a bad file mode must not take down
        # request shapes that need nothing from settings.
        try:
            settings = await self._run_lifecycle(
                lambda: get_settings_store().load() or PersistedSettings()
            )
        except (PermissionError, OSError):
            logger.warning(
                "Cannot read settings; starting without the stored agent preferences",
                exc_info=True,
            )
            settings = PersistedSettings()
        # ``ACPAgentSettings.agent_context`` is nullable, hence the guard.
        stored_context = settings.agent_settings.agent_context
        load_memory = bool(stored_context and stored_context.load_memory)

        source = await self._run_lifecycle(
            launch_source,
            request,
            lambda: server_launch_stores(settings, self.cipher),
            self.cipher,
        )
        secrets = scoped_secrets(request.secrets, source)
        managed_codex_credential = is_codex_source(source) and (
            CODEX_AUTH_SECRET_NAME in self._credential_bindings.get(conversation_id, {})
            or await self._has_local_codex_credential()
        )
        if managed_codex_credential:
            secrets.pop(CODEX_AUTH_SECRET_NAME, None)

        # Dynamically register tools from client's registry
        if request.tool_module_qualnames:
            for tool_name, module_qualname in request.tool_module_qualnames.items():
                try:
                    # Import the module to trigger tool auto-registration
                    importlib.import_module(module_qualname)
                    logger.debug(
                        f"Tool '{tool_name}' registered via module '{module_qualname}'"
                    )
                except ImportError as e:
                    logger.warning(
                        f"Failed to import module '{module_qualname}' for tool "
                        f"'{tool_name}': {e}. Tool will not be available."
                    )
                    # Continue even if some tools fail to register
                    # The agent will fail gracefully if it tries to use unregistered
                    # tools
            logger.info(
                "Dynamically registered %d tools for conversation %s",
                len(request.tool_module_qualnames),
                conversation_id,
            )

        # Register client-defined tools (JSON specs, no Python code). The
        # ClientTool *class* is registered statelessly; each tool's schema
        # travels with the conversation via the returned Tool.params, so
        # concurrent conversations never clobber each other's schemas.
        client_tools = (
            register_client_tools(request.client_tools) if request.client_tools else []
        )

        worktree = (
            _plan_conversation_worktree(
                request.workspace, conversation_id, self.conversation_worktree_root
            )
            if request.worktree
            else None
        )
        launched = await self._run_lifecycle(
            lambda: finalize(
                source,
                live_launch_runtime(
                    self.acp_skill_sourcing, enable_browser=self.enable_browser
                ),
                additions=request.agent_launch_additions,
                extra_suffixes=[worktree.guidance] if worktree else (),
                client_tools=client_tools,
                load_memory=load_memory,
                managed_secrets=(
                    [CODEX_AUTH_SECRET_NAME] if managed_codex_credential else ()
                ),
            )
        )
        workspace = (
            _create_conversation_worktree(worktree)
            if worktree is not None
            else request.workspace
        )

        # The server may resolve built-in tools that the creating client does not
        # import, as happens when a lightweight orchestrator starts a runtime
        # conversation. Persist those server-resolved modules so another client
        # can attach and deserialize the resulting tool events.
        registered_tool_modules = get_tool_module_qualnames()
        tool_module_qualnames = dict(request.tool_module_qualnames)
        client_tool_names = {tool.name for tool in client_tools}
        for tool in launched.agent.tools:
            module_qualname = registered_tool_modules.get(tool.name)
            if module_qualname is not None and tool.name not in client_tool_names:
                tool_module_qualnames.setdefault(tool.name, module_qualname)

        # Register subagent definitions forwarded from the client
        if request.agent_definitions:
            _register_agent_definitions(
                request.agent_definitions,
                context=f"conversation {conversation_id}",
            )

        # Plugin loading is handled lazily by LocalConversation, which fetches
        # plugins on the first run()/send_message(), pins refs to commit SHAs
        # and merges plugin skills/MCP/hooks into the agent.
        #
        # Use mode='json' so SecretStr in nested structures (e.g. LookupSecret.headers)
        # serialize to plain strings. Pass expose_secrets=True so StaticSecret values
        # are preserved through the round-trip; the dict is only used in-process to
        # construct StoredConversation, not sent over the network.
        request_data = request.model_copy(
            update={
                "secrets": secrets,
                "workspace": workspace,
                "tool_module_qualnames": tool_module_qualnames,
            }
        ).model_dump(
            mode="json",
            context={"expose_secrets": True},
            exclude={
                "agent",
                "agent_settings",
                "agent_profile_id",
                "agent_launch_additions",
            },
        )
        launched_agent_profile = launched.profile or runtime_launched_profile
        if request.secrets_encrypted:
            stored = StoredConversation.model_validate(
                {
                    "id": conversation_id,
                    **request_data,
                    "launched_agent_profile": (
                        launched_agent_profile.model_dump(mode="json")
                        if launched_agent_profile is not None
                        else None
                    ),
                },
                context={"cipher": self.cipher},
            )
        else:
            stored = StoredConversation(
                id=conversation_id,
                launched_agent_profile=launched_agent_profile,
                **request_data,
            )
        async with self._conversation_lifecycle(conversation_id):
            # Re-check under the lock. Preparing ``stored`` above awaits, so a
            # concurrent create for this same id can have committed since the
            # check at the top of this method. Without this the loser would
            # start a second EventService for an id that already exists,
            # re-running its initial message.
            if self._has_conversation(conversation_id):
                return await self._reuse_existing_conversation_locked(
                    conversation_id, request
                )
            # New conversation: the agent is written to base_state.json (its
            # single source of truth), not to meta.json. Pass it explicitly.
            # ``new_agent`` is ``request.agent`` (decrypted when the request was
            # secrets_encrypted).
            event_service = await self._start_event_service(
                stored, is_new_conversation=True, launched=launched
            )
        initial_message = request.initial_message
        if initial_message:
            message = Message(
                role=initial_message.role, content=initial_message.content
            )
            await event_service.send_message(message, False)
            await event_service.run(run_slot=run_slot)

        state = await event_service.get_state()
        conversation_info = _compose_conversation_info(event_service.stored, state)

        # Notify conversation webhooks about the started conversation
        await self._notify_conversation_webhooks(
            _compose_webhook_conversation_info(event_service.stored, state)
        )

        return conversation_info, True

    async def pause_conversation(self, conversation_id: UUID) -> bool:
        event_service = await self._get_or_load_event_service(conversation_id)
        if event_service:
            await event_service.pause()
            # Notify conversation webhooks about the paused conversation
            state = await event_service.get_state()
            conversation_info = _compose_webhook_conversation_info(
                event_service.stored, state
            )
            await self._notify_conversation_webhooks(conversation_info)
        return bool(event_service)

    async def interrupt_conversation(self, conversation_id: UUID) -> bool:
        """Immediately cancel an in-flight LLM call for a conversation.

        Unlike :meth:`pause_conversation`, which waits for the current
        LLM request to finish, this cancels the running ``arun()`` task
        so the interruption takes effect mid-stream.
        """
        event_service = await self._get_or_load_event_service(conversation_id)
        if event_service:
            await event_service.interrupt()
            state = await event_service.get_state()
            conversation_info = _compose_webhook_conversation_info(
                event_service.stored, state
            )
            await self._notify_conversation_webhooks(conversation_info)
        return bool(event_service)

    async def resume_conversation(self, conversation_id: UUID) -> bool:
        return bool(await self._get_or_load_event_service(conversation_id))

    def _worktree_dir(self, stored: StoredConversation) -> Path | None:
        return conversation_worktree_dir(
            self.conversation_worktree_root, stored.workspace.working_dir
        )

    async def delete_conversation(self, conversation_id: UUID) -> bool:
        event_services = self._event_services
        if event_services is None:
            raise ValueError("inactive_service")
        if (
            conversation_id not in event_services
            and conversation_id not in self._conversation_records
        ):
            return False
        async with self._conversation_lifecycle(conversation_id):
            event_service = await self._get_or_load_event_service_locked(
                conversation_id,
                require_runtime_bindings=False,
            )
            if event_service is None:
                return False

            # Notify conversation webhooks about the stopped conversation before closing
            try:
                state = await event_service.get_state()
                conversation_info = _compose_webhook_conversation_info(
                    event_service.stored, state
                )
                conversation_info.execution_status = (
                    ConversationExecutionStatus.DELETING
                )
                await self._notify_conversation_webhooks(conversation_info)
            except Exception as e:
                logger.warning(
                    f"Failed to notify webhooks for conversation {conversation_id}: {e}"
                )

            # Close the event service
            try:
                await event_service.close()
            except CredentialBindingError:
                raise
            except Exception as e:
                logger.warning(
                    f"Failed to close event service for conversation "
                    f"{conversation_id}: {e}"
                )
            event_services.pop(conversation_id, None)
            # Children are orphaned, not cascaded: parent_conversation_id is
            # left dangling, like forked_from_conversation_id on source delete.
            self._conversation_records.pop(conversation_id, None)
            self._credential_bindings.pop(conversation_id, None)

            # Safely remove only the conversation directory (workspace is preserved).
            # This operation may fail due to permission issues, but we don't want that
            # to prevent the conversation from being marked as deleted.
            safe_rmtree(
                event_service.conversation_dir,
                f"conversation directory for {conversation_id}",
            )
            worktree_dir = self._worktree_dir(event_service.stored)
            # Forks share their source's worktree; the last one deleted removes it.
            if worktree_dir is not None and not any(
                self._worktree_dir(record.stored) == worktree_dir
                for record in self._conversation_records.values()
            ):
                await self._run_lifecycle(remove_conversation_worktree, worktree_dir)

            logger.info(f"Successfully deleted conversation {conversation_id}")
            return True

    async def update_conversation(
        self, conversation_id: UUID, request: UpdateConversationRequest
    ) -> bool:
        """Update conversation metadata.

        Args:
            conversation_id: The ID of the conversation to update
            request: Request object containing fields to update (e.g., title, tags)

        Returns:
            bool: True if the conversation was updated successfully, False if not found
        """
        event_service = await self._get_or_load_event_service(conversation_id)
        if event_service is None:
            return False

        state = await event_service.get_state()
        if request.title is not None:
            event_service.stored.title = request.title.strip()
        if request.tags is not None:
            event_service.stored.tags = request.tags
            # Keep the persisted ConversationState update under the state lock so
            # autosave and state-change callbacks observe a consistent mutation.
            state = cast(
                ConversationState,
                await self._run_lifecycle(_update_state_tags_sync, state, request.tags),
            )
        event_service.stored.updated_at = utc_now()
        record = self._conversation_records.get(conversation_id)
        if record is not None:
            record.stored = event_service.stored
            record.cached_info = None
        # Save the updated metadata to disk
        await event_service.save_meta()

        # Notify conversation webhooks about the updated conversation. Compose the
        # full-state snapshot under the state lock, but do the synchronous wait in a
        # worker thread so metadata updates cannot block the FastAPI event loop.
        conversation_info = cast(
            ConversationInfo,
            await self._run_background(
                _compose_webhook_conversation_info_sync, event_service.stored, state
            ),
        )
        await self._notify_conversation_webhooks(conversation_info)

        updated_fields = []
        if request.title is not None:
            updated_fields.append("title")
        if request.tags is not None:
            updated_fields.append("tags")
        logger.info(
            "Successfully updated conversation %s (%s)",
            conversation_id,
            ", ".join(updated_fields),
        )
        return True

    async def get_event_service(self, conversation_id: UUID) -> EventService | None:
        return await self._get_or_load_event_service(conversation_id)

    def _configure_event_service_executors(self, event_service: EventService) -> None:
        event_service._run_executor = self._run_executor
        event_service._interactive_executor = self._interactive_executor
        event_service._read_executor = self._read_executor
        event_service._control_executor = self._control_executor
        event_service._lifecycle_executor = self._lifecycle_executor
        event_service._background_executor = self._background_executor
        event_service._lease_executor = self._lease_executor

    async def get_persisted_event_service(
        self, conversation_id: UUID
    ) -> EventService | None:
        """Open append-only event history without acquiring a runtime lease."""
        if self._event_services is None:
            raise ValueError("inactive_service")
        record = self._conversation_records.get(conversation_id)
        if record is None:
            return None
        event_service = EventService.for_persisted_events(
            record.stored, self.conversations_dir
        )
        self._configure_event_service_executors(event_service)
        return event_service

    async def generate_conversation_title(
        self, conversation_id: UUID, max_length: int = 50, llm: LLM | None = None
    ) -> str | None:
        """Generate a title for the conversation using LLM."""
        event_service = await self._get_or_load_event_service(conversation_id)
        if event_service is None:
            return None

        # Delegate to EventService to avoid accessing private conversation internals
        title = await event_service.generate_title(llm=llm, max_length=max_length)
        return title

    async def ask_agent(self, conversation_id: UUID, question: str) -> str | None:
        """Ask the agent a simple question without affecting conversation state."""
        event_service = await self._get_or_load_event_service(conversation_id)
        if event_service is None:
            return None

        # Delegate to EventService to avoid accessing private conversation internals
        response = await event_service.ask_agent(question)
        return response

    async def condense(self, conversation_id: UUID) -> bool:
        """Force condensation of the conversation history."""
        event_service = await self._get_or_load_event_service(conversation_id)
        if event_service is None:
            return False

        # Delegate to EventService to avoid accessing private conversation internals
        await event_service.condense()
        return True

    async def fork_conversation(
        self,
        source_id: UUID,
        *,
        fork_id: UUID | None = None,
        title: str | None = None,
        tags: dict[str, str] | None = None,
        reset_metrics: bool = True,
        from_event_id: str | None = None,
    ) -> ConversationInfo | None:
        """Fork an existing conversation, deep-copying its event history.

        The fork is persisted to disk and then loaded as a new EventService,
        so the forked conversation is fully independent from the source.

        When *from_event_id* is set, only the branch up to and including that
        event is copied and the fork's HEAD is set there; otherwise the whole
        conversation is copied (today's behavior).

        Returns ``None`` when *source_id* does not exist.

        Raises:
            ValueError: If *fork_id* is already taken by an active
                conversation, or if *from_event_id* is not in the source
                conversation.
        """
        if self._event_services is None:
            raise ValueError("inactive_service")

        # Reject duplicate fork IDs before fork() writes into its persistence
        # directory. The catalog includes both live and unloaded conversations.
        if fork_id is not None and fork_id in self._conversation_records:
            raise ValueError(f"Conversation with id {fork_id} already exists")

        source_service = await self._get_or_load_event_service(source_id)
        if source_service is None:
            return None

        source_conversation = source_service.get_conversation()
        fork_conv_id = fork_id or uuid4()

        fork_dir = self.conversations_dir / fork_conv_id.hex
        async with self._conversation_lifecycle(fork_conv_id):
            # Re-check under the lock, before fork() writes into ``fork_dir``: a
            # concurrent fork of the same id can have committed since the check
            # above, and both fork() and the cleanup below would then touch the
            # winner's persisted data.
            if self._has_conversation(fork_conv_id):
                raise ValueError(f"Conversation with id {fork_id} already exists")

            # fork() deep-copies events and state into ``fork_dir``.
            fork_conv = await self._run_lifecycle(
                source_conversation.fork,
                conversation_id=fork_conv_id,
                tags=tags,
                reset_metrics=reset_metrics,
                from_event_id=from_event_id,
            )
            # Extract the persisted data, then discard the temporary conversation.
            fork_agent = cast(AgentBase, fork_conv.agent)
            fork_workspace = fork_conv.workspace
            fork_conv.delete_on_close = False
            fork_conv.close()

            # _start_event_service will resume from the persisted fork directory.
            # Copy the source's stored metadata so request-level configuration
            # (client_tools, tool_module_qualnames, agent_definitions, plugins,
            # secrets, ...) is preserved on the fork, then override only the
            # fork-specific fields. Without this, e.g. a fork of a client-tool
            # conversation would lose ``client_tools`` in meta.json and be unable
            # to re-register its tools after a server restart.
            # Note: the agent is NOT stored in meta.json (StoredConversation) — the
            # fork's agent is already persisted to the fork's base_state.json by
            # ``source_conversation.fork`` above. It is passed to
            # ``_start_event_service`` via ``agent=`` for the new-conversation
            # path.
            fork_overrides: dict[str, Any] = {
                "id": fork_conv_id,
                "workspace": fork_workspace,
                "title": title,
                "tags": tags or {},
                "created_at": utc_now(),
                "updated_at": utc_now(),
                "forked_from_conversation_id": source_id,
                "forked_from_event_id": from_event_id,
            }
            if reset_metrics:
                fork_overrides["metrics"] = None
            fork_stored = source_service.stored.model_copy(update=fork_overrides)
            try:
                # If the service fails to start, clean up the orphaned
                # persistence directory so we don't leave stale state on disk.
                fork_event_service = await self._start_event_service(
                    fork_stored, is_new_conversation=True, persisted_agent=fork_agent
                )
            except Exception:
                safe_rmtree(fork_dir)
                raise

        state = await fork_event_service.get_state()
        return _compose_conversation_info(
            fork_event_service.stored, state, self._children_of(fork_conv_id)
        )

    async def navigate_conversation(
        self, conversation_id: UUID, *, event_id: str | None = None
    ) -> ConversationInfo | None:
        """Move a conversation's HEAD to an existing event (in-place re-root).

        All branches stay on disk; only the active branch the agent runs on
        changes. The new HEAD persists via the conversation's own state
        autosave. Returns ``None`` when *conversation_id* does not exist.

        Raises:
            ValueError: If *event_id* is not ``None`` and not present in the
                conversation.
        """
        event_service = await self._get_or_load_event_service(conversation_id)
        if event_service is None:
            return None

        await event_service.navigate_to(event_id)
        state = await event_service.get_state()
        return _compose_conversation_info(
            event_service.stored, state, self._children_of(conversation_id)
        )

    async def __aenter__(self):
        self.conversations_dir.mkdir(parents=True, exist_ok=True)
        self._run_executor = ThreadPoolExecutor(
            max_workers=self.max_concurrent_runs,
            thread_name_prefix="conversation-run",
        )
        self._interactive_executor = ThreadPoolExecutor(
            max_workers=self.max_concurrent_runs,
            thread_name_prefix="conversation-interactive",
        )
        self._read_executor = ThreadPoolExecutor(
            max_workers=self.max_concurrent_reads,
            thread_name_prefix="conversation-read",
        )
        self._control_executor = ThreadPoolExecutor(
            max_workers=2,
            thread_name_prefix="conversation-control",
        )
        self._lifecycle_executor = ThreadPoolExecutor(
            max_workers=2,
            thread_name_prefix="conversation-lifecycle",
        )
        self._background_executor = ThreadPoolExecutor(
            max_workers=min(2, max(1, self.max_concurrent_runs // 2)),
            thread_name_prefix="conversation-background",
        )
        self._lease_executor = ThreadPoolExecutor(
            max_workers=1,
            thread_name_prefix="conversation-lease",
        )
        self._run_semaphore = asyncio.Semaphore(self.max_concurrent_runs)
        self._event_services = {}
        self._conversation_records = cast(
            dict[UUID, _ConversationRecord],
            await self._run_background(self._load_catalog_sync),
        )

        # Initialize conversation webhook subscribers
        self._conversation_webhook_subscribers = [
            ConversationWebhookSubscriber(
                spec=webhook_spec,
                session_api_key=self.session_api_key,
            )
            for webhook_spec in self.webhook_specs
        ]

        # Preserve crash recovery semantics without hydrating every idle
        # conversation. RUNNING records may contain an interrupted tool call;
        # EventService.start() marks those records as ERROR and appends the
        # corresponding recovery event. A live lease still prevents takeover.
        running_ids = [
            conversation_id
            for conversation_id, record in self._conversation_records.items()
            if record.execution_status == ConversationExecutionStatus.RUNNING
        ]
        for conversation_id in running_ids:
            try:
                await self._get_or_load_event_service(conversation_id)
            except Exception:
                # One broken conversation must not prevent the server from
                # starting or make every healthy conversation unavailable.
                logger.exception(
                    "error_recovering_running_conversation:%s",
                    conversation_id,
                    stack_info=True,
                )

        self._lease_renewal_task = asyncio.create_task(self._renew_all_leases_loop())
        if self.conversation_idle_ttl_seconds:
            self._eviction_task = asyncio.create_task(
                self._evict_idle_conversations_loop()
            )

        return self

    async def _renew_all_leases_loop(self) -> None:
        """Single background task that renews leases for all active conversations.

        Replaces N per-conversation renewal tasks with one centralized loop,
        reducing asyncio task overhead.  Each renewal involves synchronous
        file I/O (FileLock + read + write), so individual calls are offloaded
        via ``asyncio.to_thread`` to avoid blocking the event loop.
        """
        try:
            while True:
                await asyncio.sleep(LEASE_RENEW_INTERVAL_SECONDS)
                event_services = self._event_services
                if event_services is None:
                    return
                for event_service in list(event_services.values()):
                    await self._run_lease(event_service.renew_lease)
        except asyncio.CancelledError:
            raise

    async def _evict_idle_conversations_loop(self) -> None:
        """Periodically evict conversations idle beyond the TTL."""
        ttl = self.conversation_idle_ttl_seconds
        if not ttl or ttl <= 0:
            return
        interval = max(60.0, ttl / 2)
        try:
            while True:
                await asyncio.sleep(interval)
                try:
                    await self._evict_idle_conversations(ttl)
                except Exception:
                    logger.exception(
                        "error_evicting_idle_conversations", stack_info=True
                    )
        except asyncio.CancelledError:
            raise

    async def _evict_idle_conversations(self, ttl_seconds: float) -> None:
        """Evict idle conversations without holding the global lifecycle gate.

        The exclusive gate is only needed to atomically detach eligible services
        from the live registry. Closing a conversation can block on a Runtime,
        tool process, or lease file, so it happens after the gate is released
        while the detached conversation's own lock prevents a concurrent reload.
        """

        retiring: list[
            tuple[
                UUID, EventService, dict[str, VersionedCredentialBinding], asyncio.Lock
            ]
        ] = []
        async with self._exclusive_lifecycle():
            event_services = self._event_services
            if event_services is None:
                return
            to_evict = [
                conversation_id
                for conversation_id, event_service in event_services.items()
                if event_service.is_open()
                and event_service.idle_seconds() >= ttl_seconds
                and event_service.is_idle_evictable()
            ]
            for conversation_id in to_evict:
                event_service = event_services.pop(conversation_id, None)
                if event_service is None:
                    continue
                # The exclusive gate waited for all lifecycle operations, so the
                # lock is immediately available. Keep it through close() so the
                # same conversation cannot be rehydrated while its old lease or
                # Runtime is still draining.
                conversation_lock = self._get_conversation_lock(conversation_id)
                await conversation_lock.acquire()
                record = self._conversation_records.get(conversation_id)
                if record is not None:
                    record.stored = event_service.stored
                    record.cached_info = None
                retiring.append(
                    (
                        conversation_id,
                        event_service,
                        dict(event_service.credential_bindings),
                        conversation_lock,
                    )
                )

        for conversation_id, event_service, bindings, conversation_lock in retiring:
            try:
                try:
                    await event_service.__aexit__(None, None, None)
                except Exception:
                    logger.warning(
                        "Failed to evict idle conversation %s",
                        conversation_id,
                        exc_info=True,
                    )
                else:
                    logger.info(
                        "Evicted idle conversation %s (idle >= %.0fs)",
                        conversation_id,
                        ttl_seconds,
                    )
                if bindings:
                    pending = self._credential_bindings.setdefault(conversation_id, {})
                    for secret_name, binding in bindings.items():
                        pending.setdefault(secret_name, binding)
            finally:
                conversation_lock.release()

    async def __aexit__(self, exc_type, exc_value, traceback):
        if self._eviction_task is not None:
            self._eviction_task.cancel()
            with suppress(asyncio.CancelledError):
                await self._eviction_task
            self._eviction_task = None

        if self._lease_renewal_task is not None:
            self._lease_renewal_task.cancel()
            with suppress(asyncio.CancelledError):
                await self._lease_renewal_task
            self._lease_renewal_task = None

        async with self._exclusive_lifecycle():
            event_services = self._event_services
            if event_services is None:
                return
            services = tuple(event_services.items())
            results = await asyncio.gather(
                *[
                    event_service.__aexit__(exc_type, exc_value, traceback)
                    for _, event_service in services
                ],
                return_exceptions=True,
            )
            failed_ids = {
                conversation_id
                for (conversation_id, _), result in zip(services, results, strict=True)
                if isinstance(result, BaseException)
            }
            failures = [
                result for result in results if isinstance(result, BaseException)
            ]
            if failed_ids:
                self._event_services = {
                    conversation_id: event_service
                    for conversation_id, event_service in services
                    if conversation_id in failed_ids
                }
                self._conversation_records = {
                    conversation_id: record
                    for conversation_id, record in self._conversation_records.items()
                    if conversation_id in failed_ids
                }
                self._credential_bindings = {
                    conversation_id: bindings
                    for conversation_id, bindings in self._credential_bindings.items()
                    if conversation_id in failed_ids
                }
            else:
                self._event_services = None
                self._conversation_records = {}
                self._credential_bindings = {}
        for executor_name in (
            "_run_executor",
            "_interactive_executor",
            "_read_executor",
            "_control_executor",
            "_lifecycle_executor",
            "_background_executor",
            "_lease_executor",
        ):
            executor = getattr(self, executor_name)
            if executor is not None:
                executor.shutdown(wait=False)
                setattr(self, executor_name, None)
        if failures:
            assert self._event_services is not None
            for event_service in self._event_services.values():
                await self._run_lease(event_service.renew_lease)
            self._lease_renewal_task = asyncio.create_task(
                self._renew_all_leases_loop()
            )
            credential_failure = next(
                (
                    failure
                    for failure in failures
                    if isinstance(failure, CredentialBindingError)
                ),
                None,
            )
            raise credential_failure or failures[0]

    @classmethod
    def get_instance(cls, config: Config) -> "ConversationService":
        # Initialise the settings-store singleton with the server cipher before
        # any conversation handler can call get_settings_store() without config.
        from openhands.agent_server.mcp_oauth_store import (
            create_settings_backed_mcp_tool_provider,
        )
        from openhands.agent_server.persistence import (
            get_secrets_store,
            get_settings_store,
        )

        get_settings_store(config)
        return ConversationService(
            conversations_dir=config.conversations_path,
            webhook_specs=config.webhooks,
            session_api_key=(
                config.session_api_keys[0] if config.session_api_keys else None
            ),
            cipher=config.cipher,
            mcp_tool_provider=create_settings_backed_mcp_tool_provider(config),
            secrets_store=get_secrets_store(config),
            max_concurrent_runs=config.max_concurrent_runs,
            max_concurrent_reads=config.max_concurrent_reads,
            lease_ttl_seconds=config.lease_ttl_seconds,
            conversation_idle_ttl_seconds=config.conversation_idle_ttl_seconds,
            conversation_worktree_root=config.conversation_worktree_root,
            acp_skill_sourcing=config.acp_skill_sourcing,
            enable_browser=config.enable_browser,
        )

    async def _start_event_service(
        self,
        stored: StoredConversation,
        *,
        is_new_conversation: bool = False,
        launched: LaunchedAgent | None = None,
        persisted_agent: AgentBase | None = None,
    ) -> EventService:
        event_services = self._event_services
        if event_services is None:
            raise ValueError("inactive_service")

        # A new conversation starts with the ``launched`` agent (meta.json does
        # not carry it). Otherwise the agent is read from base_state.json, and
        # ``persisted_agent`` only spares the credential check that read.
        agent = launched.agent if launched is not None else persisted_agent
        credential_bindings = await self._resolve_credential_bindings(
            stored, agent=agent
        )
        event_service = EventService(
            stored=stored,
            conversations_dir=self.conversations_dir,
            agent=launched.agent if launched is not None else None,
            cipher=self._cipher_for(stored.id),
            mcp_tool_provider=self.mcp_tool_provider,
            credential_bindings=credential_bindings,
            owner_instance_id=self.owner_instance_id,
            lease_ttl_seconds=self.lease_ttl_seconds,
        )
        # Lease renewal is handled by the centralized
        # _renew_all_leases_loop task on ConversationService.
        event_service._external_lease_renewal = True
        self._configure_event_service_executors(event_service)
        event_service._run_semaphore = self._run_semaphore

        try:
            await event_service.start()
            # Register subscribers after start() so subscribe_to_events runs
            # its initial-state push synchronously and any failure surfaces to
            # the caller instead of being silently logged on a later publish.
            await event_service.subscribe_to_events(
                _EventSubscriber(
                    service=event_service,
                    catalog_records=self._conversation_records,
                )
            )
            if stored.autotitle and stored.title is None:
                await event_service.subscribe_to_events(
                    AutoTitleSubscriber(service=event_service)
                )
            await self._maybe_subscribe_telemetry(
                event_service, stored, is_new_conversation=is_new_conversation
            )
            await asyncio.gather(
                *[
                    event_service.subscribe_to_events(
                        WebhookSubscriber(
                            conversation_id=stored.id,
                            service=event_service,
                            spec=webhook_spec,
                            session_api_key=self.session_api_key,
                        )
                    )
                    for webhook_spec in self.webhook_specs
                ]
            )
            # Mark these as internal so idle eviction only counts external clients.
            event_service.mark_subscription_baseline()
            # Save metadata immediately after successful start to ensure persistence
            # even if the system is not shut down gracefully
            await event_service.save_meta()
            if self._event_services is not event_services:
                raise ValueError("inactive_service")
        except Exception:
            try:
                await event_service.close()
            except Exception as close_error:
                logger.warning(
                    "Failed to close conversation %s after startup failure: %s",
                    stored.id,
                    close_error,
                )
            finally:
                pending = self._credential_bindings.setdefault(stored.id, {})
                for secret_name, binding in credential_bindings.items():
                    pending.setdefault(secret_name, binding)
            raise

        event_services[stored.id] = event_service
        state = await event_service.get_state()
        self._conversation_records[stored.id] = _ConversationRecord(
            stored=event_service.stored,
            execution_status=state.execution_status,
        )
        return event_service

    async def _maybe_subscribe_telemetry(
        self,
        event_service: EventService,
        stored: StoredConversation,
        *,
        is_new_conversation: bool,
    ) -> None:
        """Attach the telemetry subscriber, if telemetry is active.

        The subscriber is attached on *every* path, including rehydration, so
        errors and terminal outcomes are always captured. But
        ``conversation_created`` is emitted only for a genuinely new
        conversation: ``_start_event_service`` also runs when an idle
        conversation is lazily reloaded and when RUNNING conversations are
        recovered after a restart, and counting those as creations would inflate
        the metric on every server bounce.

        Deliberately total: telemetry must never be able to fail conversation
        startup. The ``enabled`` check comes first so the disabled path does no
        sanitization work at all.
        """
        # Resolve the process sink lazily rather than trusting a value captured
        # at construction. ``ConversationService`` is instantiated at import
        # time (``sockets.py`` module scope), before the lifespan builds the
        # sink, so a cached reference is always the pre-init NoOp — which would
        # silence conversation telemetry regardless of consent. Reading the
        # current sink here makes conversations honour the live decision, the
        # same way the server-lifecycle and request-failed paths already do.
        sink = get_telemetry_sink()
        if not sink.enabled:
            return
        try:
            factory = get_event_factory()
            if factory is None:
                return

            live_conversation = event_service._conversation
            live_agent = (
                live_conversation.agent if live_conversation is not None else None
            )
            subscriber = TelemetrySubscriber(
                conversation_id=stored.id,
                sink=sink,
                factory=factory,
                context=_build_telemetry_context(stored, factory, agent=live_agent),
            )
            await event_service.subscribe_to_events(subscriber)
            if is_new_conversation:
                subscriber.emit_started()
        except Exception:
            logger.debug("Could not attach telemetry subscriber", exc_info=True)


def _build_telemetry_context(
    stored: StoredConversation,
    factory: DiagnosticEventFactory,
    agent: AgentBase | None = None,
) -> ConversationTelemetryContext:
    """Reduce a stored conversation to its sanitized telemetry facts.

    Every read is defensive: a shape change upstream should degrade a property
    to ``unknown``, never raise into conversation startup.

    The agent is no longer stored on meta.json; callers pass the live/persisted
    agent explicitly. When ``agent`` is ``None`` (no live conversation), the
    agent-derived fields simply degrade to ``unknown``.
    """
    tags = getattr(stored, "tags", None)
    is_automation = isinstance(tags, dict) and any(
        bool(tags.get(key)) for key in _AUTOMATION_TAG_KEYS
    )

    llm = getattr(agent, "llm", None)

    workspace = getattr(stored, "workspace", None)
    workspace_kind = safe_token(
        type(workspace).__name__.lower() if workspace is not None else None
    )

    tools = getattr(agent, "tools", None)
    tool_count = len(tools) if isinstance(tools, (list, tuple)) else 0

    return ConversationTelemetryContext(
        conversation_ref=factory.conversation_ref(stored.id),
        user_id=getattr(stored, "user_id", None),
        llm_model_family=model_family(getattr(llm, "model", None)),
        agent_kind=safe_token(type(agent).__name__.lower() if agent else None),
        tool_count=tool_count,
        is_fork=getattr(stored, "forked_from_conversation_id", None) is not None,
        has_agent_profile=getattr(stored, "launched_agent_profile", None) is not None,
        workspace_kind=workspace_kind,
        # Policy kind, not a bool: a bool would collapse ConfirmRisky.
        confirmation_policy=safe_token(
            type(getattr(stored, "confirmation_policy", None)).__name__.lower()
        ),
        is_automation=is_automation,
    )


@dataclass
class _EventSubscriber(Subscriber):
    service: EventService
    catalog_records: dict[UUID, _ConversationRecord]

    async def __call__(self, event: Event):
        # Any event is activity; refresh the idle-eviction clock.
        self.service.touch()
        record = self.catalog_records.get(self.service.stored.id)
        if isinstance(event, ConversationStateUpdateEvent):
            # Maintain the catalog's native status from the formal state event.
            # This makes activity polling lock-free for live conversations.
            raw_status = (
                event.value.get("execution_status")
                if event.key == "full_state" and isinstance(event.value, dict)
                else event.value
                if event.key == "execution_status"
                else None
            )
            if record is not None and isinstance(raw_status, str):
                with suppress(ValueError):
                    record.execution_status = ConversationExecutionStatus(raw_status)
            # State synchronization does not represent agent activity and must
            # not reset the event-derived activity timestamp after a restart.
            return
        self.service.stored.updated_at = utc_now()
        if record is not None:
            record.stored = self.service.stored
        update_last_execution_time()


@observe(
    name="conversation.generate_title",
    ignore_inputs=["conversation", "llm", "on_error"],
    metadata={OPERATION_METADATA_KEY: "title_generation"},
)
def _generate_title_traced(
    # Must stay first and positional: ``observe`` re-attaches the
    # root span it carries, and this runs on a context-less executor thread.
    conversation: LocalConversation | None,
    message: str,
    llm: LLM | None,
    max_length: int,
    on_error: Callable[[Exception], None] | None = None,
) -> str:
    call_context = (
        conversation.get_llm_call_context() if conversation else LLMCallContext()
    )
    return generate_title_from_message(
        message, llm, max_length, call_context=call_context, on_error=on_error
    )


@dataclass
class AutoTitleSubscriber(Subscriber):
    service: EventService

    async def __call__(self, event: Event) -> None:
        # Only act on incoming user messages
        if not isinstance(event, MessageEvent) or event.source != "user":
            return
        # Guard: skip if a title was already set (e.g. by a concurrent task)
        if self.service.stored.title is not None:
            return

        # Extract the message text now, before spawning the background task,
        # to avoid a race where the event hasn't been persisted to the events
        # list yet when title generation tries to read it.
        message_text = extract_message_text(event)
        if not message_text:
            return

        # Precedence: title_llm_profile (if configured and loads) → agent.llm →
        # truncation. This keeps auto-titling non-breaking for consumers who
        # don't configure title_llm_profile.
        conversation = self.service._conversation
        title_llm = self._load_title_llm()
        if title_llm is None:
            title_llm = conversation.agent.llm if conversation else None

        # Surface an LLM failure during auto-titling to the UI (issue #16686);
        # generation itself stays non-fatal and falls back to truncation.
        def _on_title_error(exc: Exception) -> None:
            self.service._publish_error_event_sync(exc)

        async def _generate_and_save() -> None:
            try:
                title = cast(
                    str,
                    await self.service._run_background(
                        _generate_title_traced,
                        conversation,
                        message_text,
                        title_llm,
                        50,
                        _on_title_error,
                    ),
                )
                if title and self.service.stored.title is None:
                    self.service.stored.title = title
                    self.service.stored.updated_at = utc_now()
                    await self.service.save_meta()
            except Exception:
                logger.warning(
                    f"Auto-title generation failed for "
                    f"conversation {self.service.stored.id}",
                    exc_info=True,
                )

        asyncio.create_task(_generate_and_save())

    def _load_title_llm(self) -> LLM | None:
        """Load the LLM for title generation from profile store.

        Returns:
            LLM instance if title_llm_profile is configured and loads
            successfully, None otherwise. When None is returned, the caller
            falls back to the agent's LLM (and then to message truncation).
        """
        profile_name = self.service.stored.title_llm_profile
        if not profile_name:
            return None

        try:
            from openhands.agent_server.persistence.store import (
                get_llm_profile_store,
            )

            profile_store = get_llm_profile_store()
            return profile_store.load(profile_name, cipher=self.service.cipher)
        except (FileNotFoundError, ValueError) as e:
            logger.warning(
                f"Failed to load title LLM profile '{profile_name}': {e}. "
                "Falling back to the agent's LLM."
            )
            return None


@dataclass
class WebhookSubscriber(Subscriber):
    conversation_id: UUID
    service: EventService
    spec: WebhookSpec
    session_api_key: str | None = None
    queue: list[Event] = field(default_factory=list)
    _flush_timer: asyncio.Task | None = field(default=None, init=False)
    _post_lock: asyncio.Lock = field(default_factory=asyncio.Lock, init=False)
    _queue_sizes: list[int] = field(default_factory=list, init=False)
    _queue_bytes: int = field(default=0, init=False)
    _dropped_events: int = field(default=0, init=False)
    _closed: bool = field(default=False, init=False)
    # Per-instance sleep seam so tests override delays without patching the
    # global asyncio.sleep. default_factory (not default) keeps it an instance
    # attribute, else the function would be descriptor-bound as a method.
    _sleep: Callable[[float], Awaitable[None]] = field(
        default_factory=lambda: asyncio.sleep, init=False
    )

    async def __call__(self, event: Event):
        """Add event to queue and post to webhook when buffer size is reached."""
        self._enqueue(event)

        if (
            len(self.queue) >= self.spec.event_buffer_size
            or self._queue_bytes >= self.spec.max_batch_bytes
        ):
            if self._post_lock.locked():
                self._start_flush_timer()
                return
            # Cancel timer since we're flushing due to buffer size
            self._cancel_flush_timer()
            await self._post_events()
        elif self.queue:
            self._start_flush_timer()

    async def close(self):
        """Post any remaining items in the queue to the webhook."""
        self._closed = True
        # Cancel any pending flush timer
        self._cancel_flush_timer()

        if self.queue:
            await self._post_events()

    async def _post_events(self):
        """Post bounded batches serially until the queue is empty or a post fails."""
        async with self._post_lock:
            self._sync_queue_sizes()
            self._trim_queue()
            events_remaining = len(self.queue)
            while events_remaining:
                events_to_post, event_data = self._take_batch(events_remaining)
                if not await self._post_batch(event_data):
                    self._requeue(events_to_post)
                    return
                events_remaining -= len(events_to_post)

    async def _post_batch(self, event_data: list[dict[str, Any]]) -> bool:
        """Post one serialized batch with retry logic."""

        # Prepare headers
        headers = self.spec.headers.copy()
        if self.session_api_key:
            headers["X-Session-API-Key"] = self.session_api_key

        # Construct events URL
        events_url = (
            f"{self.spec.base_url.rstrip('/')}/events/{self.conversation_id.hex}"
        )

        # Retry logic
        for attempt in range(self.spec.num_retries + 1):
            try:
                async with httpx.AsyncClient() as client:
                    response = await client.request(
                        method="POST",
                        url=events_url,
                        json=event_data,
                        headers=headers,
                        timeout=30.0,
                    )
                    response.raise_for_status()
                    logger.debug(
                        f"Successfully posted {len(event_data)} events "
                        f"to webhook {events_url}"
                    )
                    return True
            except Exception as e:
                logger.warning(f"Webhook post attempt {attempt + 1} failed: {e}")
                if attempt < self.spec.num_retries:
                    await self._sleep(self.spec.retry_delay)
                else:
                    logger.error(
                        f"Failed to post events to webhook {events_url} "
                        f"after {self.spec.num_retries + 1} attempts"
                    )
        return False

    @staticmethod
    def _event_data(event: Event) -> dict[str, Any]:
        # mode="json" makes types such as set and SecretStr JSON-safe.
        if hasattr(event, "model_dump"):
            return event.model_dump(mode="json")
        return event.__dict__

    @classmethod
    def _event_size(cls, event: Event) -> int:
        return len(
            json.dumps(
                cls._event_data(event),
                ensure_ascii=False,
                separators=(",", ":"),
                allow_nan=False,
            ).encode()
        )

    def _sync_queue_sizes(self):
        """Refresh size accounting after callers directly replace the public queue."""
        if len(self._queue_sizes) != len(self.queue):
            self._queue_sizes = [self._event_size(event) for event in self.queue]
            self._queue_bytes = sum(self._queue_sizes)

    def _enqueue(self, event: Event):
        self._sync_queue_sizes()
        event_size = self._event_size(event)
        self.queue.append(event)
        self._queue_sizes.append(event_size)
        self._queue_bytes += event_size
        self._trim_queue()

    def _requeue(self, events: list[Event]):
        sizes = [self._event_size(event) for event in events]
        self.queue[:0] = events
        self._queue_sizes[:0] = sizes
        self._queue_bytes += sum(sizes)
        self._trim_queue()

    def _trim_queue(self):
        dropped = 0
        while self.queue and (
            len(self.queue) > self.spec.max_queue_size
            or self._queue_bytes > self.spec.max_queue_bytes
        ):
            del self.queue[0]
            self._queue_bytes -= self._queue_sizes.pop(0)
            dropped += 1
        if dropped:
            previous_dropped = self._dropped_events
            self._dropped_events += dropped
            if (
                previous_dropped == 0
                or self._dropped_events // 100 > previous_dropped // 100
            ):
                logger.warning(
                    "Webhook queue exceeded its configured count or byte limit; "
                    f"dropped {self._dropped_events} event(s) so far for conversation "
                    f"{self.conversation_id.hex}."
                )

    def _take_batch(self, max_events: int) -> tuple[list[Event], list[dict[str, Any]]]:
        self._sync_queue_sizes()
        batch_size = 2  # JSON array brackets
        batch_count = 0
        event_data: list[dict[str, Any]] = []

        for event, event_size in zip(self.queue, self._queue_sizes, strict=True):
            next_size = batch_size + event_size + (1 if batch_count else 0)
            if batch_count and next_size > self.spec.max_batch_bytes:
                break
            event_data.append(self._event_data(event))
            batch_size = next_size
            batch_count += 1
            if batch_count >= min(self.spec.event_buffer_size, max_events):
                break

        events = self.queue[:batch_count]
        del self.queue[:batch_count]
        removed_sizes = self._queue_sizes[:batch_count]
        del self._queue_sizes[:batch_count]
        self._queue_bytes -= sum(removed_sizes)
        return events, event_data

    def _start_flush_timer(self):
        if not self._closed and not self._flush_timer:
            self._flush_timer = asyncio.create_task(self._flush_after_delay())

    def _cancel_flush_timer(self):
        """Cancel the current flush timer if it exists."""
        if self._flush_timer and not self._flush_timer.done():
            self._flush_timer.cancel()
        self._flush_timer = None

    async def _flush_after_delay(self):
        """Wait for flush_delay seconds then flush events if any exist."""
        current_task = asyncio.current_task()
        should_reschedule = False
        try:
            await self._sleep(self.spec.flush_delay)
            # Only flush if there are events in the queue
            if self.queue:
                await self._post_events()
                should_reschedule = bool(self.queue)
        except asyncio.CancelledError:
            # Timer was cancelled, which is expected behavior
            pass
        finally:
            if self._flush_timer is current_task:
                self._flush_timer = None
            if should_reschedule:
                self._start_flush_timer()


@dataclass
class ConversationWebhookSubscriber:
    """Webhook subscriber for conversation lifecycle events (start, pause, stop)."""

    spec: WebhookSpec
    session_api_key: str | None = None
    # Per-instance sleep seam; see WebhookSubscriber._sleep.
    _sleep: Callable[[float], Awaitable[None]] = field(
        default_factory=lambda: asyncio.sleep, init=False
    )

    async def post_conversation_info(self, conversation_info: BaseModel):
        """Post conversation info to the webhook immediately (no batching)."""
        # Prepare headers
        headers = self.spec.headers.copy()
        if self.session_api_key:
            headers["X-Session-API-Key"] = self.session_api_key

        # Construct conversations URL
        conversations_url = f"{self.spec.base_url.rstrip('/')}/conversations"

        # Convert conversation info to serializable format
        conversation_data = conversation_info.model_dump(mode="json")

        # Retry logic
        response = None
        for attempt in range(self.spec.num_retries + 1):
            try:
                async with httpx.AsyncClient() as client:
                    response = await client.request(
                        method="POST",
                        url=conversations_url,
                        json=conversation_data,
                        headers=headers,
                        timeout=30.0,
                    )
                    response.raise_for_status()
                    logger.debug(
                        f"Successfully posted conversation info "
                        f"to webhook {conversations_url}"
                    )
                    return
            except Exception as e:
                logger.warning(
                    f"Conversation webhook post attempt {attempt + 1} failed: {e}"
                )
                if attempt < self.spec.num_retries:
                    await self._sleep(self.spec.retry_delay)
                else:
                    # Log response content for debugging failures
                    response_content = (
                        response.text if response is not None else "No response"
                    )
                    logger.error(
                        f"Failed to post conversation info to webhook "
                        f"{conversations_url} after {self.spec.num_retries + 1} "
                        f"attempts. Response: {response_content}"
                    )


_conversation_service: ConversationService | None = None


def get_default_conversation_service() -> ConversationService:
    global _conversation_service
    if _conversation_service:
        return _conversation_service

    from openhands.agent_server.config import (
        get_default_config,
    )

    config = get_default_config()
    _conversation_service = ConversationService.get_instance(config)
    return _conversation_service
