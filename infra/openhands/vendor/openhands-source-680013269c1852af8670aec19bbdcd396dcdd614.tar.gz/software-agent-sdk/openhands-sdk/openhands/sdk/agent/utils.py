from __future__ import annotations

import contextlib
import json
import logging
import os
import re
import shlex
import shutil
import subprocess
import textwrap
import types
from collections.abc import Collection
from typing import (
    Annotated,
    Any,
    Union,
    get_args,
    get_origin,
    overload,
)

from pydantic import BaseModel

from openhands.sdk.context.condenser.base import CondenserBase
from openhands.sdk.context.view import View
from openhands.sdk.event.base import LLMConvertibleEvent
from openhands.sdk.event.condenser import Condensation
from openhands.sdk.llm import LLM, Message


# Regex matching raw ASCII control characters (U+0000–U+001F) that are
# illegal inside JSON strings per RFC 8259 §7.
_CONTROL_CHAR_RE = re.compile(r"[\x00-\x1f]")

# Mapping from raw control-char ordinals to their JSON-legal two-character
# escape sequences.  Characters without a short alias fall back to \uXXXX.
_CTRL_ESCAPE_TABLE: dict[int, str] = {
    0x08: "\\b",
    0x09: "\\t",
    0x0A: "\\n",
    0x0C: "\\f",
    0x0D: "\\r",
}


logger = logging.getLogger(__name__)


def _escape_control_char(m: re.Match[str]) -> str:
    """Replace a single raw control character with its JSON escape."""
    ch = m.group(0)
    return _CTRL_ESCAPE_TABLE.get(ord(ch), f"\\u{ord(ch):04x}")


def sanitize_json_control_chars(raw: str) -> str:
    """Escape raw control characters in a JSON string produced by an LLM.

    Some models (e.g. kimi-k2.5, minimax-m2.5) emit literal control
    characters (newline, tab, …) inside ``tool_call.arguments`` instead of
    their proper two-character JSON escape sequences (``\\n``, ``\\t``, …).
    ``json.loads`` rejects these per RFC 8259.

    This function replaces every raw U+0000–U+001F byte with the correct
    escape sequence so the string becomes valid JSON.
    """
    return _CONTROL_CHAR_RE.sub(_escape_control_char, raw)


def _is_chunked_str_field(value: Any, expected_origins: list[Any]) -> bool:
    """Return True if a str-only field was given a list of string chunks.

    Some models (e.g. minimax-m2.5) split a single string argument such as
    file_editor's old_str/new_str into a JSON array of chunks. Such a list is
    rejoined into one string by the caller. ``str | list[str]`` fields are
    excluded so a genuinely-valid list is never collapsed, and lists holding
    non-strings are rejected so they fail validation instead of being silently
    mangled.
    """
    return (
        isinstance(value, list)
        and str in expected_origins
        and not any(exp in (list, dict) for exp in expected_origins)
        and all(isinstance(part, str) for part in value)
    )


def _json_schema_expected_types(
    schema: dict[str, Any], defs: dict[str, Any]
) -> list[Any]:
    ref = schema.get("$ref")
    if isinstance(ref, str) and ref.startswith("#/$defs/"):
        target = defs.get(ref.rsplit("/", 1)[-1])
        if isinstance(target, dict):
            return _json_schema_expected_types(target, defs)

    expected: list[Any] = []
    for key in ("anyOf", "oneOf"):
        for option in schema.get(key, []):
            if isinstance(option, dict):
                expected.extend(_json_schema_expected_types(option, defs))

    json_types = schema.get("type")
    if isinstance(json_types, str):
        json_types = [json_types]
    if isinstance(json_types, list):
        type_map = {
            "array": list,
            "boolean": bool,
            "integer": int,
            "number": float,
            "object": dict,
            "string": str,
        }
        expected.extend(
            type_map[json_type] for json_type in json_types if json_type in type_map
        )
    return expected


def fix_malformed_tool_arguments(
    arguments: dict[str, Any], action_type: type[BaseModel] | dict[str, Any]
) -> dict[str, Any]:
    """Fix malformed tool arguments emitted by some LLMs under native fn calling.

    Two malformations are repaired:

    1. list/dict parameters encoded as JSON strings (e.g. GLM 4.6), which are
       decoded back into native arrays/objects (see example below).
    2. str-only parameters emitted as a JSON array of string chunks (e.g.
       minimax-m2.5 chunking file_editor's old_str/new_str), which are joined
       back into a single string.

    Example raw LLM output from GLM 4.6:
    {
        "role": "assistant",
        "content": "I'll view the file for you.",
        "tool_calls": [{
            "id": "call_ef8e",
            "type": "function",
            "function": {
                "name": "str_replace_editor",
                "arguments": '{
                    "command": "view",
                    "path": "/tmp/test.txt",
                    "view_range": "[1, 5]"
                }'
            }
        }]
    }

    Expected output: `"view_range" : [1, 5]`

    Note: The arguments field is a JSON string. When decoded, view_range is
    incorrectly a string "[1, 5]" instead of the proper array [1, 5].
    This function automatically fixes this by detecting that view_range
    expects a list type and decoding the JSON string to get the actual array.

    Args:
        arguments: The parsed arguments dict from json.loads(tool_call.arguments).
        action_type: The model or JSON Schema defining expected arguments.

    Returns:
        The arguments dict with JSON strings decoded where appropriate.
    """
    if not isinstance(arguments, dict):
        return arguments

    fixed_arguments = arguments.copy()

    if isinstance(action_type, dict):
        defs = action_type.get("$defs", {})
        field_types = [
            (field_name, _json_schema_expected_types(field_schema, defs))
            for field_name, field_schema in action_type.get("properties", {}).items()
            if isinstance(field_schema, dict)
        ]
    else:
        field_types = []
        for field_name, field_info in action_type.model_fields.items():
            data_key = field_info.alias if field_info.alias else field_name
            expected_type = field_info.annotation
            if get_origin(expected_type) is Annotated:
                type_args = get_args(expected_type)
                expected_type = type_args[0] if type_args else expected_type

            origin = get_origin(expected_type)
            if origin is Union or origin is types.UnionType:
                type_args = get_args(expected_type)
                expected_origins = [get_origin(arg) or arg for arg in type_args]
            else:
                expected_origins = [origin or expected_type]
            field_types.append((data_key, expected_origins))

    for data_key, expected_origins in field_types:
        if data_key not in fixed_arguments:
            continue

        value = fixed_arguments[data_key]

        # Rejoin a str-only field that a model chunked into a JSON array.
        if _is_chunked_str_field(value, expected_origins):
            fixed_arguments[data_key] = "".join(value)
            continue

        # Skip non-strings — the JSON decoding below only works on strings.
        if not isinstance(value, str):
            continue

        # Check if any of the expected types is list or dict
        if any(exp in (list, dict) for exp in expected_origins):
            # Try to parse the string as JSON
            try:
                # `strict=False` allows control characters (e.g. newlines) that
                # the outer json.loads decoded from escape sequences.
                # https://docs.python.org/3/library/json.html#json.JSONDecoder
                parsed_value = json.loads(value, strict=False)
                # json.loads() returns dict, list, str, int, float, bool, or None
                # Only use parsed value if it matches expected collection types
                if isinstance(parsed_value, (list, dict)):
                    fixed_arguments[data_key] = parsed_value
            except (json.JSONDecodeError, ValueError):
                # LLMs sometimes append trailing garbage (e.g. XML tags)
                # after valid JSON. Truncate at the last } or ] and retry.
                for end_char in ("}", "]"):
                    idx = value.rfind(end_char)
                    if idx == -1:
                        continue
                    with contextlib.suppress(json.JSONDecodeError, ValueError):
                        parsed_value = json.loads(value[: idx + 1], strict=False)
                        if isinstance(parsed_value, (list, dict)):
                            truncated = value[idx + 1 :]
                            logger.warning(
                                "Truncated trailing garbage from tool argument %r: %r",
                                data_key,
                                truncated,
                            )
                            fixed_arguments[data_key] = parsed_value
                            break
    return fixed_arguments


TOOL_NAME_ALIASES: dict[str, str] = {
    "bash": "terminal",
    "command": "terminal",
    "execute": "terminal",
    "execute_bash": "terminal",
    "git": "terminal",
    "reset": "terminal",
    "str_replace": "file_editor",
    "str_replace_editor": "file_editor",
}

# Regex to detect malformed tool names (e.g., "str_replace </parameter"
# or "str_replace</function>"). These occur when LLMs emit XML/HTML
# tag fragments in tool names. The leading identifier is extracted and
# used as the lookup key.
_MALFORMED_TOOL_NAME_RE = re.compile(r"^([a-zA-Z_][a-zA-Z0-9_]*)")


def _extract_tool_name_base(tool_name: str) -> str:
    """Return the leading identifier of ``tool_name``.

    This is used to recover from malformed tool names like
    ``"str_replace </parameter"`` or ``"str_replace</function>"`` that LLMs
    sometimes emit by appending XML/HTML tag fragments. If ``tool_name``
    has no valid leading identifier, return it unchanged.
    """
    match = _MALFORMED_TOOL_NAME_RE.match(tool_name)
    return match.group(1) if match else tool_name


# Terminal aliases that prepend the tool name to the command argument.
# Unlike 'bash' which passes through the command directly, these tools
# (e.g., 'git', 'reset') are themselves commands that should be combined
# with their arguments (e.g., 'git status', 'reset clear').
_TERMINAL_COMMAND_PREFIX_ALIASES = frozenset({"git", "reset"})

# This fallback is intentionally tiny: it only accepts exact, bare command names
# that are useful as read-only defaults when some models emit them as tool names.
_SHELL_TOOL_FALLBACK_COMMANDS = frozenset({"find", "git", "ls", "pwd"})

# Typo normalization for common mistakes in security_risk field
_SECURITY_RISK_TYPOS = {"security_rort", "securtiy_risk", "security_riks"}


def _normalize_arguments(arguments: dict[str, Any]) -> dict[str, Any]:
    """Normalize common typos and inconsistencies in tool arguments."""
    normalized = arguments.copy()

    # Fix security_risk typos
    for typo in _SECURITY_RISK_TYPOS:
        if typo in normalized:
            normalized["security_risk"] = normalized.pop(typo)
            break

    # Remove any arguments that are clearly not valid (None values, etc.)
    # but keep all others to preserve tool-specific arguments
    return {k: v for k, v in normalized.items() if v is not None}


def parse_tool_call_arguments(raw_arguments: str) -> dict[str, Any]:
    """Parse tool call arguments, sanitizing raw control chars only on fallback."""
    try:
        parsed = json.loads(raw_arguments)
    except json.JSONDecodeError:
        sanitized_args = sanitize_json_control_chars(raw_arguments)
        parsed = json.loads(sanitized_args)

    result = parsed if isinstance(parsed, dict) else {}
    return _normalize_arguments(result)


def _infer_file_editor_command(arguments: dict[str, Any]) -> str | None:
    if "command" in arguments:
        return None
    if "old_str" in arguments:
        return "str_replace"
    if "insert_line" in arguments:
        return "insert"
    if "file_text" in arguments:
        return "create"
    if "path" in arguments:
        return "view"
    return None


def _has_file_editor_hint(arguments: dict[str, Any]) -> bool:
    """Check if arguments contain any hint that this is a file_editor call."""
    file_editor_hints = frozenset(
        {
            "old_str",
            "new_str",
            "insert_line",
            "file_text",
            "path",
            "view_range",
        }
    )
    return bool(arguments and any(k in arguments for k in file_editor_hints))


_GREP_FALLBACK_SCRIPT = textwrap.dedent(
    """
    import fnmatch
    import pathlib
    import re
    import sys

    pattern = sys.argv[1]
    root = pathlib.Path(sys.argv[2])
    include = sys.argv[3] if len(sys.argv) > 3 else None
    regex = re.compile(pattern, re.IGNORECASE)

    if root.is_file():
        candidates = [root]
    else:
        candidates = []
        for path in root.rglob("*"):
            if not path.is_file():
                continue
            try:
                relative_parts = path.relative_to(root).parts
            except ValueError:
                relative_parts = (path.name,)
            if any(part.startswith(".") for part in relative_parts[:-1]):
                continue
            if include:
                if not fnmatch.fnmatch(path.name, include):
                    continue
            elif path.name.startswith("."):
                continue
            candidates.append(path)
        candidates.sort(key=lambda candidate: candidate.stat().st_mtime, reverse=True)

    for path in candidates:
        if root.is_file():
            if include and not fnmatch.fnmatch(path.name, include):
                continue
            if not include and path.name.startswith("."):
                continue
        try:
            with path.open(encoding="utf-8", errors="ignore") as handle:
                for line_number, line in enumerate(handle, start=1):
                    if regex.search(line):
                        sys.stdout.write(f"{path}:{line_number}:{line}")
        except OSError:
            continue
    """
).strip()


def _join_shell_command(parts: list[str]) -> str:
    """Join a command list using the current platform's shell quoting rules."""
    if os.name == "nt":
        return subprocess.list2cmdline(parts)
    return shlex.join(parts)


def _build_ripgrep_terminal_command(
    pattern: str,
    search_path: str,
    include: str | None,
) -> str:
    command_parts = ["rg", "-n", "-i", pattern, search_path, "--sortr=modified"]
    if include:
        command_parts.extend(["-g", include])
    return _join_shell_command(command_parts)


def _build_system_grep_terminal_command(
    pattern: str,
    search_path: str,
    include: str | None,
) -> str:
    command_parts = ["grep", "-R", "-I", "-n", "-i", pattern, search_path]
    if include:
        command_parts.append(f"--include={include}")
    return _join_shell_command(command_parts)


def _build_python_grep_terminal_command(
    pattern: str,
    search_path: str,
    include: str | None,
) -> str:
    command_parts = ["python", "-c", f"exec({_GREP_FALLBACK_SCRIPT!r})", pattern]
    command_parts.append(search_path)
    if include:
        command_parts.append(include)
    return _join_shell_command(command_parts)


def _build_grep_terminal_command(arguments: dict[str, Any]) -> str | None:
    """Return a portable terminal command for structured grep fallbacks.

    Returning ``None`` keeps malformed grep payloads on the normal "tool not
    found" path instead of broadening terminal execution.
    """
    pattern = arguments.get("pattern")
    if not isinstance(pattern, str) or not pattern.strip():
        return None

    path = arguments.get("path")
    search_path = path if isinstance(path, str) and path.strip() else "."

    include = arguments.get("include")
    include_pattern = include if isinstance(include, str) and include.strip() else None

    if shutil.which("rg") is not None:
        return _build_ripgrep_terminal_command(pattern, search_path, include_pattern)
    if shutil.which("grep") is not None:
        return _build_system_grep_terminal_command(
            pattern, search_path, include_pattern
        )
    return _build_python_grep_terminal_command(pattern, search_path, include_pattern)


def _maybe_rewrite_as_terminal_command(
    tool_name: str,
    arguments: dict[str, Any],
) -> str | None:
    """Return a narrow terminal fallback for shell-style tool names.

    Aliases are handled before this helper, so Anthropic-style names like
    ``str_replace`` normalize to canonical SDK tools instead of being treated as
    shell commands. This helper only runs for otherwise-unknown names when the
    agent already exposes ``terminal``.
    """
    if tool_name == "grep":
        return _build_grep_terminal_command(arguments)

    if arguments or tool_name not in _SHELL_TOOL_FALLBACK_COMMANDS:
        return None

    return tool_name


def normalize_tool_call(
    tool_name: str,
    arguments: dict[str, Any],
    available_tools: Collection[str],
) -> tuple[str, dict[str, Any]]:
    """Normalize legacy tool names and Anthropic-style argument shapes.

    Precedence is intentional: preserve explicitly registered tools first,
    then apply legacy aliases for unknown names, terminal fallback only
    applies to still-unknown names, and file_editor command inference runs
    after the canonical tool name is known.
    """
    normalized_tool_name = tool_name
    normalized_arguments = arguments.copy()

    # Only apply aliases for tool names that are not explicitly registered.
    # This prevents hijacking legitimate tools that share names with aliases.
    if tool_name not in available_tools:
        # Extract the leading identifier so we can recover from malformed names
        # like "str_replace </parameter" (the LLM appended an XML fragment).
        # For clean names like "git" this is a no-op.
        base_name = _extract_tool_name_base(tool_name)
        alias_target = TOOL_NAME_ALIASES.get(base_name)
        if base_name != tool_name and base_name in available_tools:
            normalized_tool_name = base_name
        elif alias_target and alias_target in available_tools:
            normalized_tool_name = alias_target
            # For terminal alias with prefix, combine tool name with command
            if (
                alias_target == "terminal"
                and base_name in _TERMINAL_COMMAND_PREFIX_ALIASES
            ):
                original_command = arguments.get("command")
                normalized_arguments = {
                    key: value
                    for key, value in arguments.items()
                    if key in {"security_risk", "summary"}
                }
                if not original_command:
                    normalized_arguments["command"] = base_name
                elif str(original_command).split(maxsplit=1)[:1] == [base_name]:
                    # Already carries the executable, e.g. git(command="git status").
                    # Comparing whole tokens keeps "github status" prefixed.
                    normalized_arguments["command"] = original_command
                else:
                    normalized_arguments["command"] = f"{base_name} {original_command}"
        elif "terminal" in available_tools:
            terminal_command = _maybe_rewrite_as_terminal_command(
                tool_name,
                normalized_arguments,
            )
            if terminal_command is not None:
                normalized_tool_name = "terminal"
                # Preserve only terminal-relevant arguments (security_risk, summary)
                # along with the generated command
                normalized_arguments = {
                    key: value
                    for key, value in normalized_arguments.items()
                    if key in {"security_risk", "summary"}
                }
                normalized_arguments["command"] = terminal_command

    if normalized_tool_name == "file_editor":
        inferred_command = _infer_file_editor_command(normalized_arguments)
        if inferred_command is not None:
            normalized_arguments = {
                "command": inferred_command,
                **normalized_arguments,
            }
        elif not normalized_arguments or (
            "command" not in normalized_arguments
            and not _has_file_editor_hint(normalized_arguments)
        ):
            raise ValueError(
                f"Cannot infer 'command' for tool '{normalized_tool_name}' "
                f"from empty arguments {normalized_arguments!r}. "
                f"Expected one of: str_replace, insert, create, view with "
                f"appropriate arguments (e.g., old_str for str_replace, "
                f"path for view)."
            )

    return normalized_tool_name, normalized_arguments


@overload
def prepare_llm_messages(
    view: View,
    condenser: None = None,
    additional_messages: list[Message] | None = None,
    llm: LLM | None = None,
) -> list[Message]: ...


@overload
def prepare_llm_messages(
    view: View,
    condenser: CondenserBase,
    additional_messages: list[Message] | None = None,
    llm: LLM | None = None,
) -> list[Message] | Condensation: ...


def prepare_llm_messages(
    view: View,
    condenser: CondenserBase | None = None,
    additional_messages: list[Message] | None = None,
    llm: LLM | None = None,
) -> list[Message] | Condensation:
    """Prepare LLM messages from a conversation view.

    This utility function extracts the common logic for preparing conversation
    context that is shared between agent.step() and ask_agent() methods.
    It handles condensation internally and calls the callback when needed.

    Callers should pass the cached `ConversationState.view`, which is
    maintained incrementally as events are appended. This avoids paying the
    O(n) `View.from_events` (with `enforce_properties`) cost on every step.
    See https://github.com/OpenHands/software-agent-sdk/issues/3053.

    Args:
        view: A `View` of the conversation history. The view is treated as
            read-only — see `CondenserBase.condense` for the same contract.
        condenser: Optional condenser for handling context window limits
        additional_messages: Optional additional messages to append
        llm: Optional LLM instance from the agent, passed to condenser for
            token counting or other LLM features

    Returns:
        List of messages ready for LLM completion, or a Condensation event
        if condensation is needed
    """
    llm_convertible_events: list[LLMConvertibleEvent] = view.events

    # If a condenser is registered, we need to give it an
    # opportunity to transform the events. This will either
    # produce a list of events, exactly as expected, or a
    # new condensation that needs to be processed
    if condenser is not None:
        condensation_result = condenser.condense(view, agent_llm=llm)

        match condensation_result:
            case View():
                llm_convertible_events = condensation_result.events

            case Condensation():
                return condensation_result

    # Convert events to messages
    messages = LLMConvertibleEvent.events_to_messages(llm_convertible_events)

    # Add any additional messages (e.g., user question for ask_agent)
    if additional_messages:
        messages.extend(additional_messages)

    return messages


# ---------------------------------------------------------------------------
# Async variants
# ---------------------------------------------------------------------------


async def aprepare_llm_messages(
    view: View,
    condenser: CondenserBase | None = None,
    additional_messages: list[Message] | None = None,
    llm: LLM | None = None,
) -> list[Message] | Condensation:
    """Async variant of :func:`prepare_llm_messages`.

    Calls ``condenser.acondense()`` so that condensers backed by an LLM can
    use async completions without blocking the event loop.
    """
    llm_convertible_events: list[LLMConvertibleEvent] = view.events

    if condenser is not None:
        condensation_result = await condenser.acondense(view, agent_llm=llm)

        match condensation_result:
            case View():
                llm_convertible_events = condensation_result.events
            case Condensation():
                return condensation_result

    messages = LLMConvertibleEvent.events_to_messages(llm_convertible_events)

    if additional_messages:
        messages.extend(additional_messages)

    return messages
