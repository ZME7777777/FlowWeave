"""Parallel tool execution for agent.

This module provides utilities for executing multiple tool calls concurrently
with a configurable per-agent concurrency limit and resource-level locking.

Resource locking (via ``ResourceLockManager``) ensures that tools operating on
the same shared state (files, terminal session, browser, …) are serialized,
while tools touching *different* resources can run concurrently.

.. warning:: Thread safety of individual tools

   When ``tool_concurrency_limit > 1``, multiple tools run in parallel
   threads sharing the same ``conversation`` object. The executor uses
   ``ResourceLockManager`` to serialize access to shared resources, but
   tools must correctly implement ``declared_resources()`` for this
   to be effective.
"""

from __future__ import annotations

import asyncio
import contextvars
from collections.abc import Callable, Sequence
from concurrent.futures import ThreadPoolExecutor
from typing import TYPE_CHECKING

from openhands.sdk.conversation.cancellation import CancellationToken
from openhands.sdk.conversation.resource_lock_manager import ResourceLockManager
from openhands.sdk.event.error_classification import (
    AGENT_OUTCOME,
    ErrorClassification,
    FailureKind,
)
from openhands.sdk.event.llm_convertible import AgentErrorEvent
from openhands.sdk.logger import get_logger
from openhands.sdk.observability.laminar import record_tool_result
from openhands.sdk.observability.utils import extract_action_name


if TYPE_CHECKING:
    from openhands.sdk.event.base import Event
    from openhands.sdk.event.llm_convertible import ActionEvent
    from openhands.sdk.tool.tool import DeclaredResources, ToolDefinition

logger = get_logger(__name__)

#: Unexpected internal failure - should surface as a diagnostic, not an outcome.
_INTERNAL = ErrorClassification(kind=FailureKind.INTERNAL, retryable=False)


class ParallelToolExecutor:
    """Executes a batch of tool calls concurrently with resource locking.

    Each instance has its own thread pool, concurrency limit, and
    ``ResourceLockManager``, so nested execution (e.g., subagents) cannot
    deadlock the parent.
    """

    def __init__(
        self,
        max_workers: int = 1,
        lock_manager: ResourceLockManager | None = None,
    ) -> None:
        self._max_workers = max_workers
        self._lock_manager = lock_manager or ResourceLockManager()

    def execute_batch(
        self,
        action_events: Sequence[ActionEvent],
        tool_runner: Callable[[ActionEvent], list[Event]],
        tools: dict[str, ToolDefinition] | None = None,
        cancel_token: CancellationToken | None = None,
        span_owner: object | None = None,
    ) -> list[list[Event]]:
        """Execute a batch of action events concurrently.

        Args:
            action_events: Sequence of ActionEvent objects to execute.
            tool_runner: A callable that takes an ActionEvent and returns
                        a list of Event objects produced by the execution.
            tools: Optional mapping of tool name to ToolDefinition used
                   to derive resource keys for locking. When *None*,
                   locking is skipped (backward-compatible).
            cancel_token: If set and cancelled, pending tool calls are
                          skipped and return a synthetic error event.
            span_owner: Object carrying the conversation root span for
                        synthetic cancellation results.

        Returns:
            List of event lists in the same order as the input action_events.
        """
        if not action_events:
            return []

        def _resolve(ae: ActionEvent) -> ToolDefinition | None:
            return tools.get(ae.tool_name) if tools else None

        if len(action_events) == 1 or self._max_workers == 1:
            return [
                self._run_safe(
                    action,
                    tool_runner,
                    _resolve(action),
                    cancel_token,
                    span_owner,
                )
                for action in action_events
            ]

        with ThreadPoolExecutor(max_workers=self._max_workers) as executor:
            # submit() itself propagates no contextvars; a fresh copy per task
            # because one Context cannot be entered by two threads.
            futures = [
                executor.submit(
                    contextvars.copy_context().run,
                    self._run_safe,
                    action,
                    tool_runner,
                    _resolve(action),
                    cancel_token,
                    span_owner,
                )
                for action in action_events
            ]

        return [future.result() for future in futures]

    async def aexecute_batch(
        self,
        action_events: Sequence[ActionEvent],
        tool_runner: Callable[[ActionEvent], list[Event]],
        tools: dict[str, ToolDefinition] | None = None,
        cancel_token: CancellationToken | None = None,
        span_owner: object | None = None,
    ) -> list[list[Event]]:
        """Async variant of :meth:`execute_batch`.

        Each tool call is dispatched to a dedicated
        :class:`~concurrent.futures.ThreadPoolExecutor` (sized to
        ``max_workers``) via :func:`asyncio.loop.run_in_executor` and
        scheduled concurrently with :func:`asyncio.gather`. The pool
        itself bounds concurrency, matching the sync path's per-batch
        :class:`ThreadPoolExecutor`; using a dedicated pool avoids
        serializing on asyncio's shared default executor (small and
        process-wide), which could throttle previously-parallel tool
        calls when other ``run_in_executor`` users contend for it.

        The *tool_runner* is the same **synchronous** callable used by
        :meth:`execute_batch` (i.e. ``_execute_action_event``).
        ``span_owner`` anchors synthetic cancellation results to their root span.
        Resource locking via :class:`ResourceLockManager` (threading
        locks) works correctly because each tool call runs in its own
        thread.
        """
        if not action_events:
            return []

        def _resolve(ae: ActionEvent) -> ToolDefinition | None:
            return tools.get(ae.tool_name) if tools else None

        if len(action_events) == 1 or self._max_workers == 1:
            return [
                await self._arun_safe(
                    action,
                    tool_runner,
                    _resolve(action),
                    cancel_token,
                    span_owner=span_owner,
                )
                for action in action_events
            ]

        with ThreadPoolExecutor(
            max_workers=self._max_workers,
            thread_name_prefix="aexecute_batch",
        ) as pool:
            return list(
                await asyncio.gather(
                    *[
                        self._arun_safe(
                            action,
                            tool_runner,
                            _resolve(action),
                            cancel_token,
                            pool,
                            span_owner,
                        )
                        for action in action_events
                    ]
                )
            )

    async def _arun_safe(
        self,
        action: ActionEvent,
        tool_runner: Callable[[ActionEvent], list[Event]],
        tool: ToolDefinition | None = None,
        cancel_token: CancellationToken | None = None,
        executor: ThreadPoolExecutor | None = None,
        span_owner: object | None = None,
    ) -> list[Event]:
        """Run :meth:`_run_safe` in a thread via ``run_in_executor``.

        This keeps the event loop free while the (blocking) tool
        executes and ensures that ``ResourceLockManager``'s threading
        locks are acquired on the worker thread, not the event-loop
        thread.

        When *executor* is ``None`` the asyncio default pool is used
        (suitable for one-off / single-action calls); batch callers
        should pass a dedicated pool so concurrent tool calls don't
        contend with other ``run_in_executor`` users on the shared
        default pool.

        If the asyncio task is cancelled while the thread is running
        (e.g. via ``conversation.interrupt()``), we call
        ``tool.executor.interrupt()`` to signal the tool to abort
        (e.g. send Ctrl+C to a terminal subprocess).  The thread
        still runs to completion, but the interrupted command
        finishes quickly rather than blocking until its original
        timeout.
        """
        loop = asyncio.get_running_loop()
        # run_in_executor copies no contextvars, unlike asyncio.to_thread.
        ctx = contextvars.copy_context()

        def run_in_caller_context() -> list[Event]:
            return ctx.run(
                self._run_safe,
                action,
                tool_runner,
                tool,
                cancel_token,
                span_owner,
            )

        fut = loop.run_in_executor(executor, run_in_caller_context)
        try:
            return await fut
        except asyncio.CancelledError:
            # The asyncio task was cancelled (interrupt), but the
            # thread-pool worker is still running.  Signal the tool
            # to abort its in-flight work so the thread exits quickly.
            if tool is not None and tool.executor is not None:
                try:
                    tool.executor.interrupt()
                except Exception:
                    logger.debug(
                        "executor.interrupt() failed for '%s'",
                        action.tool_name,
                        exc_info=True,
                    )
            raise

    @staticmethod
    def _cancelled_error(
        action: ActionEvent, span_owner: object | None = None
    ) -> list[Event]:
        """Return a synthetic error for a tool call skipped due to cancellation."""
        error = AgentErrorEvent(
            error="Tool call cancelled by interrupt.",
            tool_name=action.tool_name,
            tool_call_id=action.tool_call_id,
            classification=AGENT_OUTCOME,
        )
        record_tool_result(
            span_owner if span_owner is not None else action,
            name=extract_action_name(action),
            tool_call_id=action.tool_call_id,
            tool_input=action.action,
            tool_output=error.to_llm_message(),
        )
        return [error]

    def _run_safe(
        self,
        action: ActionEvent,
        tool_runner: Callable[[ActionEvent], list[Event]],
        tool: ToolDefinition | None = None,
        cancel_token: CancellationToken | None = None,
        span_owner: object | None = None,
    ) -> list[Event]:
        """Run tool_runner with resource locking.

        Converts exceptions to ``AgentErrorEvent``.
        If *cancel_token* is set before the tool begins, the call is
        skipped and a synthetic error is returned.

        Locking strategy:

        - ``declared=False`` → ``tool:<name>`` mutex.
        - ``declared=True``, empty keys → no locking.
        - ``declared=True``, keys present → lock those resources.
        """
        if cancel_token is not None and cancel_token.is_cancelled:
            logger.info(
                "Skipping tool '%s' -- cancelled before execution",
                action.tool_name,
            )
            return self._cancelled_error(action, span_owner)

        try:
            if tool is None:
                return tool_runner(action)

            resources = self._extract_declared_resources(action, tool)
            lock_keys = self._resolve_lock_keys(resources, tool)
            if not lock_keys:
                return tool_runner(action)
            with self._lock_manager.lock(*lock_keys):
                return tool_runner(action)

        except ValueError as e:
            logger.info(f"Tool error in '{action.tool_name}': {e}")
            return [
                AgentErrorEvent(
                    error=f"Error executing tool '{action.tool_name}': {e}",
                    tool_name=action.tool_name,
                    tool_call_id=action.tool_call_id,
                    classification=AGENT_OUTCOME,
                )
            ]
        except Exception as e:
            logger.error(
                f"Unexpected error in tool '{action.tool_name}': {e}",
                exc_info=True,
            )
            return [
                AgentErrorEvent(
                    error=f"Error executing tool '{action.tool_name}': {e}",
                    tool_name=action.tool_name,
                    tool_call_id=action.tool_call_id,
                    classification=_INTERNAL,
                )
            ]

    @staticmethod
    def _extract_declared_resources(
        action: ActionEvent,
        tool: ToolDefinition,
    ) -> DeclaredResources | None:
        """Call ``tool.declared_resources()`` if the action is parsed."""
        parsed_action = action.action
        return tool.declared_resources(parsed_action) if parsed_action else None

    @staticmethod
    def _resolve_lock_keys(
        resources: DeclaredResources | None,
        tool: ToolDefinition,
    ) -> list[str]:
        """Turn declared resources into lock keys.

        Returns an empty list when no locking is needed.
        """
        if resources is None or not resources.declared:
            return [f"tool:{tool.name}"]
        return list(resources.keys)
